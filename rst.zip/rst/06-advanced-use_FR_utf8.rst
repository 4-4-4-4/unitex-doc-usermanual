Utilisation avancée des graphes
===============================

Les types de graphes
--------------------

Unitex peut manipuler plusieurs types de graphes qui correspondent aux
utilisations suivantes : flexion automatique de dictionnaires,
prétraitement des textes, normalisation des automates de textes, graphes
dictionnaires, recherche de motifs, levée d’ambiguïtés et génération
automatique de graphes. Ces différents types de graphes ne sont pas
interprétés de la même façon par Unitex. Certaines choses comme les
sorties sont permises pour certains types et interdites pour d’autres.
De plus, les symboles spéciaux ne sont pas les mêmes en fonction du type
de graphe. Cette section présente donc chacun des types de graphes en
détaillant leurs particularités.

Graphes de flexion
~~~~~~~~~~~~~~~~~~

Un graphe de flexion décrit les variations morphologiques associées à
une classe de mots, en associant à chaque variante des codes
flexionnels. Les chemins d’un tel graphe décrivent les modifications à
appliquer aux formes canoniques tandis que les sorties contiennent les
informations flexionnelles qui seront produites.

.. figure:: resources/img/fig6-1.png
   :alt: Exemple de grammaire de flexion
   :width: 4.50000cm

   Exemple de grammaire de flexion

Les chemins peuvent contenir des opérateurs et des lettres. Les
opérateurs possibles sont représentés par les caractères ``L``, ``R``,
``C``, ``D``, ``U``, ``P`` et ``W``. Les lettres qui ne sont pas des
opérateurs sont des caractères. Le seul symbole spécial autorisé est le
mot vide ``<E>``. Il n’est pas possible de faire référence aux
dictionnaires dans un graphe de flexion. Il est cependant possible de
faire appel à des sous-graphes.

Les sorties sont concaténées pour produire une chaîne de caractères.
Cette chaîne est ensuite concaténée à la ligne de dictionnaire produite.
Les sorties à variables n’ont pas de sens dans un graphe de flexion.

Le contenu d’un graphe de flexion est manipulé sans aucune variante de
casse: les lettres minuscules restent minuscules, idem pour les
majuscules. En outre, la liaison de deux boîtes est strictement
équivalente à la concaténation de leurs contenus munie de la
concaténation de leurs sorties (voir
figure [fig-equivalent-inflection-paths]).

.. figure:: resources/img/fig6-2.png
   :alt: Deux chemins équivalents dans une grammaire de
   flexion[fig-equivalent-inflection-paths]
   :width: 5.50000cm

   Deux chemins équivalents dans une grammaire de
   flexion[fig-equivalent-inflection-paths]

Les graphes de flexion doivent être compilés avant de pouvoir être
utilisés par le pro- gramme de flexion.

Pour plus de détails, voir section [section-automatic-inflection].

Graphes de prétraitement
~~~~~~~~~~~~~~~~~~~~~~~~

Les graphes de prétraitement sont destinés à être appliqués aux textes
avant que ceux-ci soient découpés en unités lexicales. Ces graphes
peuvent être utilisés pour insérer ou remplacer des séquences dans les
textes. Les deux utilisations usuelles de ces graphes sont la
normalisation de formes non ambiguës et le découpage en phrases.

L’interprétation de ces graphes dans Unitex est très proche de celle des
graphes syntaxiques utilisés pour la recherche de motifs. Les
différences sont les suivantes:

-  on peut utiliser le symbole spécial ``<^>`` qui reconnaît un retour à
   la ligne;

-  si l’on travaille en mode caractère par caractère, il est possible
   d’utiliser le symbole spécial ``<L>`` qui reconnaît une lettre, telle
   que définie dans le fichier alphabet;

-  il est impossible de faire référence aux dictionnaires;

-  il est impossible d’utiliser les filtres morphologiques;

-  il est impossible d’utiliser le mode morphologique;

-  il est impossible d’utiliser des contextes.

Les figures [fig-example-sentence-splitting] (page )
et [fig-normalization-grammar] (page ) montrent des exemples de graphes
de prétraitement.

Graphes de normalisation de l’automate du texte
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Les graphes de normalisation de l’automate du texte permettent de
normaliser des formes ambiguës. En effet, ils peuvent décrire plusieurs
étiquettes pour une même forme. Ces étiquettes sont ensuite insérées
dans l’automate du texte, explicitant ainsi les ambiguïtés. La
figure [fig-tfst-normalization-grammar] montre un extrait du graphe de
normalisation utilisé pour le français.

.. figure:: resources/img/fig6-3.png
   :alt: Extrait du graphe de normalisation utilisé pour le
   français[fig-tfst-normalization-grammar]
   :width: 13.50000cm

   Extrait du graphe de normalisation utilisé pour le
   français[fig-tfst-normalization-grammar]

Les chemins décrivent les formes qui doivent être normalisées. Les
variantes minuscules et majuscules sont prises en compte selon le
principe suivant : les lettres majuscules dans le graphe ne
reconnaissent que les lettres majuscules dans l’automate du texte ; les
lettres minuscules peuvent reconnaître les lettres minuscules et
majuscules.

Les sorties représentent les séquences d’étiquettes qui seront insérées
dans l’automate du texte. Ces étiquettes peuvent être des entrées de
dictionnaires ou de simples chaînes de caractères. Les étiquettes
représentant des entrées de dictionnaire doivent respecter le format des
entrées d’un DELAF et être encadrées par les symboles ``{`` et ``}``.
Les sorties à variables n’ont pas de sens dans ce type de graphe.

Il est possible de faire appel à des sous-graphes. Il n’est pas possible
de faire référence aux dictionnaires pour décrire les formes à
normaliser. L’unique symbole spécial reconnu dans ce type de graphe est
le mot vide ``<E>``. Les graphes de normalisation de formes ambiguës
doivent être compilés avant de pouvoir être utilisés.

Graphes syntaxiques
~~~~~~~~~~~~~~~~~~~

Les graphes syntaxiques, également appelés grammaires locales,
permettent de décrire des motifs syntaxiques qui pourront ensuite être
recherchés dans des textes. De tous les types de graphe, ceux-ci
possèdent la plus grande puissance d’expressions, car ils permettent de
faire référence aux dictionnaires.

Les variantes minuscules/majuscules sont autorisées selon le principe
décrit plus haut. Il est toutefois possible de forcer le respect de la
casse en encadrant une expression avec des guillemets. L’emploi des
guillemets permet également de forcer le respect des espacements. En
effet, Unitex considère, par défaut, qu’un espace est possible entre
deux boîtes. Pour forcer la présence d’un espace, il faut le mettre
entre guillemets. Pour interdire la présence d’un espace, il faut
utiliser le symbole spécial ``#``.

Les graphes syntaxiques peuvent faire appel à des sous-graphes (voir
section  [section-subgraphs]). Ils gèrent également les sorties, y
compris les sorties à variables. Les séquences produites sont
interprétées comme des chaînes de caractères qui seront insérées dans
les concordances ou dans le texte si vous voulez modifier celui-ci (voir
section  [section-modifying-text]).

Les graphes syntaxiques peuvent utiliser des contextes (voir
section [section-contexts]).

Les graphes syntaxiques peuvent utiliser des filtres morphologiques
(voir section [section-filters]).

Les graphes syntaxiques peuvent utiliser le mode morphologique (voir
section [section-morphological-mode]).

Les symboles spéciaux supportés par les graphes syntaxiques sont les
mêmes que ceux utilisables dans les expressions rationnelles (voir
section [section-special-symbols]).

Il n’est pas obligatoire de compiler les graphes syntaxiques avant de
les utiliser pour la recherche de motifs. Si un graphe n’est pas
compilé, le système le compilera automatiquement.

Grammaires ELAG
~~~~~~~~~~~~~~~

La syntaxe des grammaires de levée d’ambiguïtés est présentée à la
section [section-elag-grammars], page .

Graphes paramétrés
~~~~~~~~~~~~~~~~~~

Les graphes paramétrés sont des méta-graphes permettant de générer une
famille de graphes à partir d’une table de lexique-grammaire. Il est
possible de construire des graphes paramétrés pour n’importe quel type
de graphe. La construction et l’utilisation des graphes paramétrés
seront développées dans le chapitre  [chap-lexicon-grammar].

Compilation d’une grammaire
---------------------------

Compilation d’un graphe
~~~~~~~~~~~~~~~~~~~~~~~

La compilation est l’opération qui permet de passer du format ``.grf`` à
un format plus facile à manipuler par les programmes d’Unitex. Pour
compiler un graphe, vous devez l’ouvrir, puis cliquer sur “Compile FST2”
dans le sous-menu “Tools” du menu “FSGraph”. Unitex lance alors le
programme ``Grf2Fst2`` dont vous pouvez suivre l’exécution dans une
fenêtre (voir figure [fig-compilation-frame]).

.. figure:: resources/img/fig6-4.png
   :alt: Fenêtre de compilation[fig-compilation-frame]
   :width: 14.70000cm

   Fenêtre de compilation[fig-compilation-frame]

Si le graphe fait appel à des sous-graphes, ceux-ci sont automatiquement
compilés. Le résultat est un fichier ``.fst2`` fichier qui rassemble
tous les graphes qui composent la grammaire. La grammaire est alors
prête à être utilisée par les différents programmes d’Unitex.

Approximation par un transducteur fini
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

[flatten-section] Le format FST2 conserve l’architecture en sous-graphes
des grammaires, ce qui les différencie des stricts transducteurs à états
finis. Le programme ``Flatten`` permet de transformer une grammaire FST2
en un transducteur à états finis quand cela est possible, et d’en
construire une approximation dans le cas contraire. Cette fonction
permet ainsi d’obtenir des objets plus simples à manipuler et sur
lesquels peuvent s’appliquer tous les algorithmes classiques sur les
automates.

Pour compiler et transformer ainsi une grammaire, sélectionnez la
commande “Compile Flatten FST2” dans le sous-menu “Tools” du menu
“FSGraph”. La fenêtre de la figure [fig-flatten-configuration] vous
permet de configurer l’opération d’approximation.

.. figure:: resources/img/fig6-5.png
   :alt: Configuration de l’approximation d’une
   grammaire[fig-flatten-configuration]
   :width: 10.40000cm

   Configuration de l’approximation d’une
   grammaire[fig-flatten-configuration]

Le cadre “Flattening depth” permet de préciser le niveau d’imbrication
des sous-graphes. Cette valeur représente la profondeur maximale au-delà
de laquelle les appels à des sous- graphes ne seront plus remplacés par
les sous-graphes eux-mêmes.

Le cadre “Expected result grammar format” permet de déterminer le
comportement du programme au-delà de la limite indiquée. Si vous
sélectionnez l’option “Finite State Transducer”, les appels aux
sous-graphes seront ignorés (remplacé par ``<E>``) au-delà de la
profondeur maximale. Cette option garantit ainsi l’obtention d’un
transducteur à états finis, éventuellement non équivalent à la grammaire
de départ. En revanche, l’option “equivalent FST2” indique au programme
de laisser tels quels les appels aux sous-graphes au-delà de la
profondeur limite. Cette option garantit la stricte équivalence du
résultat avec la grammaire d’origine, mais ne produit pas forcément un
transducteur à états finis. Cette option peut être utilisée pour
optimiser certaines grammaires.

Un message indique à la fin du processus d’approximation si le résultat
est un transducteur à états finis ou une grammaire FST2, et dans le cas
d’un transducteur, s’il est équivalent à la grammaire d’origine (voir
figure [fig-flatten-result]).

.. figure:: resources/img/fig6-6.png
   :alt: Résultat de l’approximation d’une grammaire[fig-flatten-result]
   :width: 14.70000cm

   Résultat de l’approximation d’une grammaire[fig-flatten-result]

Contraintes sur les grammaires
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

À l’exception des grammaires de flexion, une grammaire ne peut pas avoir
de chemin vide. Cela signifie que le graphe principal d’une grammaire ne
doit pas pouvoir reconnaître le mot vide, mais cela n’empêche pas un
sous-graphe de cette grammaire de reconnaître epsilon.

Il n’est pas possible d’associer une sortie à un appel à un sous-graphe.
De telles sorties sont ignorées par Unitex. Il faut donc utiliser une
boîte vide située immédiatement à gauche de l’appel au sous-graphe pour
porter la sortie (voir figure [fig-subgraph-output]).

.. figure:: resources/img/fig6-7.png
   :alt: Comment associer une sortie à un appel de
   sous-graphe[fig-subgraph-output]
   :width: 9.10000cm

   Comment associer une sortie à un appel de
   sous-graphe[fig-subgraph-output]

Les grammaires ne doivent pas non plus comporter de boucles infinies,
car les programmes d’Unitex ne pourraient jamais terminer l’exploration
de telles grammaires. Ces boucles peuvent être dues à des transitions
étiquetées par le mot vide epsilon ou à des appels de sous-graphes
récursifs.

Les boucles dues à des transitions par le mot vide peuvent avoir deux
origines dont la première est illustrée par la
figure [fig-epsilon-output-loop]. Ce type de boucle est dû au fait
qu’une transition par le mot vide ne peut pas être éliminée
automatiquement par Unitex lorsqu’elle est munie d’une sortie. Ainsi, la
transition par le mot vide de la figure [fig-epsilon-output-loop] ne
sera pas supprimée et provoquera une boucle infinie.

.. figure:: resources/img/fig6-8.png
   :alt: Boucle infinie due à une transition par le mot vide avec
   sortie[fig-epsilon-output-loop]
   :width: 6.20000cm

   Boucle infinie due à une transition par le mot vide avec
   sortie[fig-epsilon-output-loop]

La seconde catégorie de boucle par epsilon concerne les appels à des
sous-graphes pouvant reconnaître le mot vide. Ce cas de figure est
illustré par la figure [fig-epsilon-subgraph-loop]: si le sous-graphe
``Adj`` reconnait epsilon, on a une boucle infinie qu’Unitex ne peut pas
éliminer.

.. figure:: resources/img/fig6-9.png
   :alt: Boucle infinie due à un appel à un sous-graphe reconnaissant
   epsilon [fig-epsilon-subgraph-loop]
   :width: 7.90000cm

   Boucle infinie due à un appel à un sous-graphe reconnaissant epsilon
   [fig-epsilon-subgraph-loop]

.. figure:: resources/img/fig6-10.png
   :alt: Boucle infinie causée par deux graphes s’appelant l’un l’autre
   [fig-recursive-calls-loop]
   :width: 15.50000cm

   Boucle infinie causée par deux graphes s’appelant l’un l’autre
   [fig-recursive-calls-loop]

La troisième possibilité de boucle infinie concerne les appels récursifs
à des sous-graphes. Considérons les graphes ``Det`` et ``DetCompose`` de
la figure [fig-recursive-calls-loop]. Chacun de ces graphes peut appeler
l’autre *sans rien lire dans le texte*. Le fait qu’aucun des deux
graphes ne comporte d’étiquette entre l’état initial et l’appel à
l’autre graphe est capital. En effet, s’il y avait au moins une
étiquette différente d’epsilon entre le début du graphe ``Det`` et
l’appel à ``DetCompose``, cela signifierait que les programmes d’Unitex
explorant le graphe ``Det`` devraient lire le motif décrit par cette
étiquette dans le texte avant d’appeler récursivement ``DetCompose``
Dans ce cas, les programmes ne pourraient boucler indéfiniment que s’ils
rencontraient une infinité de fois le motif dans le texte, ce qui ne
peut pas arriver.

Intervalle pour le nombre de répétitions
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Pour reconnaître des séquences de tokens dans laquelle un motif apparaît
une fois, plusieurs fois ou jamais, on peut associer un intervalle
d’entiers à une boîte. Cela fixe les limites du nombre de fois que le
motif apparait. Le motif doit être décrit dans une boite unique. Si on
associe un intervalle [m,M] à une boîte contenant <A>
(figure [intervals]), le chemin reconnaitra des séquences avec au moins
:math:`m` adjectifs consécutifs et pas plus de :math:`M`.

.. figure:: resources/img/fig6-10a.png
   :alt: Utilisation d’un intervalle pour reconnaître plusieurs tokens
   consécutifs[intervals]
   :width: 13.50000cm

   Utilisation d’un intervalle pour reconnaître plusieurs tokens
   consécutifs[intervals]

On attache un intervalle en insérant ``$[m,M]$`` dans la sortie de la
boite, juste après le caractère “/”, et selon les règles :

-  ``[m,M]`` = au moins :math:`m` motifs consécutifs et pas de plus de
   :math:`M`

-  ``[,M]`` = de 0 à :math:`M`

-  ``[m,]`` = au moins :math:`m`

La boite ne doit pas être connectée à elle-même par une boucle directe.
Un intervalle est compatible avec une sortie au sens habituel. Par
exemple, pour insérer sous la boite de la figure [intervals] la sortie
``<ADJ position='antéposé'>``, saisissez dans le champ texte :
``<A>/$[1,4]$/<ADJ position='antéposé'>``.

Détection d’erreurs
~~~~~~~~~~~~~~~~~~~

Pour éviter aux programmes de se bloquer ou de planter, Unitex effectue
automatique- ment une détection d’erreurs lors de la compilation des
graphes. Le compilateur de graphes vérifie que le graphe principal ne
reconnaît pas le mot vide et recherche toutes les formes de boucles
infinies. Si une erreur est trouvée, un message d’erreur apparaît dans
la fenêtre de compilation. La figure  [fig-error-message] montre le
message obtenu lorsqu’on tente de compiler le graphe ``Det`` de la
figure [fig-recursive-calls-loop].

.. figure:: resources/img/fig6-11.png
   :alt: Message d’erreur obtenu en compilant le graphe
   ``Det``\ [fig-error-message]
   :width: 15.00000cm

   Message d’erreur obtenu en compilant le graphe
   ``Det``\ [fig-error-message]

Si vous avez lancé une recherche de motifs en sélectionnant un graphe au
format ``.grf`` , et qu’Unitex y décèle une erreur, l’opération de
recherche sera automatiquement interrompue.

Contextes
---------

[section-contexts]

Les graphes d’Unitex sont des grammaires algébriques. Elles sont
également appelées grammaires hors-contexte, car lorsque l’on souhaite
reconnaître une séquence :math:`A`, on ne tient pas compte du contexte
dans lequel :math:`A` apparaît. Par exemple, il est impossible de
rechercher avec un graphe normal toutes les occurrences du mot
``president``, sauf celles qui sont suivies par ``of the republic``.

Il est toutefois possible de tenir compte du contexte dans les graphes
syntaxiques. Dans ce cas, les graphes ne sont plus des grammaires
algébriques, mais des grammaires contex- tuelles qui n’ont pas les mêmes
propriétés théoriques. .

Contextes droits
~~~~~~~~~~~~~~~~

On définit un contexte droit en délimitant une zone du graphe avec des
boîtes contenant ``$[`` and ``$]``, représentant respectivement les
début et fin de contexte qui sont représentés dans le graphe par des
crochets verts. Le début et la fin d’un contexte doivent apparaître dans
le même graphe.

.. figure:: resources/img/fig6-12.png
   :alt: Utilisation d’un contexte droit[fig-context1]
   :width: 7.40000cm

   Utilisation d’un contexte droit[fig-context1]

La figure [fig-context1] montre un exemple simple de contexte. Ce graphe
reconnaît tous les nombres qui sont suivis par l’euro, la livre ou le
dollar, mais sans que le symbole d’unité n’apparaisse dans les
occurrences trouvées, c’est-à-dire dans la concordance.

Les contextes s’interprètent de la façon suivante. Supposons que l’on
rencontre un début de contexte lors de l’application d’une grammaire à
un texte, et notons :math:`pos` la position courante dans le texte à cet
instant. Le programme ``Locate`` va ensuite chercher à reconnaître
l’expression décrite dans le contexte. S’il échoue, il n’y aura pas de
match. S’il réussit, c’est- à-dire s’il peut atteindre la fin du
contexte, le programme reviendra à la position :math:`pos` dans le texte
et continuera l’exploration de la grammaire à partir de la fin du
contexte.

Les poids (section [Transducers]) dans les contextes droits sont
ignorés.

On peut également définir des contextes droits négatifs, en utilisant
``$![`` comme début de contexte. La figure [fig-context2] montre un
graphe reconnaissant des nombres qui ne sont pas suivis par ``th``. La
différence avec les contextes positifs est que lorsque ``Locate`` essaie
de reconnaître l’expression décrite dans le contexte, le fait
d’atteindre la fin du contexte est considéré comme un échec, car cela
signifie que l’on a reconnu une séquence interdite. À l’inverse, si la
fin de contexte ne peut être atteinte, le programme ``Locate`` reviendra
à la position :math:`pos` dans le texte et continuera l’exploration de
la grammaire à partir de la fin du contexte.

.. figure:: resources/img/fig6-13.png
   :alt: Utilisation d’un contexte négatif[fig-context2]
   :width: 7.30000cm

   Utilisation d’un contexte négatif[fig-context2]

Les contextes peuvent être placés n’importe où dans le graphe, y compris
au début. La figure [fig-context3] montre ainsi un graphe qui reconnaît
un adjectif dans le contexte de quelque chose qui n’est pas un participe
passé. Autrement dit, ce graphe reconnaît tous les adjectifs qui ne sont
pas ambigus avec des participes passés.

.. figure:: resources/img/fig6-14.png
   :alt: Recherche d’un adjectif non ambigu avec un participe
   passé[fig-context3]
   :width: 7.50000cm

   Recherche d’un adjectif non ambigu avec un participe
   passé[fig-context3]

Dans les graphes tels que celui de la figure [fig-context3], le contexte
droit négatif ne vérifie pas nécessairement le même nombre de tokens que
la boite qui le suit. Par exemple, avant que le graphe de la
figure [too-also] ne reconnaisse ``too``, le contexte droit négatif
vérifie s’il apparait dans une expression telle que ``too early`` ou
``too many``.

.. figure:: resources/img/fig-too-also.png
   :alt: Un contexte qui ne vérifie pas le même nombre de mots que la
   boite qui le suit[too-also]
   :width: 7.50000cm

   Un contexte qui ne vérifie pas le même nombre de mots que la boite
   qui le suit[too-also]

On peut formuler des requêtes complexes avec les contextes droits
négatifs. Ainsi, la figure  [fig-context4] montre un graphe qui
reconnaît toutes les séquences de deux noms simples qui ne sont pas
ambiguës avec des mots composés. En effet, le motif
``<CDIC><<^([^ ]+ [^ ]+)$>>`` reconnaît un mot composé contenant
exactement un espace, et le motif ``<N><<^([^ ]+)$>>`` reconnaît un nom
sans espace, c’est-à-dire un nom simple. Ainsi, dans la phrase *Black
cats should like the town hall*, ce graphe reconnaîtra *Black cats*,
mais pas *town hall*, qui est un mot composé.

.. figure:: resources/img/fig6-15.png
   :alt: Utilisation avancée des contextes[fig-context4]
   :width: 8.90000cm

   Utilisation avancée des contextes[fig-context4]

Il est possible d’imbriquer des contextes. Par exemple, le graphe de la
figure [fig-context5] reconnaît un nombre qui n’est pas suivi par un
point, sauf si ce point est suivi par un nombre. Ainsi, dans le texte
*5.0+7.=12*, ce graphe reconnaîtra *5*, *0* et *12*.

.. figure:: resources/img/fig6-16.png
   :alt: Imbrication de contextes[fig-context5]
   :width: 12.00000cm

   Imbrication de contextes[fig-context5]

Les sorties qui se trouvent dans des boîtes à l’intérieur d’un contexte
sont ignorées. En revanche, il est possible d’utiliser une variable qui
a été définie dans un contexte, comme c’est le cas sur la figure
 [fig-context6]). Si l’on applique ce graphe en mode MERGE au texte *the
cat is white*, on obtient en sortie :

``the is white``

.. figure:: resources/img/fig6-17.png
   :alt: Variable définie dans un contexte[fig-context6]
   :width: 12.20000cm

   Variable définie dans un contexte[fig-context6]

Contextes gauches
~~~~~~~~~~~~~~~~~

Il est également possible de rechercher une expression :math:`X` si elle
se trouve seulement après une expression :math:`Y`. Évidemment, il était
déjà possible de le faire avec une grammaire semblable à celle de la
figure [fig-left-context1]. Cependant, avec ce type de grammaire, le
contexte gauche est inclus dans la séquence reconnue, comme le montre la
figure [fig-left-context2].

.. figure:: resources/img/fig6-17a.png
   :alt: Reconnaissance d’un nom précédé d’un déterminant
   numéral[fig-left-context1]
   :width: 7.00000cm

   Reconnaissance d’un nom précédé d’un déterminant
   numéral[fig-left-context1]

.. figure:: resources/img/fig6-17b.png
   :alt: Résultats de l’application de la grammaire de la figure
   [fig-left-context1][fig-left-context2]
   :width: 14.00000cm

   Résultats de l’application de la grammaire de la figure
   [fig-left-context1][fig-left-context2]

Pour éviter cela, on peut utiliser le symbole ``$*`` qui indique la fin
du contexte gauche de l’expression qu’on désire reconnaître. Ce symbole
est représenté par une étoile verte dans le graphe, comme le montre la
figure [fig-left-context3]. L’effet d’un tel contexte est d’utiliser une
partie de la grammaire pour calculer la séquence reconnue, sans que
cette partie ne figure dans le résultat (voir
figure [fig-left-context4]).

.. figure:: resources/img/fig6-17c.png
   :alt: Reconnaissance d’un nom après un contexte
   gauche[fig-left-context3]
   :width: 9.00000cm

   Reconnaissance d’un nom après un contexte gauche[fig-left-context3]

.. figure:: resources/img/fig6-17d.png
   :alt: Résultats de l’application de la grammaire de la figure
   [fig-left-context3][fig-left-context4]
   :width: 14.00000cm

   Résultats de l’application de la grammaire de la figure
   [fig-left-context3][fig-left-context4]

Toutes les sorties produites par un contexte gauche sont ignorées, comme
on peut le voir dans la concordance de la figure [fig-left-context6],
qui donne les résultats obtenus avec la grammaire de la figure
[fig-left-context5].

.. figure:: resources/img/fig6-17e.png
   :alt: Sorties ignorées dans un contexte gauche[fig-left-context5]
   :width: 9.00000cm

   Sorties ignorées dans un contexte gauche[fig-left-context5]

.. figure:: resources/img/fig6-17f.png
   :alt: Résultats de l’application de la grammaire de la figure
   [fig-left-context5][fig-left-context6]
   :width: 15.00000cm

   Résultats de l’application de la grammaire de la figure
   [fig-left-context5][fig-left-context6]

Toutefois, on peut mémoriser des informations avec des variables (voir
section [section-variables]) et les utiliser en dehors du contexte
gauche, comme le montrent la grammaire de la figure [fig-left-context7]
et son résultat dans la figure [fig-left-context8].

.. figure:: resources/img/fig6-17g.png
   :alt: Utilisation d’une variable dans un contexte
   gauche[fig-left-context7]
   :width: 10.00000cm

   Utilisation d’une variable dans un contexte gauche[fig-left-context7]

.. figure:: resources/img/fig6-17h.png
   :alt: Résultats de l’application de la grammaire de la figure
   [fig-left-context7][fig-left-context8]
   :width: 15.00000cm

   Résultats de l’application de la grammaire de la figure
   [fig-left-context7][fig-left-context8]

On peut invoquer dans une grammaire un graphe qui contient des contextes
gauches, mais cela nécessite d’être vigilant. Au moment où le contexte
gauche est exclu de la séquence reconnue, toutes les séquences qui
avaient été reconnues par des graphes appelants en sont exclues
également, car la séquence qui sera finalement reconnue devra être
contiguë. Les sorties correspondant aux séquences exclues sont ignorées
elles aussi.

Ainsi, avec des contextes gauche et droit, on peut faire une distinction
entre les motifs utilisés pour reconnaître des points du texte, et la
délimitation des séquences à extraire dans les résultats. Par exemple,
la grammaire de la figure [fig-left-context9] cherche des expressions
comme ``the animal's``, mais extrait seulement les noms, comme on peut
le voir figure [fig-left-context10].

.. figure:: resources/img/fig6-17i.png
   :alt: Une grammaire avec des contextes gauche et
   droit[fig-left-context9]
   :width: 10.00000cm

   Une grammaire avec des contextes gauche et droit[fig-left-context9]

.. figure:: resources/img/fig6-17j.png
   :alt: Résultats de l’application de la grammaire de la figure
   [fig-left-context9][fig-left-context10]
   :width: 15.00000cm

   Résultats de l’application de la grammaire de la figure
   [fig-left-context9][fig-left-context10]

Les poids (section [Transducers]) fonctionnent normalement dans les
contextes gauches.

Le mode morphologique
---------------------

Pourquoi ?
~~~~~~~~~~

Comme Unitex fonctionne sur une version “tokenisée” du texte, il n’est
pas possible de faire des requêtes qui entrent à l’intérieur des
“tokens”, sauf avec les filtres morphologiques (voir section
[section-filters]), comme le montre la figure [fig-morpho1].

.. figure:: resources/img/fig6-17k.png
   :alt: Reconnaissance d’éléments morphologiques[fig-morpho1]
   :width: 7.00000cm

   Reconnaissance d’éléments morphologiques[fig-morpho1]

Cependant, les filtres morphologiques ne permettent pas n’importe quelle
requête, puisqu’ils ne peuvent pas faire référence aux informations
contenues dans les dictionnaires. Ainsi, il est impossible de formuler
de cette manière une requête comme “*un mot constitué du préfixe* ``un``
*suivi d’un adjectif en* ``able``”.

Pour surmonter cette difficulté, nous introduisons un mode morphologique
dans le programme ``Locate``. Il consiste à délimiter une partie de
votre grammaire avec les symboles ``$<`` et ``$>``. Dans cette zone, les
données sont reconnues lettre par lettre, comme le montre la figure
[fig-morpho2].

.. figure:: resources/img/fig6-17l.png
   :alt: Exemple de zone morphologique dans la grammaire[fig-morpho2]
   :width: 11.00000cm

   Exemple de zone morphologique dans la grammaire[fig-morpho2]

Les règles
~~~~~~~~~~

Dans ce mode, le contenu du graphe n’est pas interprété de manière
habituelle.

#. Il n’y a pas d’espace entre les boîtes. Ainsi, si on désire
   reconnaître un espace, on doit le rendre explicite avec ``" "`` (un
   espace entre guillemets).

#. On peut toujours utiliser des sous-graphes, mais la fin de la zone
   morphologique doit se trouver dans le même graphe que son début.

#. On peut utiliser des masques lexicaux qui nécessitent la consultation
   d’un dictionnaire — comme ``<DIC>`` , ``<be>`` ou ``<N:ms>``, qui
   font référence aux informations contenues dans un dictionnaire —, du
   moment qu’il a été préalablement déclaré comme dictionnaire du mode
   morphologique (voir section [dic-mode-morpho]).

#. On peut utiliser des masques lexicaux qui nécessitent la consultation
   d’un graphe-dictionnaire (section [section-dictionary-graphs]), du
   moment que le nom du graphe-dictionnaire contient l’option ``b``.
   Cependant, cette possibilité ne fonctionne que pour les formes
   reconnues dans le texte par le graphe-dictionnaire pendant
   l’application initiale des dictionnaires
   (section [section-applying-dictionaries]), et non pour les formes qui
   n’apparaissent dans le texte que comme des parties de tokens.

#. On peut utiliser des filtres morphologiques
   (section [section-filters]). Cependant, les filtres morphologiques
   employés seuls ou sur ``<TOKEN>`` ne s’appliqueront seulement qu’au
   caractère courant. Par conséquent, les filtres comme
   ``<<[1-9][0-9]>>`` qui sont conçus pour reconnaître plus d’un
   caractère ne reconnaîtront jamais rien. En fait, dans le mode
   morphologique, les filtres morphologiques ne sont utiles que pour
   exprimer des négations comme ``<<[^aeiouy]>>`` (n’importe quel
   caractère qui n’est pas une voyelle).

#. Les contextes gauches et droits au sens de la
   section [section-contexts] sont interdits.

#. On peut utiliser des sorties.

#. ``<LETTER>`` reconnaît n’importe quelle lettre définie dans le
   fichier alphabet.

#. ``<LOWER>`` reconnaît n’importe quelle minuscule définie dans le
   fichier alphabet.

#. ``<UPPER>`` reconnaît n’importe quelle majuscule définie dans le
   fichier alphabet.

#. ``<DIC>`` reconnaît n’importe quel mot présent dans un dictionnaire
   du mode morphologique, mais les méta-symboles ``#``, ``<FIRST>``,
   ``<NB>``, ``<SDIC>`` et\ ``<CDIC>`` sont interdits.

#. Si on atteint la fin de la zone sans être à la fin du token, la
   reconnaissance échoue. Par exemple, si le texte contient ``enabled``,
   on ne peut pas reconnaître seulement ``enable``.

Les anciens codes correspondant à ``<LETTER>``, ``<LOWER>`` et
``<UPPER>`` étaient respectivement ``<MOT>``, ``<MIN>`` et ``<MAJ>``.
Ils restent opérationnels afin de conserver la compatibilité descendante
du système avec les graphes existants. Même s’il n’est pas prévu de
supprimer ces codes, on recommande de les éviter dans les graphes conçus
pour fonctionner avec les versions plus récentes [1]_, pour ne pas faire
augmenter inutilement le nombre de masques lexicaux en usage.

Dictionnaires du mode morphologique
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

[dic-mode-morpho] Dans le mode morphologique, on peut faire des requêtes
qui utilisent les dictionnaires. Par exemple, la grammaire de la figure
[fig-morpho3] cherche les mots constitués du préfixe ``un`` suivi d’un
adjectif.

.. figure:: resources/img/fig6-17m.png
   :alt: Reconnaissance des mots constitués de *un* et d’un adjectif en
   *able*\ [fig-morpho3]
   :width: 11.00000cm

   Reconnaissance des mots constitués de *un* et d’un adjectif en
   *able*\ [fig-morpho3]

.. figure:: resources/img/fig6-17n.png
   :alt: Déclaration des dictionnaires du mode
   morphologique[fig-morpho4]
   :width: 11.00000cm

   Déclaration des dictionnaires du mode morphologique[fig-morpho4]

Pour pouvoir reconnaître le mot ``unaware`` avec cette grammaire, le
système doit savoir que ``aware`` est un adjectif. Le masque lexical
``<A>`` nécessite la consultation d’un dictionnaire. Mais ``aware`` peut
ne pas être présent dans le texte, de sorte qu’on ne peut pas compter
sur les dictionnaires du texte [2]_. C’est la raison pour laquelle on
doit définir une liste de dictionnaires à consulter en mode
morphologique. Pour ce faire, on va dans
“Info>Preferences>Morphological-mode dictionaries”
(figure [fig-morpho4]). On peut définir autant de dictionnaires du mode
morphologique qu’on veut, mais ils doivent être au format ``.bin``. Ceci
fait, on peut appliquer la grammaire. Pour spécifier qu’un
graphe-dictionnaire doit être consulté lorsqu’on est en mode
morphologique, on utilise l’option ``b`` ou ``z``
(section [section-dictionary-graphs], Exporter les entrées produites
comme dictionnaire du mode morphologique).

Variables de dictionnaire
~~~~~~~~~~~~~~~~~~~~~~~~~

[dictionary-variables] On peut affecter à des variables des informations
issues des dictionnaires du mode morphologique. Ces variables sont
appelées variables de dictionnaire ou variables morphologiques.
L’initialisation d’une variable de ce type doit être associée à une
boite contenant un motif qui fait référence à des informations contenues
dans un dictionnaire du mode morphologique, à l’exception du motif
``<DIC>``. On met ``$xxx$`` en sortie de la boîte, où ``xxx`` est un nom
correct de variable (cf. section [section-using-variables]). Ceci
affecte à une variable dénommée ``xxx`` l’entrée de dictionaire reconnue
par le motif. Dans la suite des chemins qui passent par la boite, on
peut obtenir la forme fléchie, la forme canonique et les codes fournis
par l’entrée avec ``$xxx.INFLECTED$``, ``$xxx.LEMMA$`` et
``$xxx.CODE$``, comme le montre la figure [fig-morpho5]. On peut
également utiliser les motifs suivants:

-  ``$xxx.CODE.GRAM$``: fournit seulement le premier code grammatical,
   censé être la catégorie grammaticale

-  ``$xxx.CODE.SEM$``: fournit tous les autres codes, séparés par des
   ``+``, s’il en existe

-  ``$xxx.CODE.FLEX$``: fournit tous les codes flexionnels séparés par
   des ``:``, s’il en existe

-  ``$xxx.CODE.ATTR=yyy$`` renvoie la valeur d’une paire attribut-valeur
   contenue dans les codes sémantiques, c’est-à-dire la valeur ``zzz``
   de l’attribut ``yyy`` s’il y figure un code sémantique de la forme
   ``yyy=zzz``.

Les variables de dictionnaire peuvent être utilisées en dehors du mode
morphologique, comme sur la figure [fig-morpho7]. On peut effectuer des
tests sur ces variables comme expliqué dans la section
[section-variables].

.. figure:: resources/img/fig6-17o.png
   :alt: Utilisation d’une variable de dictionnaire[fig-morpho5]
   :width: 16.00000cm

   Utilisation d’une variable de dictionnaire[fig-morpho5]

.. figure:: resources/img/fig6-17p.png
   :alt: Résultats de la grammaire de la figure [fig-morpho5] appliquée
   en mode in MERGE [fig-morpho6]
   :width: 15.00000cm

   Résultats de la grammaire de la figure [fig-morpho5] appliquée en
   mode in MERGE [fig-morpho6]

.. figure:: resources/img/fig6-17q.png
   :alt: Utilisation d’une variable de dictionnaire en mode
   normal[fig-morpho7]
   :width: 15.50000cm

   Utilisation d’une variable de dictionnaire en mode
   normal[fig-morpho7]

**Variables de dictionnaire dans LocateTfst**

Pour les grammaires appliquées avec ``LocateTfst`` (cf.
section [section-locate-tfst]), on dispose d’une possibilité
supplémentaire. En dehors du mode morphologique, on peut mémoriser dans
une variable de dictionnaire une étiquette lexicale contenue dans
l’automate du texte. Il suffit pour cela d’associer à la boîte une
sortie de la forme ``$:abc$`` où ``abc`` est le nom de la variable. On
peut ensuite l’utiliser comme variable de dictionnaire habituelle, de la
façon décrite ci-dessus : on peut obtenir la forme fléchie, la forme
canonique et les codes donnés dans l’entrée, sa catégorie grammaticale,
ses codes sémantiques, ses codes flexionnels et la valeur ``zzz`` de
l’attribut ``yyy`` s’il y figure un code sémantique de la forme
``yyy=zzz``.

Exploration des chemins d’une grammaire
---------------------------------------

Il est possible de générer les chemins reconnus par une grammaire, par
exemple pour vérifier qu’elle engendre correctement les formes
attendues. Pour cela, ouvrez le graphe principal de votre grammaire et
assurez-vous que la fenêtre du graphe est bien la fenêtre active (la
fenêtre active possède une barre de titre bleu, tandis que les fenêtres
inactives ont une barre de titre grise). Allez ensuite dans le menu
“FSGraph”, puis dans le sous-menu “Tools”, et cliquez sur “Explore graph
paths”. La fenêtre de la figure  [fig-explore-graph-paths] apparaît
alors.

.. figure:: resources/img/fig6-18.png
   :alt: Exploration des chemins d’une
   grammaire[fig-explore-graph-paths]
   :width: 10.40000cm

   Exploration des chemins d’une grammaire[fig-explore-graph-paths]

Le cadre supérieur contient le nom du graphe principal de la grammaire à
explorer. Les options suivantes concernent la gestion des sorties de la
grammaire ainsi que le mode d’exploration:

-  “Ignore outputs”: les sorties sont ignorées;

-  “Separate inputs and outputs”: les sorties sont affichées groupées
   après les entrées (`` a b c / A B C``);

-  “Merge inputs and outputs”: chaque sortie est affichée immédiatement
   après l’entrée qui lui correspond (``a/A b/B c/C``).

-  “Only paths”: les appels aux sous-graphes sont explorés
   récursivement;

-  “Do not explore subgraphs recursively”: les appels aux sous-graphes
   sont affichés sans être explorés récursivement.

Si l’option “Maximum number of sequences” est cochée, le nombre spécifié
sera le nombre maximum de chemins générés. Si l’option n’est pas
sélectionnée, tous les chemins seront générés.

Voici ce que l’on obtient pour le graphe de la figure  [fig-glace] avec
les paramètres par défaut (ignorer les sorties, limite = 100 chemins) :

``<NB> <boule> de glace à la pistache``

``<NB> <boule> de glace à la fraise``

``<NB> <boule> de glace à la vanille``

``<NB> <boule> de glace vanille``

``<NB> <boule> de glace fraise``

``<NB> <boule> de glace pistache``

``<NB> <boule> de pistache``

``<NB> <boule> de fraise``

``<NB> <boule> de vanille``

``glace à la pistache``

``glace à la fraise``

``glace à la vanille``

``glace vanille``

``glace fraise``

``glace pistache``

.. figure:: resources/img/fig6-19.png
   :alt: Exemple de graphe [fig-glace]
   :width: 10.90000cm

   Exemple de graphe [fig-glace]

Collection de graphes
---------------------

Il peut arriver que l’on souhaite appliquer plusieurs grammaires situées
dans un même répertoire. Pour cela, il est possible de construire
automatiquement une grammaire à partir d’une arborescence de fichiers.
Supposons par exemple que l’on ait l’arborescence suivante:

-  *Dicos*:

   -  *Banque*:

      -  ``carte.grf``

   -  *Nourriture*:

      -  ``eau.grf``

      -  ``pain.grf``

   -  ``truc.grf``

Si l’on veut rassembler toutes ces grammaires en une seule, on peut le
faire avec la commande “Build Graph Collection” dans le sous-menu
“FSGraph > Tools”. On configure cette opération au moyen de la fenêtre
de la figure  [fig-build-graph-collection].

.. figure:: resources/img/fig6-20.png
   :alt: Construction d’une collection de
   graphes[fig-build-graph-collection]
   :width: 9.00000cm

   Construction d’une collection de graphes[fig-build-graph-collection]

Dans le champ “Source directory”, sélectionnez le répertoire racine que
vous voulez explorer (dans notre exemple, le répertoire *Dicos*). Dans
le champ “Resulting GRF grammar”, indiquez le nom de la grammaire
produite.

ATTENTION : ne placez pas la grammaire de sortie dans l’arborescence que
vous voulez explorer, car dans ce cas, le programme va chercher à lire
et à écrire simultanément dans ce fichier, ce qui provoquera un
plantage.

Lorsque vous cliquerez sur “OK”, le programme recopiera les graphes dans
le répertoire de la grammaire de sortie, et créera des sous-graphes
correspondant aux différents sous-répertoires, comme on peut le voir sur
la figure [fig-graph-collection], qui montre le graphe de sortie
engendré pour notre exemple.

On peut constater qu’une boîte contient les appels à des sous-graphes
correspondant à des sous-répertoires (ici les répertoires *Banque* et
*Nourriture*), et que l’autre boîte fait appel à tous les graphes qui se
trouvaient dans le répertoire (ici le graphe ``truc.grf``).

.. figure:: resources/img/fig6-21.png
   :alt: Graphe principal d’une collection de
   graphes[fig-graph-collection]
   :width: 11.00000cm

   Graphe principal d’une collection de graphes[fig-graph-collection]

Règles d’application des transducteurs
--------------------------------------

Cette section décrit les règles d’application des transducteurs lors des
opérations de pré- traitement et de recherche de motifs. Les graphes de
flexion et de normalisation de formes ambiguës ne sont pas concernés par
ce qui suit.

Insertion à gauche du motif reconnu
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Lorsqu’un transducteur est appliqué en mode REPLACE, les sorties
remplacent les séquences lues dans le texte. En mode MERGE, les sorties
sont insérées à gauche des séquences reconnues. Considérons le
transducteur de la figure [fig-transducer-example] .

.. figure:: resources/img/fig6-22.png
   :alt: Exemple de transducteur[fig-transducer-example]
   :width: 7.20000cm

   Exemple de transducteur[fig-transducer-example]

Si l’on applique ce transducteur au roman *Ivanhoe* by Sir Walter Scott
en mode MERGE, on obtient la concordance de la
figure [fig-transducer-example-concordance]

.. figure:: resources/img/fig6-23.png
   :alt: Concordance obtenue en mode MERGE avec le transducteur de la
   figure  [fig-transducer-example][fig-transducer-example-concordance]
   :width: 14.40000cm

   Concordance obtenue en mode MERGE avec le transducteur de la figure
    [fig-transducer-example][fig-transducer-example-concordance]

Application en avançant
~~~~~~~~~~~~~~~~~~~~~~~

Pendant les opérations de prétraitement, le texte est modifié au fur et
à mesure qu’il est parcouru. Afin d’éviter le risque de boucler
indéfiniment, il ne faut pas que les séquences produites par un
transducteur puissent être ré-analysées par celui-ci. Pour cette raison,
quand une séquence a été introduite dans le texte, l’application du
transducteur se poursuit après cette séquence. Cette règle ne concerne
que les transducteurs de prétraitement, car lors de l’application de
graphes syntaxiques, les sorties ne modifient pas le texte parcouru,
mais un fichier de concordances distinct du texte.

Priorité à gauche
~~~~~~~~~~~~~~~~~

Lors de l’application d’une grammaire locale, les occurrences qui se
chevauchent sont toutes indexées. Nous considérons, ici, de vrai
chevauchements d’occurrence comme ``abc`` et ``bcd``, et pas
d’occurrences imbriquées comme ``abc`` et ``bc``. Lors de la
construction de la concordance, toutes ces occurrences sont présentées
(voir figure [fig-overlappping-occurrences]).

.. figure:: resources/img/fig6-24.png
   :alt: Occurrences se chevauchant dans une
   concordance[fig-overlappping-occurrences]
   :width: 13.00000cm

   Occurrences se chevauchant dans une
   concordance[fig-overlappping-occurrences]

En revanche, si vous modifiez le texte au lieu de construire une
concordance, il est nécessaire de choisir parmi ces occurrences
lesquelles seront prises en compte. Pour cela, Unitex applique la règle
de priorité suivante : la séquence la plus à gauche l’emporte.

Si l’on applique cette règle aux trois occurrences de la concordance
précédente, l’occurrence est concurrente avec . C’est donc la première
qui est retenue car c’est l’occurrence la plus à gauche, et est
éliminée. L’occurrence suivante n’est donc plus en conflit avec et peut
donc apparaître dans le résultat:

``...Don, there extended large forest...``

La règle de priorité à gauche s’applique uniquement lorsque le texte est
modifié, soit lors du prétraitement, soit après l’application d’un
graphe syntaxique (voir section  [section-modifying-text]).

Priorité aux séquences les plus longues
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Lors de l’application d’un graphe syntaxique, il est possible de choisir
si la priorité doit être donnée aux séquences les plus courtes ou les
plus longues, ou si toutes les séquences doivent être retenues. Lors des
opérations de prétraitement, la priorité est toujours donnée aux
séquences les plus longues.

Sorties à variables
~~~~~~~~~~~~~~~~~~~

Comme nous l’avons vu à la section [section-using-variables], il est
possible d’utiliser des variables d’entrée pour mémoriser le texte qui a
été analysé par une grammaire. Ces variables peuvent être utilisées dans
les graphes de prétraitement et dans les graphes syntaxiques.

On doit donner des noms aux variables qu’on utilise. Ces noms peuvent
contenir les lettres comprises entre ``A`` et ``Z``, non accentuées
minuscules ou majuscules, des chiffres et le caractère ``_``
(underscore).

Pour définir le début et la fin de la zone à stocker dans une variable
d’entrée, soit on utilise le bouton avec les parenthèses rouges dans la
barre d’icônes au-dessus du graphe (section  [toolbar-commands]), soit
on crée deux boîtes, l’une contenant le nom de la variable encadré par
les caractères ``$`` et ``(`` pour le début de la zone, et l’autre par
``$`` et ``)`` pour la fin. Pour utiliser une variable dans une sortie,
on fait précéder et suivre son nom du caractère ``$`` (voir
figure [fig-variable-definition]).

Les variables sont globales. Cela signifie qu’on peut définir une
variable dans un graphe et l’appeler dans un autre, comme l’illustrent
les graphes de la figure  [fig-variable-definition]. Si on applique le
graphe ``TitleName`` en mode MERGE au texte *Ivanhoe*, on obtient la
concordance de la figure  [fig6-14].

Les sorties à variables peuvent être utilisées pour déplacer des groupes
de mots. En effet, l’application d’un transducteur en mode REPLACE
n’écrit dans le texte que les séquences produites par des sorties. Pour
intervertir deux groupes de mots, il suffit donc de les stocker dans des
variables et de produire une sortie avec ces variables dans l’ordre
souhaité. Ainsi, le transducteur de la figure [fig-swapping-words]
appliqué en mode REPLACE au texte *Ivanhoe* donne la concordance de la
figure [fig-no-space-problem].

.. figure:: resources/img/fig6-25.pdf
   :alt: Définition d’une variable d’entrée dans un
   sous-graphe[fig-variable-definition]
   :width: 16.00000cm

   Définition d’une variable d’entrée dans un
   sous-graphe[fig-variable-definition]

.. figure:: resources/img/fig6-26.png
   :alt: Concordance obtenue par l’application du graphe
   ``TitleName``\ [fig6-14] de la fig. [fig-variable-definition]
   :width: 13.00000cm

   Concordance obtenue par l’application du graphe
   ``TitleName``\ [fig6-14] de la fig. [fig-variable-definition] 

.. figure:: resources/img/fig6-27.png
   :alt: Interversion de mots grâce à deux variables
   d’entrée[fig-swapping-words]
   :width: 11.30000cm

   Interversion de mots grâce à deux variables
   d’entrée[fig-swapping-words]

.. figure:: resources/img/fig6-28.png
   :alt: Résultat de l’application du transducteur de la
   figure [fig-swapping-words][fig-no-space-problem]
   :width: 13.40000cm

   Résultat de l’application du transducteur de la
   figure [fig-swapping-words][fig-no-space-problem]

Si le début ou la fin d’une variable est mal défini (fin d’une variable
avant son début, absence du début ou de la fin d’une variable), celle-ci
sera ignorée lors des sorties. Consultez la section
[section-advanced-search-options] pour d’autres options affectant le
traitement d’erreurs concernant les variables.

Il n’y a aucune limite au nombre de variables utilisables.

Les variables d’entrées peuvent être imbriquées, et même se chevaucher
comme le montre la figure [fig-overlapping-variables].

.. figure:: resources/img/fig6-29.png
   :alt: Chevauchement de variables d’entrée[fig-overlapping-variables]
   :width: 15.00000cm

   Chevauchement de variables d’entrée[fig-overlapping-variables]

Variables de sortie
-------------------

Les variables d’entrée sont déclarées soit avec les parenthèses rouges
de la barre d’icônes, soit avec ``$xxx(`` et ``$xxx)``, et mémorisent
des portions du texte d’entrée. Il est aussi possible de mémoriser des
parties des sorties produites par une grammaire. Cela met en jeu des
variables de sortie. Ces variables sont déclarées soit avec l’icône des
parenthèses bleues dans la barre d’icônes au-dessus du graphe (section
 [toolbar-commands]), soit avec ``$|xxx(`` et ``$|xxx)``. Elles
apparaissent en bleu (voir figure [fig-output-variables]). Cette
grammaire appliquée en mode MERGE au texte *Ivanhoe* produit la
concordance visible sur la figure [fig-output-variables-concord].

.. figure:: resources/img/fig6-17r.png
   :alt: Variables de sortie[fig-output-variables]
   :width: 8.00000cm

   Variables de sortie[fig-output-variables]

.. figure:: resources/img/fig6-17s.png
   :alt: Concordances obtenues avec la grammaire de la figure
    [fig-output-variables][fig-output-variables-concord]
   :width: 15.00000cm

   Concordances obtenues avec la grammaire de la figure
    [fig-output-variables][fig-output-variables-concord]

Au moment où une variable de sortie est initialisée, les séquences de
sortie du transducteur ne sont pas émises dans la sortie correspondant à
l’occurrence courante, elles sont seulement mémorisées dans la variable
de sortie créée par cette opération. Par exemple, les sorties ``ADJ`` et
``NOUN`` de la figure figure [fig-output-variables] n’ont pas été
insérées à gauche du texte d’entrée dans la
figure [fig-output-variables-concord]. Par ailleurs, les sorties sont
traitées avant d’être mémorisées : si la sortie d’une boite contient une
chaine comme ``$A.LEMMA$``, la variable de sortie ne contiendra en fait
pas cette chaîne mais le lemme associé à la variable ``A``.

Les variables de sortie mémorisent seulement des sorties effectivement
produites par la grammaire. Ainsi, même en mode MERGE, les variables de
sortie ne mémorisent jamais le texte d’entrée
(figures [fig-output-variables] et [fig-output-variables-concord]).

Quand une boite redéfinit une variable qui avait déjà été définie, la
nouvelle valeur écrase l’ancienne. Ainsi, si la variable est définie
dans une boucle, la valeur de la variable juste après la boucle dépend
du dernier passage dans la boucle.

Opérations sur les variables
----------------------------

Tests sur les variables
~~~~~~~~~~~~~~~~~~~~~~~

Il est possible de tester si une variable est définie ou non, afin
d’interrompre la reconnaissance courante si la condition n’est pas
vérifiée. Ceci se fait en insérant la séquence ``$xxx.SET$`` dans la
sortie d’une boîte. Ainsi, si une variable dénommée ``xxx`` a été
définie, cette séquence est ignorée et la reconnaissance continue,
sinon, la reconnaissance s’arrête et le programme repart en arrière.
Ceci fonctionne sur les variables d’entrée, les variables de sortie et
les variables de dictionnaire. De façon similaire, on peut vérifier
qu’une variable n’est pas définie en utilisant ``$xxx.UNSET$``. La
figure [fig-testing-a-variable] montre un graphe qui utilise ce type de
test. La figure [fig-testing-a-variable-results] montre les résultats
obtenus par ce graphe en mode MERGE.

.. figure:: resources/img/fig6-29b.png
   :alt: Test d’une variable[fig-testing-a-variable]
   :width: 9.00000cm

   Test d’une variable[fig-testing-a-variable]

.. figure:: resources/img/fig6-29c.png
   :alt: Résultats d’un test de variable[fig-testing-a-variable-results]
   :width: 10.00000cm

   Résultats d’un test de variable[fig-testing-a-variable-results]

Comparaison de variables
~~~~~~~~~~~~~~~~~~~~~~~~

Il est également possible de comparer tout type de variable (d’entrée,
de sortie, ou de dictionnaire) avec une constante ou une autre variable.
Ceci se fait en insérant dans la sortie d’une boîte une séquence
respectant la syntaxe suivante :

``$abc.EQUAL=xyz$``

Cela agit comme un interrupteur qui permet de bloquer l’exploration de
grammaire si la valeur de la variable ``abc`` est différente de la
valeur de la variable ``xyz``. Remarquons que pour les variables de
dictionnaire, c’est la forme fléchie telle qu’elle existe dans le
dictionnaire (attention aux variantes de casse !) qui est utilisée pour
le test. Si vous désirez comparer la variable ``abc`` à la constante
``JKL``, utilisez le test suivant:

``$abc.EQUAL=#JKL$``

on peut également tester si le contenu est différent avec ``UNEQUAL``.

Si vous désirez comparer des variables en ignorant les variantes de
casse, vous pouvez utiliser les tests suivants:

| ``$abc.EQUALcC=xyz$``
| ou
| ``$abc.UNEQUALcC=xyz$``

Recherche d’un code sémantique dans une variable de dictionnaire
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

On peut chercher dans une variable de dictionnaire
(section [dictionary-variables]) un “code sémantique” au sens de la
section [section-DELAF-entry-syntax]. Pour cela, on insère dans la
sortie d’une boite une séquence respectant la syntaxe suivante :

``$abc.EQ=Conc$``

Ce test agit comme un interrupteur qui permet de bloquer l’exploration
de la grammaire si ``Conc`` ne figure pas parmi les “codes sémantiques”
de la variable de dictionnaire ``abc``. On peut chercher un seul code à
la fois dans une variable. Pour vérifier plusieurs codes, on met
plusieurs boites en série.

Cette fonctionnalité est utilisée pour de grandes grammaires de
graphes-dictionnaires morphologiques, en vue de dissocier dans des
boites distinctes la vérification d’un code grammatical et de “codes
sémantiques” qui viennent ensuite, comme dans
:raw-latex:`\cite{paumier_nam_2014}`, page 486. On teste le code
grammatical avec un masque lexical, puis on fait de même pour les codes
sémantiques en les cherchant dans la variable de dictionnaire
correspondante. Cette dissociation peut accélérer l’application des
graphes si :

-  tous les graphes sont invoqués directement ou indirectement depuis un
   même graphe principal,

-  le graphe principal est compilé et transformé en transducteur fini
   (voir section [flatten-section]),

-  la boite qui contient le masque lexical est commune à plus de chemins
   que celles qui cherchent les codes sémantiques dans la variable de
   dictionnaire [3]_.

Application des graphes aux textes
----------------------------------

Cette section concerne uniquement les graphes syntaxiques.

Configuration de la recherche
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Pour appliquer un graphe à un texte, vous devez ouvrir le texte, puis
cliquer sur “Locate Pattern...” dans le menu “Text” ou appuyer sur
<Ctrl+L>. Vous pouvez alors configurer votre recherche grâce à la
fenêtre de la figure  [fig-regexp-frame].

.. figure:: resources/img/fig6-30.png
   :alt: Fenêtre de recherche d’expressions[fig-regexp-frame]
   :width: 9.00000cm

   Fenêtre de recherche d’expressions[fig-regexp-frame]

Dans le cadre intitulé “Locate pattern in the form of”, choisissez
“Graph” et sélectionnez votre graphe en cliquant sur le bouton “Set”.
Vous pouvez choisir un graphe au format ``.grf`` (Unicode Graphs) ou un
graphe compilé au format ``.fst2`` format (Unicode Compiled Graphs). Si
votre graphe est au format ``.grf``, Unitex le compilera automatiquement
avant de lancer la recherche. Si vous cliquez sur “Activate debug mode”,
la concordance sera affichée dans une fenêtre dans laquelle vous
trouverez l’automate et, pour chaque séquence reconnue, la liste des
états du chemin qui la reconnaît. Cette fenêtre est décrite en détails à
la section [section-debug-mode].

Le cadre “Index” permet de sélectionner le mode de reconnaissance:

-  “Shortest matches” : donne la priorité aux séquences les plus
   courtes;

-  “Longest matches” : donne la priorité aux séquences les plus longues.
   C’est le mode utilisé par défaut;

-  “All matches” : donne toutes les séquences reconnues.

Le cadre “Search limitation” permet de limiter ou non la recherche à un
certain nombre d’occurrences. Par défaut, la recherche est limitée aux
200 premières occurrences.

Le cadre “Grammar outputs” concerne le mode d’utilisation des sorties.
Le mode “Merge with input text” permet d’insérer les séquences produites
par les sorties. Le mode “Replace recognized sequences” permet de
remplacer les séquences reconnues par les séquences produites. Le
troisième mode ignore les sorties. Ce dernier mode est utilisé par
défaut.

Dans le cadre “Search algorithm”, vous pouvez spécifier si vous voulez
effectuer la recherche sur le texte en utilisant le programme Locate ou
sur l’automate du texte avec LocateTfst. Par défaut, la recherche est
faite avec le programme Locate, comme Unitex l’a toujours fait jusqu’à
maintenant. Si vous désirez utiliser LocateTfst, lisez la
section [section-locate-tfst].

Une fois vos paramètres fixés, cliquez sur “SEARCH” pour lancer la
recherche.

Options de recherche avancées
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

[section-advanced-search-options] Si vous sélectionnez l’onglet
“Advanced options”, vous voyez le cadre de la figure
[fig6-advanced-options1].

.. figure:: resources/img/fig6-advanced-options1.png
   :alt: Options de recherche avancées[fig6-advanced-options1]
   :width: 9.00000cm

   Options de recherche avancées[fig6-advanced-options1]

L’option “Ambiguous output policy” est illustrée par le graphe de la
figure [fig6-advanced-options2]. Lorsqu’un déterminant est suivi par un
mot pouvant être un nom ou un adjectif, il peut produire deux sorties
distinctes pour la même séquence d’entrée (le transducteur est dit
ambigu).

.. figure:: resources/img/fig6-advanced-options2.png
   :alt: Graphe avec des sorties ambiguës[fig6-advanced-options2]
   :width: 9.00000cm

   Graphe avec des sorties ambiguës[fig6-advanced-options2]

Si nous appliquons ce graphe sur le texte *Ivanhoe* avec l’option "Allow
ambiguous outputs” (celle par défaut), nous obtenons la concordance de
la figure [fig6-advanced-options3]. Comme vous pouvez le constater, deux
sorties sont produites pour la séquence *the noble*.

.. figure:: resources/img/fig6-advanced-options3.png
   :alt: Sorties ambiguës pour *the noble*\ [fig6-advanced-options3]
   :width: 8.80000cm

   Sorties ambiguës pour *the noble*\ [fig6-advanced-options3]

A l’opposé, avec l’option “Forbid ambiguous outputs”, nous obtenons la
concordance de la figure [fig6-advanced-options4], avec seulement une
sortie choisie arbitrairement pour la séquence *the noble*.

.. figure:: resources/img/fig6-advanced-options4.png
   :alt: Sortie unique *the noble*\ [fig6-advanced-options4]
   :width: 9.00000cm

   Sortie unique *the noble*\ [fig6-advanced-options4]

L’option “Variable error policy” permet de définir le comportement de
``Locate``/``LocateTfst`` lorsqu’ils rencontrent une sortie contenant
une variable mal définie. Remarquons que ce paramètre n’a aucun effet si
les sorties sont ignorées. Considérons par exemple le graphe de la
figure [fig6-advanced-options5].

.. figure:: resources/img/fig6-advanced-options5.png
   :alt: Une variable *A* qui peut être indéfinie
   [fig6-advanced-options5]
   :width: 9.00000cm

   Une variable *A* qui peut être indéfinie [fig6-advanced-options5]

Avec l’option “Ignore variable errors”, *A* est ignorée, comme si son
contenu était vide, comme le montre la figure [fig6-advanced-options6].

.. figure:: resources/img/fig6-advanced-options6.png
   :alt: La variable *A* peut être indéfinie [fig6-advanced-options6]
   :width: 12.00000cm

   La variable *A* peut être indéfinie [fig6-advanced-options6]

Avec l’option “Exit on variable error”, ``Locate``/``LocateTfst``
émettent un message d’erreur, comme le montre la figure
[fig6-advanced-options7].

.. figure:: resources/img/fig6-advanced-options7.png
   :alt: Sortie à cause d’une variable erronée[fig6-advanced-options7]
   :width: 9.00000cm

   Sortie à cause d’une variable erronée[fig6-advanced-options7]

Avec l’option “Backtrack on variable error” , ``Locate``/``LocateTfst``
arrête l’exploration du chemin courant de la grammaire. Ainsi, les
variables jouent le rôle d’interrupteurs qui coupent les chemins lorsqu’
elles sont indéfinies. Par exemple, l’application de la grammaire
[fig6-advanced-options5] produit seulement des sorties contenant des
adjectifs , comme le montre la figure [fig6-advanced-options8].

.. figure:: resources/img/fig6-advanced-options8.png
   :alt: Marche arrière en cas de variable
   erronée[fig6-advanced-options8]
   :width: 13.00000cm

   Marche arrière en cas de variable erronée[fig6-advanced-options8]

Concordance
~~~~~~~~~~~

Le résultat de la recherche est un fichier d’index contenant les
positions de toutes les oc- currences trouvées. La fenêtre de la
figure [fig-configuration-display-occurrences] vous propose de
construire une concordance, de modifier le texte ou de comparer le
résultat de la recherche à la recherche précédente sur le même texte.

Pour afficher une concordance, vous devez cliquer sur le bouton “Build
concordance”. Vous pouvez paramétrer la taille des contextes gauche et
droit en caractères. Vous pouvez également choisir le mode de tri qui
sera appliqué aux lignes de la concordance grâce au menu “Sort According
to”. Pour plus de détails sur les paramètres de construction de la
concordance, reportez-vous à la section [section-display-occurrences].

.. figure:: resources/img/fig6-31.png
   :alt: Configuration de l’affichage des occurrences trouvées
   [fig-configuration-display-occurrences]
   :width: 10.00000cm

   Configuration de l’affichage des occurrences trouvées
   [fig-configuration-display-occurrences]

La concordance est produite sous la forme d’un fichier HTML Vous pouvez
paramétrer Unitex pour que les concordances soient lues à l’aide d’un
navigateur Web (voir section [section-display-occurrences]).

Si vous affichez les concordances avec la fenêtre proposée par Unitex,
vous pouvez accéder à la séquence reconnue dans le texte en cliquant sur
l’occurrence. Si la fenêtre du texte n’est pas icônifiée et que le texte
n’est pas trop long pour être affiché, vous verrez apparaître la
séquence sélectionnée (voir figure [fig-back-to-text]).

.. figure:: resources/img/fig6-32.png
   :alt: Sélection d’une occurrence dans le texte[fig-back-to-text]
   :width: 13.50000cm

   Sélection d’une occurrence dans le texte[fig-back-to-text]

De plus, si l’automate du texte a été construit et que la fenêtre
correspondante n’est pas icônifiée, le fait de cliquer sur une
occurrence sélectionne l’automate de la phrase qui contient cette
occurrence.

Modification du texte
~~~~~~~~~~~~~~~~~~~~~

Vous pouvez choisir de modifier le texte au lieu de construire une
concordance. Pour cela, sélectionnez un nom de fichier dans le cadre
“Modify text” de la fenêtre de la figure
 [fig-configuration-display-occurrences]. Ce fichier doit porter
l’extension ``.txt``.

Si vous souhaitez modifier le texte courant, il faut choisir le fichier
``.txt`` correspondant. Si vous choisissez un autre nom de fichier, le
texte courant ne sera pas affecté. Cliquez sur le bouton “GO” pour
lancer la modification du texte. Les règles de priorités appliquées lors
de cette opération sont détaillées à la
section [section-applying-transducers-rules].

Une fois cette opération effectuée, le fichier résultant est une copie
du texte dans laquelle les sorties ont été prises en compte. Les
opérations de normalisation et de découpage en unités lexicales sont
automatiquement appliquées à ce fichier texte. Les dictionnaires du
texte existants ne sont pas modifiés. Ainsi, si vous avez choisi de
modifier le texte courant, les modifications sont immédiatement
effectives. Vous pouvez alors lancer de nouvelles recherches sur le
texte.

ATTENTION : si vous avez choisi d’appliquer votre graphe en ignorant les
sorties, toutes les occurrences seront effacées du texte.

Extraction des occurrences
~~~~~~~~~~~~~~~~~~~~~~~~~~

Vous pouvez extraire toutes les phrases du texte qui contiennent ou non
des occurrences. Pour cela, choisissez un nom de fichier de sortie grâce
au bouton “Set File” dans le cadre “Extract units”
(figure [fig-configuration-display-occurrences]). Cliquez ensuite sur un
des boutons “Extract matching units” ou “Extract unmatching units” selon
que vous voulez extraire les phrases contenant les occurrences ou non.

Comparaison de concordances
~~~~~~~~~~~~~~~~~~~~~~~~~~~

L’option “Show differences with previous concordance” permet de comparer
la concordance qui vient d’être calculée avec la concordance précédente,
si elle existe. Pour cela, le programme ``ConcorDiff`` construit les
deux concordances dans l’ordre du texte, puis compare leurs lignes. Le
résultat est une page HTML qui montre alternativement les lignes des
deux concordances, laissant une ligne vide quand un match n’apparaît que
dans une seule des deux concordances (figure [fig-concordiff]).

.. figure:: resources/img/fig6-33.png
   :alt: Exemple de comparaison de concordances[fig-concordiff]
   :height: 10.00000cm

   Exemple de comparaison de concordances[fig-concordiff]

Les lignes de la concordance antérieure sont grisées et celles de la
concordance courante restent sur fond blanc. Dans chaque ligne, seules
les séquences reconnues sont colorées. On peut cliquer dessus pour
ouvrir le texte à cette position.

Le bleu indique qu’une séquence est commune aux deux concordances. Le
rouge indique qu’une séquence reconnue est commune aux deux
concordances, mais avec des extensions différentes, c’est-à-dire que les
deux séquences reconnues se chevauchent partiellement. Le vert signale
qu’une séquence n’apparait que dans une seule concordance.

S’il n’existe pas de concordance antérieure, le bouton est désactivé.

Mode Debug
~~~~~~~~~~

Lorsqu’on applique un graphe à un texte avec le menu ``Locate`` dans la
fenêtre de la figure [fig-regexp-frame], si le mode debug est activé
dans le champ “Locate pattern in the form of”, la concordance est
affichée dans une fenêtre spéciale (voir figure [fig-debug-mode]),
divisée en trois parties :

.. figure:: resources/img/fig6-34.png
   :alt: La fenêtre de concordance en mode debug[fig-debug-mode]
   :height: 9.50000cm

   La fenêtre de concordance en mode debug[fig-debug-mode]

En haut à droite, se trouve la fenêtre de concordance. Elle est
identique à la fenêtre habituelle dans laquelle les séquences reconnues
apparaissent en bleu.

En bas à droite se trouve le graphe utilisé par ``Locate``.

A gauche, il y a un tableau divisé en trois colonnes: “Tag”, “Output” et
“Matched”. Chaque token de la séquence reconnue apparaît dans la colonne
“Matched”, la colonne “Tag” indique le contenu de la boîte de l’automate
qui l’a reconnue, et si elle possède une sortie, elle apparaît dans la
colonne “Output”.

Pour chaque séquence reconnue de la concordance, si on clique dessus, le
tableau est mis à jour. Si on clique sur une ligne du tableau, le
système colore la boîte correspondante dans le graphe. On peut ainsi
voir pour chaque occurrence reconnue dans le texte quel chemin de
l’automate la reconnait. Le nombre en rouge au-dessus d’une boîte
indique le nombre de séquences du texte pour lesquelles cette boîte a
reconnu un token.

Quand on applique un graphe en mode debug avec le menu
``Text>Locate Pattern``, le système le compile en un fichier ``fst2``
dans un formal spécial de mode debug, qui n’est pas compatible avec
CasSys. Voir la section [graphs-for-cassys] pour résoudre ce problème.

.. [1]
   À partir de la version 3.1bêta, révision 4072 du 2 octobre 2015.

.. [2]
   Les dictionnaires du texte sont compilés pendant l’application
   initiale des dictionnaires (section [section-applying-dictionaries]),
   non pas pendant la recherche de motifs.

.. [3]
   De cette façon, le masque lexical provoque une consultation des
   dictionnaires du mode morphologique qui n’est effectuée qu’une fois
   avant plusieurs recherches de codes sémantiques. Si on vérifie le
   code grammatical et un code sémantique par un même masque lexical,
   ces masques deviennent plus nombreux dans l’ensemble de la grammaire
   et ils provoquent plus de consultations des dictionnaires.
