Alignement de texte
===================

Le principe de l’alignement de texte est simple: quand on aligne deux
textes ou plus, le premier est considéré comme le texte source et les
autres comme ses traductions. L’alignement s’effectue au niveau de la
phrase, parce l’alignement au niveau des mots n’est pas encore possible
et certainement pas pertinent. On peut chercher une expression :math:`A`
dans un des textes puis rechercher ses traductions dans les phrases
alignées avec celles contenant :math:`A`.

Pour ajouter cette fonctionnalité à Unitex, Patrick Watrin a intégré
l’outil d’alignement de texte Open Source ``XAlign``, développé au LORIA
(:raw-latex:`\cite{XAlign}`). Dans ce chapitre, nous expliquons comment
utiliser le module d’alignement. Le lecteur intéressé par les détails
d’intégration de ``XAlign`` peut consulter
:raw-latex:`\cite{IGML_DumPau08}` ou :raw-latex:`\cite{IGML_PauDum08}`,
et :raw-latex:`\cite{dusko_xalign}` pour avoir une idée de ce qui peut
être fait avec ce module.

Chargement de textes
--------------------

Il faut tout d’abord sélectionner deux textes. Pour cela, allez sur
“XAlign>Open files…”, et vous verrez le cadre de la figure
[fig-x-text-selection]. Deux formats de textes peuvent être utilisés:
texte brut unicode (comme pour les corpus) ou texte au format TEI
(format de type XML; voir :raw-latex:`\cite{TEI}`). Dans le dernier
champ, choisissez un fichier XML d’alignement, si vous en avez déjà
construit un. Si vous choisissez un texte brut, Unitex doit construire
une version TEI de votre texte (pour plus de détails, voir section
[section-XMLizer] au sujet du programme ``XMLizer``). Quand vous cliquez
sur “OK”, le nom d’un fichier XML vous est demandé comme le montre la
figure [fig-x-tei-name]. Unitex construit alors, si besoin est, les
versions XML de vos textes, et affiche le cadre de la figure
[fig-x-frame]. Comme vous pouvez le constater, chaque texte est
représenté sous la forme d’une liste, chaque cellule comportant une
phrase.

.. figure:: resources/img/figX-1.png
   :alt: Fenêtre de sélection des textes à aligner[fig-x-text-selection]
   :width: 9.50000cm

   Fenêtre de sélection des textes à aligner[fig-x-text-selection]

.. figure:: resources/img/figX-2.png
   :alt: Attention aux textes bruts[fig-x-tei-name]
   :width: 10.00000cm

   Attention aux textes bruts[fig-x-tei-name]

.. figure:: resources/img/figX-3.png
   :alt: Cadre d’alignement de texte[fig-x-frame]
   :width: 15.50000cm

   Cadre d’alignement de texte[fig-x-frame]

Aligner des textes
------------------

Une fois les textes chargés, vous pouvez les aligner en cliquant sur
“Align”. Le nom du fichier XML contenant toutes les informations
d’alignement vous sera demandé. Ensuite, Unitex lance le programme
``XAlign``, vous visualisez alors l’alignement sous la forme de traits
rouges entre les phrases alignées comme le montre la figure
[fig-x-links].

.. figure:: resources/img/figX-4.png
   :alt: Phrases alignées[fig-x-links]
   :width: 15.50000cm

   Phrases alignées[fig-x-links]

Il est possible d’éditer les liens d’alignement avec la souris. Le fait
de cliquer sur un lien le supprime. Pour ajouter un lien (ou le
supprmer, s’il existe déjà), sélectionnez une phrase avec la souris
(dans le texte de votre choix, source ou destination) et déplacez la
souris jusqu’à la phrase correspondante dans l’autre texte. Le lien en
cours de création apparaît en jaune comme le montre la figure
[fig-x-adding-a-link]. En le sélectionnant, ce lien est effectivement
ajouté et devient rouge. Une fois toutes les corrections effectuées,
sauvegardez le nouvel alignement au moyen des boutons “Save alignment”
“Save alignment as…”.

.. figure:: resources/img/figX-5.png
   :alt: Ajout d’un lien[fig-x-adding-a-link]
   :width: 15.50000cm

   Ajout d’un lien[fig-x-adding-a-link]

Une caractéristique intéressante du programme XAlign est qu’il est
*réentrant*. Cela siginifie que vous pouvez utiliser un alignement
existant comme un ensemble de liens obligatoires en tant qu’entrées du
processus d’alignement. Ceci peut-être très utile si vous souhaitez
travailler avec des *mots apparentés*. Pour plus de détails au sujet des
mots apparentés et de XAlign, voir :raw-latex:`\cite{IGML_PauDum08}`.

Recherche de motifs
-------------------

Vous pouvez effectuer des recherches de motifs sur chacun des textes, en
cliquant sur son bouton “Locate”. La première fois, Unitex vous
demandera de construire une version de travail de votre texte, comme le
montre la figure [fig-x-fig6]. Cette version sera prétraitée en tenant
compte de la langue du texte (en particulier, les dictionaires
sélectionnés par défaut seront appliqués).

ATTENTION : la langue du texte est déterminée à l’aide de son nom
complet. Par exemple, si votre fichier se trouve dans le répertoire
``.../MyUnitex/Klingon/Corpus``, la langue considérée sera ``Klingon``.
Donc, si votre texte n’est pas dans un sous-répertoire de votre
répertoire de travail, sa langue ne sera pas correctement identifiée.

.. figure:: resources/img/figX-6.png
   :alt: Unitex doit construire une version de travail du
   texte[fig-x-fig6]
   :width: 10.00000cm

   Unitex doit construire une version de travail du texte[fig-x-fig6]

.. figure:: resources/img/figX-7.png
   :alt: Recherche de motifs sur des textes alignés[fig-x-locate-frame]
   :width: 7.80000cm

   Recherche de motifs sur des textes alignés[fig-x-locate-frame]

Une fois qu’Unitex a créé et prétraité la version de travail de votre
texte, vous pouvez effectuer une requête comme indiqué figure
[fig-x-locate-frame]. Celle-ci étant faite par le programme ``Locate``,
elle est tout à fait semblable à celles effectuées sur un corpus normal.
La seule restriction est qu’il est impossible d’utiliser les sorties des
grammaires si elles en comportent.

Recherchons par exemple le motif ``<manger>`` dans le texte de notre
exemple. Dans un premier temps, nous n’obtenons aucun résultat, car nous
n’avons pas encore changé le mode d’affichage du texte, qui par défaut
est “All sentences/Plain text”. En sélectionnant “Matched sentences”,
nous voyons seulement les phrases qui contiennent des occurrences,
habituellement surlignées en bleu comme le montre la figure
[fig-x-concord]. En cliquant sur “All sentences/HTML” nous obtenons
toutes les phrases, avec les occurrences surlignées en bleu.

.. figure:: resources/img/figX-8.png
   :alt: Affichages des phrases reconnues[fig-x-concord]
   :width: 15.50000cm

   Affichages des phrases reconnues[fig-x-concord]

Pour utiliser des textes parallèles, il est intéressant de retrouver les
phrases alignées avec les phrases reconnues. Il suffit pour cela de
sélectionner *pour l’autre texte*, le mode d’affichage “Aligned with
source concordance”. Dans ce mode, Unitex filtre les phrases non liées à
des phrases reconnues dans le texte source. Il est ainsi facile de
rechercher une expression dans un texte et de trouver la phrase
correspondante dans l’autre, comme le montre la figure
[fig-x-concord-aligned].

.. figure:: resources/img/figX-9.png
   :alt: Affichages des phrases reconnues et des phrases auxquelles
   elles sont liées [fig-x-concord-aligned]
   :width: 15.50000cm

   Affichages des phrases reconnues et des phrases auxquelles elles sont
   liées [fig-x-concord-aligned]
