Formats de fichiers
===================

Ce chapitre présente les formats des différents fichiers lus ou générés
par Unitex. Les formats des dictionnaires DELAS et DELAF sont déjà
présentés aux sections [section-DELAF-format] et [section-DELAS-format].

NOTE: dans ce chapitre, le symbole ¶ représentera le retour à la ligne.
Sauf indication contraire, tous les fichiers texte décrits dans ce
chapitre sont codés en Unicode Little-Endian.

Codage Unicode
--------------

Par défaut, les fichiers textes manipulés par Unitex doivent être en
Unicode Little-Endian. Unitex accepte aussi des fichiers Unicode
Big-Endian ou UTF-8. Ce codage permet de représenter 65536 caractères en
les codant chacun sur 2 octets. En Little-Endian, les octets sont dans
l’ordre poids faible, poids fort. Quand cet ordre est inversé, on parle
de codage Big-Endian. Un fichier texte codé en Little-Endian, Big-Endian
or UTF-8 commence par le caractère spécial (Unicode Byte Order Mark -
BOM) de valeur hexadécimale ``FF``\ ``FE`` (Little-Endian),
``FE``\ ``FF`` (Big-Endian) ou ``EF``\ ``BB``\ ``BF`` (UTF-8). Parce que
UTF-8 n’a pas d’ordre d’octet, l’ajout d’un BOM UTF-8 est optionnel;
pour UTF-16 c’est obligatoire. Les symboles de saut de ligne doivent
être codés par les deux caractères ``0D``\ ``00`` et ``0A``\ ``00``
(Little-Endian), ``00``\ ``0D`` et ``00``\ ``0A`` (Big-Endian), ou
``0D`` and ``0A`` (UTF-8).

Considérons le texte suivant:

``Unitex¶``

``\beta-version¶``

Voici la représentation en Unicode Little-Endian de ce texte:

+------------------+------------------+------------------+------------------+------------------+------------------+------------------+----------------------------------+----------------------------------+
| BOM header       | U                | n                | i                | t                | e                | x                | ¶                                | :math:`\beta`                    |
+==================+==================+==================+==================+==================+==================+==================+==================================+==================================+
| ``FF``\ ``FE``   | ``55``\ ``00``   | ``6E``\ ``00``   | ``69``\ ``00``   | ``74``\ ``00``   | ``65``\ ``00``   | ``78``\ ``00``   | ``0D``\ ``00``\ ``0A``\ ``00``   | ``B2``\ ``03``                   |
+------------------+------------------+------------------+------------------+------------------+------------------+------------------+----------------------------------+----------------------------------+
| -                | v                | e                | r                | s                | i                | o                | n                                | ¶                                |
+------------------+------------------+------------------+------------------+------------------+------------------+------------------+----------------------------------+----------------------------------+
| ``2D``\ ``00``   | ``76``\ ``00``   | ``65``\ ``00``   | ``72``\ ``00``   | ``73``\ ``00``   | ``69``\ ``00``   | ``6F``\ ``00``   | ``6E``\ ``00``                   | ``0D``\ ``00``\ ``0A``\ ``00``   |
+------------------+------------------+------------------+------------------+------------------+------------------+------------------+----------------------------------+----------------------------------+

Table: Représentation hexadécimale d’un texte Unicode Little-Endian

Voici sa représentation en Unicode Big-Endian:

+------------------+------------------+------------------+------------------+------------------+------------------+------------------+----------------------------------+----------------------------------+
| BOM header       | U                | n                | i                | t                | e                | x                | ¶                                | :math:`\beta`                    |
+==================+==================+==================+==================+==================+==================+==================+==================================+==================================+
| ``FE``\ ``FF``   | ``00``\ ``55``   | ``00``\ ``6E``   | ``00``\ ``69``   | ``00``\ ``74``   | ``00``\ ``65``   | ``00``\ ``78``   | ``00``\ ``0D``\ ``00``\ ``0A``   | ``03``\ ``B2``                   |
+------------------+------------------+------------------+------------------+------------------+------------------+------------------+----------------------------------+----------------------------------+
| -                | v                | e                | r                | s                | i                | o                | n                                | ¶                                |
+------------------+------------------+------------------+------------------+------------------+------------------+------------------+----------------------------------+----------------------------------+
| ``00``\ ``2D``   | ``00``\ ``76``   | ``00``\ ``65``   | ``00``\ ``72``   | ``00``\ ``73``   | ``00``\ ``69``   | ``00``\ ``6F``   | ``00``\ ``6E``                   | ``00``\ ``0D``\ ``00``\ ``0A``   |
+------------------+------------------+------------------+------------------+------------------+------------------+------------------+----------------------------------+----------------------------------+

Table: Représentation hexadécimale d’un texte Unicode Big-Endian

Voici sa représentation Unicode en UTF-8:

+--------------------------+----------+----------+----------+----------+----------+----------+------------------+------------------+
| BOM header               | U        | n        | i        | t        | e        | x        | ¶                | :math:`\beta`    |
+==========================+==========+==========+==========+==========+==========+==========+==================+==================+
| ``EF``\ ``BB``\ ``BF``   | ``55``   | ``6E``   | ``69``   | ``74``   | ``65``   | ``78``   | ``0D``\ ``0A``   | ``CE``\ ``B2``   |
+--------------------------+----------+----------+----------+----------+----------+----------+------------------+------------------+
| -                        | v        | e        | r        | s        | i        | o        | n                | ¶                |
+--------------------------+----------+----------+----------+----------+----------+----------+------------------+------------------+
| ``2D``                   | ``76``   | ``65``   | ``72``   | ``73``   | ``69``   | ``6F``   | ``6E``           | ``0D``\ ``0A``   |
+--------------------------+----------+----------+----------+----------+----------+----------+------------------+------------------+

Table: Représentation hexadécimale d’un texte Unicode UTF-8

En Unicode Little-Endian, les octets de poids fort et de poids faible
ont été inversés, ce qui explique que le caractère d’en-tête soit codé
par ``FF``\ ``FE`` au lieu de ``FE``\ ``FF``, idem pour ``00``\ ``0D``
et ``00``\ ``0A`` qui sont devenus respectivement ``0D``\ ``00`` and
``0A``\ ``00``.

Fichiers d’alphabet
-------------------

Il y a deux sortes de fichiers d’alphabet : un fichier qui définit les
caractères d’une langue et un fichier indiquant des préférences pour le
tri. Le premier est désigné sous le terme *alphabet*, et le second sous
celui *alphabet de tri*.

Alphabet
~~~~~~~~

Le fichier d’alphabet est un fichier texte décrivant tous les caractères
d’une langue, ainsi que les correspondances entre lettres minuscules et
majuscules. Ce fichier doit s’appeler ``Alphabet.txt`` et doit se
trouver dans la racine du répertoire de la langue concernée. Sa présence
est obligatoire pour qu’Unitex puisse fonctionner.

Exemple : le fichier d’alphabet de l’anglais doit se trouver dans le
répertoire ``.../English/``

Chaque ligne du fichier alphabet doit avoir l’une des 3 formes
suivantes, suivie par un retour à la ligne :

-  |image| : un dièse suivi de 2 caractères :math:`X` and :math:`Y`
   indique que tous les caractères compris entre les caractères
   :math:`X` et :math:`Y` sont des lettres. Tous ces caractères sont
   considérés comme étant à la fois minuscules et majuscules. Ce mode
   est utile pour définir les alphabets des langues asiatiques comme le
   coréen, le chinois ou le japonais où il n’y a pas de distinction de
   casse et où le nombre de caractères rendrait très fastidieuse une
   énumération complète;

-  ``Aa`` : 2 caractères :math:`X` et :math:`Y` indiquent que :math:`X`
   et :math:`Y` sont des lettres et que :math:`X` est l’équivalent en
   majuscule de la lettre :math:`Y`.

-  |image|: un unique caractère :math:`X` définit :math:`X` comme une
   lettre à la fois minuscule et majuscule. Ce mode est utile pour
   définir un caractère asiatique de manière ponctuelle.

Pour certaines langues comme le français, il arrive qu’à une lettre
minuscule correspondent plusieurs majuscules. For example, ``é``, qui
peut avoir comme majuscule soit ``E`` ou ``É``. Pour exprimer cela, il
suffit d’utiliser plusieurs lignes. L’inverse est également vrai : à une
majuscule peuvent correspondre plusieurs minuscules. Ainsi, ``E`` peut
être la majuscule de ``e``, ``é``, ``è``, ``ë`` ou ``ê``. Voici
l’extrait du fichier alphabet du français qui définit les différentes
lettres

``e``:

``Ee``\ ¶

``Eé``\ ¶

``Éé``\ ¶

``Eè``\ ¶

``Èè``\ ¶

``Eë``\ ¶

``Ëë``\ ¶

``Eê``\ ¶

``Êê``\ ¶

Alphabet de tri
~~~~~~~~~~~~~~~

L’alphabet de tri est un fichier texte qui définit les priorités des
lettres d’une langue lors du tri à l’aide du programme ``SortTxt``.
Chaque ligne de ce fichier définit un groupe de lettres. Si un groupe de
lettres :math:`A` est défini avant un groupe de lettres :math:`B`,
n’importe quelle lettre de :math:`A` sera inférieure à n’importe quelle
lettre de :math:`B`.

Les lettres d’un même groupe ne sont distinguées que si nécessaire. Par
exemple, si l’on a défini le groupe de lettre ``eéèëê`` le mot ``ébahi``
sera considéré comme plus petit que ``estuaire``, lui-même plus petit
que ``été``. Comme les lettres qui suivent ``e`` et ``é`` permettaient
de classer les mots, on n’a pas cherché à comparer les lettres ``e`` et
``é`` car elles sont du même groupe. En revanche, si l’on compare les
mots ``chantés`` et ``chantes``, ``chantes`` sera considéré comme plus
petit. En effet, il faut comparer les lettres ``e`` et ``é`` pour
distinguer ces mots. Comme la lettre ``e`` apparaît en premier dans le
groupe ``eéèëê``, elle est considérée comme inférieure à ``é``. Le mot
``chantes`` sera donc considéré comme plus petit que le mot ``chantés``.

Le fichier d’alphabet de tri permet de définir des équivalences de
caractères. On peut donc ignorer les différences de casse et d’accent.
Par exemple, si l’on veut ordonner les lettres ``b``, ``c``, et ``d``
sans tenir compte de la casse ni de la cédille, on peut écrire les
lignes suivantes :

``Bb``\ ¶

``CcÇç``\ ¶

``Dd``\ ¶

Ce fichier est facultatif. Lorsqu’aucun alphabet de tri n’est spécifié
au programme ``SortTxt`` celui-ci effectue un tri dans l’ordre
d’apparition des caractères dans le codage Unicode.

Graphes
-------

Cette section présente les deux formats de graphes : le format graphique
``.grf`` et le format compilé ``.fst2``.

Format .grf
~~~~~~~~~~~

Un fichier ``.grf`` est un fichier texte contenant des informations de
présentation en plus des informations représentant les contenus des
boîtes et les transitions du graphe. Un fichier ``.grf`` commence par
les lignes suivantes:

``#Unigraph``\ ¶

``SIZE 1313 950``\ ¶

``FONT Times New Roman:  12``\ ¶

``OFONT Times New Roman:B 12``\ ¶

``BCOLOR 16777215``\ ¶

``FCOLOR 0``\ ¶

``ACOLOR 12632256``\ ¶

``SCOLOR 16711680``\ ¶

``CCOLOR 255``\ ¶

``DBOXES y``\ ¶

``DFRAME y``\ ¶

``DDATE y``\ ¶

``DFILE y``\ ¶

``DDIR y``\ ¶

``DRIG n``\ ¶

``DRST n``\ ¶

``FITS 100``\ ¶

``PORIENT L``\ ¶

``#``\ ¶

La première ligne ``#Unigraph`` est une ligne de commentaire. Les lignes
suivantes définissent les valeurs des paramètres de présentation du
graphe :

-  ``SIZE x y`` : définit la largeur ``x`` et la hauteur ``y`` du graphe
   en pixels;

-  ``FONT name:xyz`` : définit la police utilisée pour afficher le
   contenu des boîtes. ``name`` représente le nom de la police. ``x``
   indique si la police doit être en gras ou non. Si ``x`` vaut ``B``,
   cela indique que la police doit être en gras. Pour une police
   normale, ``x`` doit être un espace. De la même manière, ``y`` vaut
   ``I`` si la police doit être en italique, un espace sinon. ``z``
   représente la taille de la police;

-  ``OFONT name:xyz`` : définit la police utilisée pour afficher les
   transductions. Les paramètres ``name``, ``x``, ``y``, et ``z`` sont
   définis de la même manière que pour ``FONT``;

-  ``BCOLOR x`` : définit la couleur de l’arrière-plan du graphe. ``x``
   représente la couleur au format RGB;

-  ``FCOLOR x`` : définit la couleur de dessin du graphe. ``x``
   représente la couleur au format RGB;

-  ``ACOLOR x`` : définit la couleur utilisée pour dessiner les lignes
   des boîtes qui correspondent à des appels à des sous-graphes. ``x``
   représente la couleur au format RGB;

-  ``SCOLOR x`` : définit la couleur utilisée pour écrire le contenu des
   boîtes de commentaires (i.e. les boîtes qui ne sont reliées à aucune
   autre). ``x`` représente la couleur au format RGB;

-  ``CCOLOR x`` : définit la couleur utilisée pour dessiner les boîtes
   sélectionnées. ``x`` représente la couleur au format RGB;

-  ``DBOXES x`` : cette ligne est ignorée par Unitex. Elle est conservée
   par souci de compatibilité avec les graphes Intex ;

-  ``DFRAME x`` : dessine ou non un cadre autour du graphe selon que
   ``x`` vaut ``y``, ou ``n``;

-  ``DDATE x`` : affiche ou non la date en bas du graphe selon que ``x``
   vaut ``y``, ou ``n``;

-  ``DFILE x`` : affiche ou non le nom du fichier en bas du graphe selon
   que ``x`` vaut ``y``, ou ``n``;

-  ``DDIR x`` : affiche ou non le chemin complet d’accès au fichier en
   bas du graphe selon que ``x`` vaut ``y``, ou ``n``; Cette option
   n’est prise en compte que si le paramètre ``DFILE`` a la valeur
   ``y``;

-  ``DRIG x`` : dessine le graphe de droite à gauche ou de gauche à
   droite selon que ``x`` vaut ``y``, ou ``n``;

-  ``DRST x`` : cette ligne est ignorée par Unitex. Elle est conservée
   par souci de compatibilité avec les graphes Intex ;

-  ``FITS x`` : cette ligne est ignorée par Unitex. Elle est conservée
   par souci de compatibilité avec les graphes Intex ;

-  ``PORIENT x`` : cette ligne est ignorée par Unitex. Elle est
   conservée par souci de compatibilité avec les graphes Intex ;

-  ``#`` : cette ligne est ignorée par Unitex. Elle sert à indiquer la
   fin des informations d’en-tête.

Les lignes suivantes donnent le contenu et la position des boîtes du
graphe. Les lignes suivantes correspondent à un graphe reconnaissant un
chiffre :

``3``\ ¶

``"<E>" 84 248 1 2 ``\ ¶

``"" 272 248 0 ``\ ¶

``s"1+2+3+4+5+6+7+8+9+0" 172 248 1 1 ``\ ¶

La première ligne indique le nombre de boîtes du graphe, immédiatement
suivi d’un retour à la ligne. Ce nombre ne doit jamais être inférieur à
2, car un graphe est toujours sensé posséder un état initial et un état
final.

Les lignes suivantes définissent les boîtes du graphe. Les boîtes sont
numérotées à partir de :math:`0`. Par convention, l’état :math:`0` est
l’état initial et l’état :math:`1` est l’état final. Le contenu de
l’état final doit toujours être vide.

Chaque boîte du graphe est définie par une ligne qui doit avoir le
format suivant :

*contenu X Y N transitions ¶*

*contenu* est une chaîne de caractères entourée de guillemets qui
représente le contenu de la boîte. Cette chaîne peut éventuellement être
précédée d’un ``s`` dans le cas d’un graphe Intex importé ; ce caractère
est alors ignoré par Unitex. Le contenu de la chaîne est le texte qui a
été entré dans le contrôle de texte de l’éditeur de graphes. Le tableau
[table10-2] donne le codage des deux séquences spéciales qui ne sont pas
codées telles quelles dans les fichiers ``.grf``:

+-------------------------------------+-------------------------------------+
| Séquence dans l’éditeur de graphe   | Séquence dans le fichier ``.grf``   |
+=====================================+=====================================+
| ``"``                               | ``\"``                              |
+-------------------------------------+-------------------------------------+
| ``\"``                              | ``\\\"``                            |
+-------------------------------------+-------------------------------------+

Table: Codage des séquences spéciales[table10-2]

NOTE: les caractères compris entre ``<`` et ``>`` ou entre ``{`` et
``}`` ne sont pas interprétés. Ainsi, le caractère ``+`` contenu dans la
chaîne ``"le <A+Conc>"`` n’est pas interprété comme un séparateur de
lignes, car le motif ``<A+Conc>`` est interprété en priorité.

*X* and *Y* représentent les coordonnées de la boîte en pixels. La
figure [fig-box-coordinates] montre comment ces coordonnées sont
interprétées par Unitex.

.. figure:: resources/img/repere.pdf
   :alt: Interprétation des coordonnées des boîtes[fig-box-coordinates]
   :width: 7.00000cm

   Interprétation des coordonnées des boîtes[fig-box-coordinates]

*N* représente le nombre de transitions qui sortent de la boîte. Ce
nombre doit toujours valoir :math:`0` pour l’état final.

Les transitions sont définies par les numéros des boîtes vers lesquelles
elles pointent.

Chaque ligne de définition de boîte doit se terminer par un espace suivi
d’un retour à la ligne.

Format .fst2
~~~~~~~~~~~~

Un fichier ``.fst2`` est un fichier texte qui décrit un ensemble de
graphes. Voici un exemple de fichier ``.fst2`` file:

``0000000002``\ ¶

``-1 NP``\ ¶

``: 1 1 ``\ ¶

``: 2 2 -2 2 ``\ ¶

``: 3 3 ``\ ¶

``t ``\ ¶

``f ``\ ¶

``-2 Adj``\ ¶

``: 6 1 5 1 4 1 ``\ ¶

``t ``\ ¶

``f ``\ ¶

``%<E>``\ ¶

``%the/DET``\ ¶

``%<A>/ADJ``\ ¶

``%<N>``\ ¶

``%nice``\ ¶

``@pretty``\ ¶

``%small``\ ¶

``f``\ ¶

La première ligne représente le nombre de graphes codés dans le fichier.
Le début de chaque graphe est identifié par une ligne indiquant le
numéro et le nom du graphe ( (``-1 NP`` et ``-2 Adj`` dans le fichier
ci-dessus).

Les lignes suivantes décrivent les états du graphe. Si l’état est
terminal, la ligne débute par le caractère ``t`` et par le caractère
``:`` sinon. Pour chaque état, la liste des transitions est une suite
éventuellement vide de couples d’entiers :

-  le premier entier indique le numéro d’étiquette ou de sous-graphe
   correspondant à la transition. Les étiquettes sont numérotées à
   partir de 0. Les sous-graphes sont représentés par des entiers
   négatifs, ce qui explique que les numéros précédant les noms des
   graphes soient négatifs ;

-  le deuxième entier représente le numéro de l’état d’arrivée de la
   transition. Dans chaque graphe, les états sont numérotés à partir de
   0. Par convention, l’état 0 d’un graphe est son état initial.

Chaque ligne de définition d’état doit se terminer par un espace. La fin
de chaque graphe est marquée par une ligne contenant un ``f`` suivi d’un
espace et d’un retour à la ligne.

Les étiquettes sont définies après le dernier graphe. Si la ligne débute
par le caractère ``@``,cela signifie que le contenu de l’étiquette doit
être recherché sans variante de casse. Cette information n’est utile que
lorsque l’étiquette est un mot. Si la ligne débute par le caractère
``%``, les variantes de casse sont autorisées. Si une étiquette porte
une transduction, les séquences d’entrée et de sortie sont séparées par
le caractère ``/`` (exemple : ``the/DET``). Par convention, la première
étiquette doit toujours être le mot vide (``<E>``), et ce, même si cette
étiquette n’est utilisée dans aucune transition.

La fin du fichier est indiquée par une ligne contenant le caractère f
suivi d’un retour à la ligne.

Textes
------

Cette section présente les différents fichiers utilisés pour représenter
des textes.

Fichiers .txt
~~~~~~~~~~~~~

[section-texts] Les fichiers ``.txt`` doivent être des fichiers texte
codés en Unicode Little-Endian. Ces fichiers ne doivent pas contenir
d’accolade ouvrante ou fermante, à moins qu’elles soient utilisées pour
écrire un séparateur de phrase (``{S}``) ou une étiquette lexicale
valide (``{aujourd'hui,.ADV}``). Les retours à la ligne doivent être
codés par les deux caractères spéciaux de valeurs hexadécimales ``000D``
and ``000A``.

Fichiers .snt
~~~~~~~~~~~~~

``.snt`` sont des fichiers ``.txt`` qui ont été prétraités par Unitex.
Ces fichiers ne doivent pas contenir de tabulation. Ils ne doivent pas
non plus contenir plusieurs espaces ou retours à la ligne consécutifs.
Les seules accolades autorisées dans des fichiers ``.snt`` sont celles
du séparateur de phrases ``{S}`` et celles des étiquettes lexicales
(``{aujourd'hui,.ADV}``).

Fichier text.cod
~~~~~~~~~~~~~~~~

Le fichier ``text.cod`` est un fichier binaire contenant une suite
d’entiers représentant le texte. Chaque entier ``i`` renvoie au token
d’indice ``i`` dans le fichier ``tokens.txt`` Ces entiers sont codés sur
4 octets.

NOTE : les tokens sont numérotés à partir de 0.

Fichier tokens.txt
~~~~~~~~~~~~~~~~~~

[fichier-tokens-txt] Le fichier ``tokens.txt`` est un fichier texte
contenant la liste de toutes les unités lexicales du texte. La première
ligne de ce fichier indique le nombre d’unités contenues dans le
fichier. Les unités sont séparées par des retours à la ligne. Quand une
séquence est trouvée dans le texte avec des variantes de casse, chaque
variante est codée par une unitée distincte.

NOTE : les retours à la ligne éventuellement présents dans le fichier
``.snt`` sont codés comme des espaces. Il n’y a donc jamais d’unité
codant le retour à la ligne.

Fichier tok\_by\_alph.txt et tok\_by\_freq.txt
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Ces deux fichiers sont des fichiers texte qui contiennent la liste des
unités lexicales triée par ordre alphabétique ou par ordre de fréquence.

Dans le fichier ``tok_by_alph.txt``, chaque ligne est composée d’une
unité, suivie par le caractère tabulation et le nombre d’occurrences de
cette unité dans le texte.

Les lignes du fichier ``tok_by_freq.txt`` sont formées sur le même
principe, mais le nombre d’occurrences apparaît avant le caractère
tabulation et l’unité.

Fichier enter.pos
~~~~~~~~~~~~~~~~~

Ce fichier est un fichier binaire contenant la liste des positions des
retours à la ligne dans le fichier ``.snt``. Chaque position est
l’indice dans le fichier text.cod d’un retour à la ligne ayant été
remplacé par un espace. Ces positions sont des entiers codés sur 4
octets.

Automate du texte
-----------------

Fichier text.tfst
~~~~~~~~~~~~~~~~~

Le fichier ``text.tfst`` représente l’automate du texte. C’est un
fichier texte qui commence par une ligne comportant dix chiffres qui
indiquent le nombre de phrases contenues dans l’automate. Ensuite, pour
chaque phrase, on dispose de l’en-tête suivante:

-  ``$XXX``\ ¶: ``XXX`` = numéro de la phrase;

-  ``foo foo foo...``\ ¶: texte de la phrase;

-  ``a/b c/d e/f g/h...``\ ¶: pour chaque token de la phrase, il y a une
   paire ``x/y``: ``x`` est l’index du token dans le fichier
   ``tokens.txt``, ``y`` est sa longueur en caractères;

-  ``X_Y``\ ¶: ``X`` est l’offset du premier token de la phrase, en
   tokens depuis le début du texte; ``Y`` est identique mais l’offset
   représente le nombre de caractères.

Ensuite, tous les états de l’automate sont codés, un par ligne. Si
l’état est final, la ligne commence par ``t``. Sinon, elle commence par
``:``. Toutes les transitions sont écrites sous la forme de paires
``x y``, ``x`` étant le nombre de tag, ``y`` étant le nombre d’états de
destination. Remarquons que contrairement au format ``.fst2``, les
lignes doivent finir par un espace. La dernière ligne de la liste
d’états contient ``f``.

Enfin, tous les les tags sont codés. Par convention, le premier tag est
toujours épsilon: ``@<E>``\ ¶

``.``\ ¶

D’autres étiquettes doivent être soit des unités lexicales ou des
entrées au format DELAF entre accolades. Elles sont codées comme suit:

``@STD``\ ¶

``@``\ *content*\ ¶

``@``\ *a*\ ``.``\ *b*\ ``.``\ *c*\ ``-`` *x*\ ``.``\ *y*\ ``.``\ *z*\ ¶

``.``\ ¶

*contenu* est le contenu du tag. Les informations *a.b.c-x.y.z*
décrivent la zone du texte couverte par le tag:

-  *a*: offset de début en tokens depuis le début de la phrase;

-  *b*: offset de début en caractères depuis le début du premier; token
   du tag;

-  *c*: offset de début en lettres logiques depuis le premier caractère
   du tag. Ces informations sont utiles pour le coréen, parce qu’un tag
   représent une séquence de caractères Jamo qui apparaissent à
   l’intérieur d’un Hangul. L’offset en caractères n’est donc pas assez
   précis;

-  *x*: offset de fin en tokens depuis le début de la phrase;

-  *y*: offset de fin en caractères depuis le début du dernier token du
   tag;

-  *z*: de fin en lettres logiques depuis le dernier caractère du the
   tag. Dans des automates de phrase coréen, des formes de surface vides
   peuvent correspondre à des mots vides du texte. Dans ces cas, *z* a
   la valeur :math:`-1`.

La définition de tag se termine par une ligne qui contient ``f``.

Exemple : Voici le fichier correspondant au texte *He is drinking orange
juice.*

``0000000001``\ ¶

``$1``\ ¶

``He is drinking orange juice. ``\ ¶

``0/2 1/1 2/2 1/1 3/8 1/1 4/6 1/1 5/5 6/1 1/1``\ ¶

``0_0``\ ¶

``: 2 1 1 1``\ ¶

``: 4 2 3 2``\ ¶

``: 7 3 6 3 5 3``\ ¶

``: 10 5 9 4 8 4``\ ¶

``: 12 5 11 5``\ ¶

``: 13 6``\ ¶

``t``\ ¶

``f``\ ¶

``@<E>``\ ¶

``.``\ ¶

``@STD``\ ¶

``@{He,he.N:s:p}``\ ¶

``@0.0.0-0.1.0``\ ¶

``.``\ ¶

``@STD``\ ¶

``@{He,he.PRO+Nomin:3ms}``\ ¶

``@0.0.0-0.1.0``\ ¶

``.``\ ¶

``@STD``\ ¶

``@{is,be.V:P3s}``\ ¶

``@2.0.0-2.1.0``\ ¶

``.``\ ¶

``@STD``\ ¶

``@{is,i.N:p}``\ ¶

``@2.0.0-2.1.0``\ ¶

``.``\ ¶

``@STD``\ ¶

``@{drinking,drinking.A}``\ ¶

``@4.0.0-4.7.0``\ ¶

``.``\ ¶

``@STD``\ ¶

``@{drinking,drinking.N:s}``\ ¶

``@4.0.0-4.7.0``\ ¶

``.``\ ¶

``@STD``\ ¶

``@{drinking,drink.V:G}``\ ¶

``@4.0.0-4.7.0``\ ¶

``.``\ ¶

``@STD``\ ¶

``@{orange,orange.A}``\ ¶

``@6.0.0-6.5.0``\ ¶

``.``\ ¶

``@STD``\ ¶

``@{orange,orange.N:s}``\ ¶

``@6.0.0-6.5.0``\ ¶

``.``\ ¶

``@STD``\ ¶

``@{orange juice,orange juice.N+XN+z1:s}``\ ¶

``@6.0.0-8.4.0``\ ¶

``.``\ ¶

``@STD``\ ¶

``@{juice,juice.N+Conc:s}``\ ¶

``@8.0.0-8.4.0``\ ¶

``.``\ ¶

``@STD``\ ¶

``@{juice,juice.V:W:P1s:P2s:P1p:P2p:P3p}``\ ¶

``@8.0.0-8.4.0``\ ¶

``.``\ ¶

``@STD``\ ¶

``@.``\ ¶

``@9.0.0-9.0.0``\ ¶

``.``\ ¶

``f``\ ¶

Fichier text.tind
~~~~~~~~~~~~~~~~~

Le fichier ``text.tind`` utilisé pour sauter à l’octet d’offset correct
dans le fichier ``text.tfst`` quand on veut charger une phrase donnée.
C’est un fichier binaire qui contient :math:`4
\times N` octets,où :math:`N` est le nombre de phrases. Il donne
l’offset de départ de chaque phrase sous la forme d’une suite de 4
octets en little-endian.

Fichier cursentence.grf
~~~~~~~~~~~~~~~~~~~~~~~

Le fichier ``cursentence.grf`` est généré par Unitex lors de l’affichage
d’un automate de phrase. Le programme ``Fst2Grf`` construit un fichier
``.grf`` représentant l’automate d’une phrase à partir du fichier
``text.fst2``.

NOTE: les sorties des boîtes sont utilisées pour coder les offsets, tels
que définis dans ``.tfst``. Les offsets sont séparés par des espaces.
Voici, par exemple, quelques lignes qui representent la première phrase
d’\ *Ivanhoe*:

``"Ivanhoe/0 0 0 0 6 0" 100 200 2 3 4 ``\ ¶

``"{by,by.PART}/2 0 0 2 1 0" 220 150 2 5 6 ``\ ¶

``"{by,by.PREP}/2 0 0 2 1 0" 220 50 2 5 6 ``\ ¶

``"{Sir,sir.N+Hum:s}/4 0 0 4 2 0" 310 200 1 7``\ ¶

Fichier sentenceN.grf
~~~~~~~~~~~~~~~~~~~~~

Lorsque l’utilisateur modifie l’automate d’une phrase, cet automate est
sauvegardé sous le nom ``sentenceN.grf``, où ``N`` représente le numéro
de la phrase.

un tel graphe contient des offsets dans les sorties des boîtes du graphe
(voir note section [section-cursentence\_grf]).

Fichier cursentence.txt
~~~~~~~~~~~~~~~~~~~~~~~

Lors de l’extraction de l’automate phrase, le texte de la phrase est
enregistré dans le fichier appelé ``cursentence.txt``. Ce fichier est
utilisé par Unitex pour afficher le texte de la phrase sous l’automate.
Ce fichier contient le texte de la phrase, suivie d’un saut de ligne.

The cursentence.tok file
~~~~~~~~~~~~~~~~~~~~~~~~

Lors de l’extraction de l’automate phrase, les numéros de tokens qui
composent la phrase sont enregistrés dans un fichier nommé
``cursentence.tok``. Ce fichier contient une ligne par token, chaque
ligne étant composée de 2 entiers ``x y``: ``x`` est le numéro de token,
``y`` est sa longueur en caractères.

Voici le contenu de ce fichier pour la première phrase d’\ *Ivanhoe*:

``0 7``\ ¶\ ``         ``\ *Ivanhoe*

``1 1``\ ¶\ ``         ``\ ``‘ ``

``2 2``\ ¶\ ``         ``\ *by*

``1 1``\ ¶\ ``         ``\ ``‘ ``

``3 3``\ ¶\ ``         ``\ *Sir*

``1 1``\ ¶\ ``         ``\ ``‘ ``

``4 6``\ ¶\ ``         ``\ *Walter*

``1 1``\ ¶\ ``         ``\ ``‘ ``

``5 5``\ ¶\ ``         ``\ *Scott*

``1 1``\ ¶\ ``         ``\ ``‘ ``

Fichiers tfst\_tags\_by\_freq.txt et tfst\_tags\_by\_alph.txt
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Ces fichiers contiennent tous les tags qui apparaissent dans l’automate
du texte classés par fréquence et par ordre alphabétique.

Concordances
------------

Fichier concord.ind
~~~~~~~~~~~~~~~~~~~

Le fichier ``concord.ind`` est l’index des occurrences trouvées par les
programmes ``Locate`` ou ``LocateTfst`` lors de l’application d’une
grammaire. C’est un fichier texte qui contient les positions de début et
de fin de chaque occurrence, éventuellement accompagnées d’une chaîne de
caractères si la concordance a été obtenue en prenant en compte les
éventuelles transductions de la grammaire. Voici un exemple de fichier :

``#M``\ ¶

``59.0.0 63.3.0 the[ADJ= greater] part``\ ¶

``67.0.0 71.4.0 the beautiful hills``\ ¶

``87.0.0 91.3.0 the pleasant town``\ ¶

``123.0.0 127.4.0 the noble seats``\ ¶

``157.0.0 161.5.0 the fabulous Dragon``\ ¶

``189.0.0 193.3.0 the Civil Wars``\ ¶

``455.0.0 459.11.0 the feeble interference``\ ¶

``463.0.0 467.6.0 the English Council``\ ¶

``566.0.0 570.10.0 the national convulsions``\ ¶

``590.0.0 594.5.0 the inferior gentry``\ ¶

``626.0.0 630.11.0 the English constitution``\ ¶

``696.0.0 700.4.0 the petty kings``\ ¶

``813.0.0 817.5.0 the certain hazard``\ ¶

``896.0.0 900.5.0 the great Barons``\ ¶

``938.0.0 942.3.0 the very edge``\ ¶

La première ligne indique dans quel mode de transduction la concordance
a été calculée. Les trois valeurs possibles sont :

-  ``#I`` : les transductions ont été ignorées;

-  ``#M`` : les transductions ont été insérées dans les séquences
   reconnues (mode MERGE);

-  ``#R`` : les transductions ont remplacé les séquences reconnues (mode
   REPLACE).

Chaque occurrence est décrite par une ligne. Les lignes commencent par
les positions de début et de fin de l’occurrence. Ces positions
correspondent aux offsets définis dans le fichier tag ``.tfst`` (voir
[section-tfst-format]).

Si le fichier comporte la ligne d’en-tête ``#I``, la position de fin de
chaque occurrence est immédiatement suivie d’un retour à la ligne. Dans
le cas contraire, elle est suivie d’un espace et d’une chaîne de
caractères. En mode REPLACE, cette chaîne correspond à la transduction
produite pour la séquence reconnue. En mode MERGE, elle représente la
séquence reconnue dans laquelle ont été insérées les transductions. En
mode MERGE ou REPLACE, c’est cette chaîne qui est affichée dans la
concordance. Si les transductions ont été ignorées, le contenu de
l’occurrence est extrait du fichier texte.

Fichier concord.txt
~~~~~~~~~~~~~~~~~~~

Le fichier ``concord.txt`` est un fichier texte représentant une
concordance. Chaque occurrence est codée par une ligne composée de 3
chaînes de caractères séparées par le caractère de tabulation et qui
représentent le contexte gauche, l’occurrence (éventuellement modifiée
par des transductions) et le contexte droit.

Fichier concord.html
~~~~~~~~~~~~~~~~~~~~

Le fichier ``concord.html`` est un fichier ``HTML`` qui représente une
concordance. Ce fichier est codé en UTF-8.

Le titre de la page est le nombre d’occurrences qu’elle décrit. Les
lignes de la concordance sont codées par des lignes où les occurrences
sont considérées comme des liens hypertextes. La référence associée à
chacun de ces liens est de la forme :

``<a href="X Y Z">``

``X`` et ``Y`` représentent les positions de début et de fin de
l’occurrence en caractères dans le fichier ``name_of_text.snt``. ``Z``
représente le numéro de la phrase dans laquelle apparaît cette
occurrence.

Tous les espaces sont codés comme des espaces insécables (``&nbsp;`` in
HTML), ce qui permet de conserver l’alignement des occurrences, même si
l’une d’elles, se trouvant en début de fichier, a un contexte gauche
complété avec des espaces.

NOTE : dans le cas d’une concordance construite avec le paramètre
glossanet, le fichier HTML obtenu a la même structure, sauf en ce qui
concerne les liens. Dans ces concordances, les occurrences sont des
liens réels renvoyant vers le serveur web de l’application GlossaNet.
Pour plus d’information sur GlossaNet, consulter les liens sur le site
web d’Unitex.(http://www-igm.univ-mlv.fr/ unitex).

Voici un exemple de fichier:

``<html lang=en>``\ ¶

``<head>``\ ¶

````\ ¶

``   <meta http-equiv="Content-Type" content="text/html;``

``         charset=UTF-8">``\ ¶

``   <title>6 matches</title>``\ ¶

``</head>``\ ¶

``<body>``\ ¶

``<table border="0" cellpadding="0" width="100%" ``

``       style="font-family: 'Arial Unicode MS'; font-size: 12">``\ ¶

``<font face="Courier new" size=3>``\ ¶

``on, there <a href="116 124 2">extended</a>&nbsp;i&nbsp;<br>``\ ¶

``&nbsp;extended <a href="125 127 2">in</a>&nbsp;ancient&nbsp;<br>``\ ¶

``&nbsp;Scott {S}<a href="32 34 2">IN</a>&nbsp;THAT PL&nbsp;<br>``\ ¶

``STRICT of <a href="61 66 2">merry</a>&nbsp;Engl&nbsp;<br>``\ ¶

``S}IN THAT <a href="40 48 2">PLEASANT</a>&nbsp;D&nbsp;<br>``\ ¶

``&nbsp;which is <a href="84 91 2">watered</a>&nbsp;by&nbsp;<br>``\ ¶

``</font>``\ ¶

``</td></table></body>``\ ¶

``</html>``\ ¶

La figure [fig-example-concordance-2] montre la page correspondant au
fichier ci-dessus.

.. figure:: resources/img/fig10-2.png
   :alt: Exemple de concordance [fig-example-concordance-2]
   :width: 5.00000cm

   Exemple de concordance [fig-example-concordance-2]

Fichier diff.html
~~~~~~~~~~~~~~~~~

Le fichier ``diff.html`` est une page ``HTML`` qui montre les
différences entre deux concordances. Ce fichier est encodé en UTF-8.
Voici un exemple de fichier (des retours à la ligne ont été introduits
pour la mise en page) :

::

    <html>
    <head>
    <meta http-equiv="Content-Type" content="text/html;
    charset=UTF-8">
    <style type="text/css">
    a.blue {color:blue; text-decoration:underline;}
    a.red {color:red; text-decoration:underline;}
    a.green {color:green; text-decoration:underline;}
    </style>
    </head>
    <body>
    <h4>
    <font color="blue">Blue:</font> identical sequences<br>
    <font color="red">Red:</font> similar but different sequences<br>
    <font color="green">Green:</font> sequences that occur in only
    one of the two concordances<br>
    <table border="1" cellpadding="0" style="font-family: Courier new;
    font-size: 12">
    <tr><td width="450"><font color="blue">ed in ancient times
    <u>a large forest</u>, covering the greater par</font></td>
    <td width="450"><font color="blue">ed in ancient times
    <u>a largeforest</u>, covering the greater par</font></td>
    </tr>
    <tr><td width="450"><font color="green">ge forest, covering
    <u>the greater part</u>&nbsp;of the beautiful hills </font>
    </td>
    <td width="450"><font color="green"></font></td>
    </tr>
    </table>
    </body>
    </html>

Dictionnaires du texte
----------------------

Le programme ``Dico`` produit plusieurs fichiers qui représentent les
dictionnaires.

dlf et dlc
~~~~~~~~~~

``dlf`` et ``dlc`` sont des dictionnaires de mots simples et composés au
format DELAF format (voir section [section-DELAF-format]).

err
~~~

Ce fichier contient les mots inconnus, un par ligne.

tags\_err
~~~~~~~~~

Ce fichier contient les mots inconnus, un par ligne. La différence avec
le fichier ``err`` est que dans celui-ci les mots simples reconnus dans
le fichier ``tags.ind`` n’apparaissent pas.

tags.ind
~~~~~~~~

[section-tags-ind] Ce fichier a le même format que ``concord.ind`` il
s’obtient en mode MERGE ou REPLACE mais son en-tête est ``#T``.
Remarquons que les sorties ne commence pas par un slash.

Dictionnaires
-------------

La compression des dictionnaires DELAF par le programme ``Compress``
produit 2 fichiers : un fichier ``.bin`` qui représente l’automate
minimal des formes fléchies du dictionnaire, et un fichier ``.inf`` qui
contient les formes comprimées permettant de reconstruire les lignes du
dictionnaire à partir des formes fléchies. Cette section décrit le
format de ces deux types de fichiers, ainsi que le format du fichier
``CHECK_DIC.TXT``, qui contient le résultat de la vérification d’un
dictionnaire.

Fichier .bin
~~~~~~~~~~~~

Un fichier ``.bin`` est un fichier binaire représentant un automate. Les
4 premiers octets du fichier représentent un entier indiquant la taille
du fichier en octets. Les états de l’automate sont ensuite codés de la
manière suivante :

-  les 2 premiers octets indiquent si l’état est terminal ainsi que le
   nombre de transitions qui en sortent. Le bit le plus fort vaut 0 si
   l’état est terminal et 1 sinon. Les 15 autres bits codent le nombre
   de transitions.

   Exemple : un état non terminal avec 17 transitions est codé par la
   séquence hexadécimale 8011

-  si l’état est terminal, les 3 octets suivants codent l’indice dans le
   fichier ``.inf`` de la forme comprimée à utiliser pour reconstruire
   les lignes de dictionnaires pour cette forme fléchie.

   Exemple : si l’état renvoie à la forme comprimée d’indice 25133, la
   séquence hexadécimale correspondante est ``00622D``

-  chaque transition sortante est ensuite codée sur 5 octets. Les 2
   premiers octets codent le caractère étiquetant la transition, et les
   3 suivants codent la position en octets dans le fichier ``.bin`` de
   l’état d’arrivée. Les transitions d’un état sont codées les unes à la
   suite des autres.

   Exemple : une transition étiquetée par le caractère A pointant vers
   l’état dont la description débute au :math:`50106`\ ème , octet sera
   représenté par la séquence hexadécimale ``004100C3BA``.

Par convention, le premier état de l’automate est l’état initial.

Fichier.inf
~~~~~~~~~~~

Un fichier ``.inf`` est un fichier texte décrivant les formes comprimées
associées à un fichier ``.bin``. Voici un exemple de fichier ``.inf``
file:

``0000000006``\ ¶

``_10\0\0\7.N``\ ¶

``.PREP``\ ¶

``_3.PREP``\ ¶

``.PREP,_3.PREP``\ ¶

``1-1.N+Hum:mp``\ ¶

``3er 1.N+AN+Hum:fs``\ ¶

La première ligne du fichier indique le nombre de formes comprimées
qu’il contient. Chaque ligne peut contenir une ou plusieurs formes
comprimées. S’il y a plusieurs formes, celles-ci doivent être séparées
par des virgules. Chaque forme comprimée est formée d’une séquence
permettant de retrouver une forme canonique à partir d’une forme
fléchie, suivie par la séquence de codes grammaticaux, sémantiques et
flexionnels associés à l’entrée.

Le mode de compression de la forme canonique varie en fonction de la
forme fléchie. Si les deux formes sont exactement identiques, la forme
comprimée se résume aux informations grammaticales, sémantiques et
flexionnelles, comme c’est le cas dans la ligne suivante :

``.N+Hum:ms``

Si les formes sont différentes, le programme de compression découpe les
deux formes en unités. Ces unités peuvent être soit un espace, soit un
tiret, soit une séquence de caractères ne contenant ni espace ni tiret.
Ce mode de découpage permet de prendre efficacement en compte les
flexions des mots composés.

Si les formes fléchies et canonique ne comportent pas le même nombre
d’unités, le programme code la forme canonique par le nombre de
caractères à retrancher de la forme fléchie, suivi des caractères à
ajouter. Ainsi, la première ligne du fichier ci-dessus correspond à la
ligne de dictionnaire :

``James Bond,007.N``

Comme la séquence ``James Bond`` contient trois unités et ``007``
seulement une, la forme canonique est codée par ``_10\0\0\7``. Le
caractère ``_`` indique que les deux formes n’ont pas le même nombre
d’unités. Le nombre qui suit (ici 10) indique le nombre de caractères à
retrancher. La séquence ``\0\0\7`` qui suit ce nombre indique que l’on
doit ensuite ajouter la séquence ``007``. Les chiffres sont précédés du
caractère ``\`` pour ne pas être confondus avec le nombre de caractères
à retrancher.

Lorsque les deux formes ont le même nombre d’unités, les unités sont
comprimées deux à deux. Si les deux unités sont composées d’un espace ou
d’un tiret, la forme comprimée de l’unité est l’unité elle-même, comme
c’est le cas dans la ligne suivante :

``0-1.N:p``

qui est la sortie pour ``battle-axes,battle-axe.N:p``

Cela permet de conserver une certaine visibilité dans le fichier
``.inf`` lorsque le dictionnaire contient des mots composés.

Lorsque au moins une des unités n’est ni un espace ni un tiret, la forme
comprimée est composée du nombre de caractères à retrancher suivi de la
séquence de caractères à ajouter. Ainsi, la ligne de dictionnaire :

``première partie,premier parti.N+AN+Hum:fs``

est codée par la ligne :

``3er 1.N+AN+Hum:fs``

Le code ``3er`` indique que l’on doit retrancher 3 caractères à la
séquence ``première`` et lui ajouter les caractères ``er`` pour obtenir
``premier``. Le ``1`` indique que l’on doit simplement retirer un
caractère à ``partie`` pour obtenir la séquence ``parti``. Le nombre
``0`` est utilisé lorsqu’on veut indiquer que l’on ne doit supprimer
aucun caractère.

Fichier information sur un dictionnaire
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Dans le cadre “Apply lexical resources”, il est possible d’obtenir
quelques informations sur un dictionnaire par click droit. Ces
informations sont associées aux dictionnaires ``biniou.bin`` ou
``biniou.fst2`` à l’aide d’un texte brut nommé ``biniou.txt``, situé
dans le même répertoire.

Fichier CHECK\_DIC.TXT
~~~~~~~~~~~~~~~~~~~~~~

Ce fichier est produit par le programme de vérification de dictionnaire
``CheckDic``. Il s’agit d’un fichier texte qui donne des informations
sur le dictionnaire analysé, et se décom- pose en quatre parties.

La première partie donne la liste, éventuellement vide, de toutes les
erreurs de syntaxe trouvées dans le dictionnaire : absence de la forme
fléchie ou de la forme canonique, absence de code grammatical, ligne
vide, etc. Chaque erreur est décrite par le numéro de la ligne
concernée, un message décrivant la nature de l’erreur, ainsi que le
contenu de la ligne. Voici un exemple de message :

::

    Line 12451: unexpected end of line
    garden,N:s

Les deuxième et troisième parties donnent respectivement les listes de
codes grammaticaux et/ou sémantiques et flexionnels. Afin de prévenir
des erreurs de codage, le programme signale les codes qui contiennent
des espaces, des tabulations ou des caractères non ASCII. Ainsi, si un
dictionnaire grec contient le code ``ADV`` où le caractère ``A`` est le
``A`` grec au lieu du ``A`` latin, le programme signalera
l’avertissement suivant :

::

    ADV warning: 1 suspect char (1 non ASCII char): (0391 D V)

Les caractères non ASCII sont indiqués par leur numéro de caractère en
hexadécimal.Dans l’exemple ci-dessus, le code ``0391`` représente le
``A`` grec. Les espaces sont indiqués par la séquence ``SPACE``:

::

    Km s warning: 1 suspect char (1 space): (K m SPACE s)

Lorsqu’on vérifie le dictionnaire suivant :

::

    1,2 et 3!,.INTJ 
    abracadabra,INTJ 
    supercalifragilisticexpialidocious,.INTJ
    damned,. INTJ
    Paul,.N+Hum+Hum
    eat,.V:W:P1s:Ps:P1p:P2p:P3p

on obtient le fichier ``CHECK_DIC.TXT`` suivant :

``Line 1: unprotected comma in lemma``\ ¶

``1,2 et 3!,.INTJ ``\ ¶

``Line 2: unexpected end of line``\ ¶

``abracadabra,INTJ ``\ ¶

``Line 5: duplicate semantic code``\ ¶

``Paul,.N+Hum+Hum``\ ¶

``Line 6: an inflectional code is a subset of another``\ ¶

``eat,.V:W:P1s:Ps:P1p:P2p:P3p``\ ¶

``-----------------------------------``\ ¶

``-------------  Stats  -------------``\ ¶

``-----------------------------------``\ ¶

``File: D:\My Unitex\English\Dela\axe.dic``\ ¶

``Type: DELAF``\ ¶

``6 lines read``\ ¶

``2 simple entries for 2 distinct lemmas``\ ¶

``0 compound entry for 0 distinct lemma``\ ¶

``-----------------------------------``\ ¶

``----  All chars used in forms  ----``\ ¶

``-----------------------------------``\ ¶

``a (0061)``\ ¶

``c (0063)``\ ¶

``d (0064)``\ ¶

``e (0065)``\ ¶

``f (0066)``\ ¶

``g (0067)``\ ¶

``i (0069)``\ ¶

``l (006C)``\ ¶

``m (006D)``\ ¶

``n (006E)``\ ¶

``o (006F)``\ ¶

``p (0070)``\ ¶

``r (0072)``\ ¶

``s (0073)``\ ¶

``t (0074)``\ ¶

``u (0075)``\ ¶

``x (0078)``\ ¶

``-------------------------------------------------------------``\ ¶

``----    2 grammatical/semantic codes used in dictionary  ----``\ ¶

``-------------------------------------------------------------``\ ¶

``INTJ``\ ¶

`` INTJ warning: 1 suspect char (1 space): (SPACE I N T J)``\ ¶

``-----------------------------------------------------``\ ¶

``----    0 inflectional code used in dictionary  -----``\ ¶

``-----------------------------------------------------``\ ¶

Remarquons que les codes flexionnels de ``eat`` ne sont pas signalés,
puisque une erreur s’est produite dans cette ligne.

Fichiers ELAG
-------------

Fichier tagset.de
~~~~~~~~~~~~~~~~~

See section [section-elag-tagset], page .

Fichiers .lst
~~~~~~~~~~~~~

LES FICHIERS .LST NE SONT PAS CODÉS EN UNICODE.

Un fichier ``.lst`` contient une liste de noms de fichiers ``.grf``. Si
le nom d’un fichier n’est pas absolu, il est relatif à l’emplacement du
fichier ``elag.lst``. Voici le fichier ``elag.lst`` fourni pour le
français :

``PPVs/PpvIL.grf``\ ¶

``PPVs/PpvLE.grf``\ ¶

``PPVs/PpvLUI.grf``\ ¶

``PPVs/PpvPR.grf``\ ¶

``PPVs/PpvSeq.grf``\ ¶

``PPVs/SE.grf``\ ¶

``PPVs/postpos.grf``\ ¶

.elg files
~~~~~~~~~~

Les fichiers ``.elg`` contiennent des règles ELAG compilées. Ces
fichiers sont au format ``.fst2``.

Fichier .rul
~~~~~~~~~~~~

LES FICHIERS .RUL NE SONT PAS CODÉS EN UNICODE.

Un fichier ``.rul`` contient différents fichiers ``.elg`` qui compose un
ensemble de règles ELAG. Un fichier ``.rul`` est constitué d’autant de
parties qu’il y a de fichiers ``.elg``. Chaque partie est composée de la
liste des grammaires ELAG qui correspondent à un fichier ``.elg`` . Les
noms de fichiers ``.elg`` sont entres angles. Les lignes commençant par
une tabulation ont valeur de commentaire et sont ignorées par le
programme ``Elag``. Voici le fichier ``elag.rul`` fourni par défaut pour
le français :

``    PPVs/PpvIL.elg``\ ¶

``    PPVs/PpvLE.elg``\ ¶

``    PPVs/PpvLUI.elg``\ ¶

``<elag.rul-0.elg>``\ ¶

``    PPVs/PpvPR.elg``\ ¶

``    PPVs/PpvSeq.elg``\ ¶

``    PPVs/SE.elg``\ ¶

``    PPVs/postpos.elg``\ ¶

``<elag.rul-1.elg>``\ ¶

Fichier taggeur
---------------

Cette section présente les fichiers produits et utilisés par les
programmes TrainingTagger et Tagger.

Fichier corpus.txt
~~~~~~~~~~~~~~~~~~

[section-corpus-file] Ce fichier est utilisé par le programme
TrainingTagger afin de calculer les statistiques pour le programme
Tagger. Il contient des phrases où chaque mot est représenté sur une
ligne séparée.

Chaque ligne représentant un mot est constituée d’un mot, simple ou
composé, suivie d’une barre oblique et de l’étiquette du mot.

Cette étiquette est composée d’un code grammatical, parfois suivi
d’une\ ``'+'`` et de codes syntaxiques ou sémantiques. Les codes
flexionnels sont spécifiés après un ``':'``. Si le mot est un composé,
les mots simples qui y figurent doivent être séparés par un ``'_'``.
Voici un exemple d’un fichier corpus.txt:

``The/DET+Ddef:s``\ ¶

``GATT/N:s``\ ¶

``had/V:I3s``\ ¶

``formerly/ADV``\ ¶

``a/DET+Dind:s``\ ¶

``political/A``\ ¶

``assessment/N:s``\ ¶

``of/PREP``\ ¶

``the/DET+Ddef:s``\ ¶

``behavior/N:s``\ ¶

``of/PREP``\ ¶

``foreign_countries/N:p``\ ¶

``./PONCT``\ ¶

¶

``She/PRO+Nomin:3fs``\ ¶

``closed/V:I3s``\ ¶

``easily/ADV``\ ¶

``her/DET+Poss3fs:p``\ ¶

``eyes/N:p``\ ¶

``when/CONJ``\ ¶

``some/DET+Dadj:p``\ ¶

``infractions/N:p``\ ¶

``might/V:I3p``\ ¶

``appear/V:W``\ ¶

``justified/V:K``\ ¶

``against/PREP``\ ¶

``higher/A``\ ¶

``interests/N:p``\ ¶

``./PONCT``\ ¶

¶

REMARQUE: Les phrases doivent être délimitées par des lignes vides.

Le format ``.txt`` peut également être utilisé (voir section
[section-texts]). Chaque mot du texte doit être représenté par une
étiquette lexicale valide (``{aujourd'hui,.ADV}``) et les phrases sont
délimitées par ``{S}``. Voici l’exemple précédent dans le format
``.txt`` :

| ``{The,.DET+Ddef:s}`` ``{GATT,.N:s}`` ``{had,.V:I3s}``
  ``{formerly,.ADV}``
| ``{a,.DET+Dind:s}`` ``{political,.A}`` ``{assessment,.N:s}``
  ``{of,.PREP}``
| ``{the,.DET+Ddef:s}`` ``{behavior,.N:s}`` ``{of,.PREP}``
  ``{foreign countries,.N:p}``
| ``{.,.PONCT}`` ``{S}`` ``{She,.PRO+Nomin:3fs}`` ``{closed,.V:I3s}``
  ``{easily,.ADV}``
| ``{her,.DET+Poss3fs:p}`` ``{eyes,.N:p}`` ``{when,.CONJ}``
  ``{some,.DET+Dadj:p}``
| ``{infraction,.N:p}`` ``{might,.V:I3p}`` ``{appear,.V:W}``
  ``{justified,.V:K}``
| ``{against,.PREP}`` ``{higher,.A}`` ``{interests,.N:p}``
  ``{.,.PONCT}`` ``{S}``

Le fichier de données du taggueur
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

[section-training-dict] The TrainingTagger programme genère deux
fichiers de données (par défaut) utilisé par le programme Tagger afin de
calculer un modèle de Markov caché d’ordre 2. Ces fichiers contiennent
des tuples unigram, bigramme et trigramme extraits du corpus étiqueté
corpus.txt. Les tuples sont composés soit d’une séquence de 2 ou 3 tags
(pour calculer la probabilité de transition) ou d’un mot précédé par 0
ou 1 tag (pour calculer la probabilité émise). Les unités dans un tuple
doivent être séparées par une tabulation. Ces tuples sont suivis par la
séquence de délimiteurs “,.” et ensuite un nombre entier représentant le
nombre d’occurrences de ce tuple dans le corpus.

Les noms de fichiers sont suffixés par “cat” ou “morph”. Dans la
premier, les tuples sont composés tags de codes grammaticaux,
syntaxiques et sémantiques. Dans le second, les tuples sont composés de
tags de codes grammaticaux, syntaxiques et sémantiques parfois suivis
par un ``':'`` et des codes flexionnels. Voici un exemple d’un fichier
de données avec des tags de type “cat” :

``the,.9630``\ ¶

``those,.236``\ ¶

``eyes,.32``\ ¶

``DET+Ddef   the,.9630``\ ¶

``DET+Ddem   those,.140``\ ¶

``PRO+Pdem   those,.96``\ ¶

``N        eyes,.32``\ ¶

``DET    N,.62541``\ ¶

``PREP  DET  N,.25837``\ ¶

¶

Voici un exemple d’un fichier de données avec des tags de type “morph” :

``the,.9630``\ ¶

``those,.236``\ ¶

``eyes,.32``\ ¶

``DET+Ddef:s     the,.4437``\ ¶

``DET+Ddef:p     the,.5193``\ ¶

``DET+Ddem:p     those,.140``\ ¶

``PRO+Pdem:p     those,.96``\ ¶

``N:p          eyes,.32``\ ¶

``DET:s  N:s,.18489``\ ¶

``PREP    DET:s  N:s,.6977``\ ¶

¶

Une ligne spécifique est ajoutée à des fichiers de données afin de
déterminer si le fichier contient des tags de type “cat” ou “morph”.

Cette ligne contient ``CODE FEATURES`` suivie soit le nombre 0 pour
“cat” tags ou 1 pour “morph”.

REMARQUE: À l’étape finale, TrainingTagger comprime ces deux fichiers de
données au format ``.bin``.

Fichier de configuration
------------------------

Fichier Config
~~~~~~~~~~~~~~

Lorsque l’utilisateur modifie ses préférences pour une langue donnée,
celles-ci sont sauvegardées dans un fichier texte nommé ``Config`` qui
se trouve dans le répertoire de la langue courante. Ce fichier a la
syntaxe suivante (l’ordre des lignes peut varier) :

``#Unitex configuration file of 'paumier' for 'English'``\ ¶

``#Fri Oct 10 15:18:06 CEST 2008``\ ¶

``TEXT\ FONT\ NAME=Courier New``\ ¶

``TEXT\ FONT\ STYLE=0``\ ¶

``TEXT\ FONT\ SIZE=10``\ ¶

``CONCORDANCE\ FONT\ NAME=Courier new``\ ¶

``CONCORDANCE\ FONT\ HTML\ SIZE=12``\ ¶

``INPUT\ FONT\ NAME=Times New Roman``\ ¶

``INPUT\ FONT\ STYLE=0``\ ¶

``INPUT\ FONT\ SIZE=10``\ ¶

``OUTPUT\ FONT\ NAME=Arial Unicode MS``\ ¶

``OUTPUT\ FONT\ STYLE=1``\ ¶

``OUTPUT\ FONT\ SIZE=12``\ ¶

``DATE=true``\ ¶

``FILE\ NAME=true``\ ¶

``PATH\ NAME=false``\ ¶

``FRAME=true``\ ¶

``RIGHT\ TO\ LEFT=false``\ ¶

``BACKGROUND\ COLOR=-1``\ ¶

``FOREGROUND\ COLOR=-16777216``\ ¶

``AUXILIARY\ NODES\ COLOR=-3289651``\ ¶

``COMMENT\ NODES\ COLOR=-65536``\ ¶

``SELECTED\ NODES\ COLOR=-16776961``\ ¶

``PACKAGE\ NODES\ COLOR=-2302976``\ ¶

``CONTEXT\ NODES\ COLOR=-16711936``\ ¶

``CHAR\ BY\ CHAR=false``\ ¶

``ANTIALIASING=false``\ ¶

``HTML\ VIEWER=``\ ¶

``MAX\ TEXT\ FILE\ SIZE=2097152``\ ¶

``ICON\ BAR\ POSITION=West``\ ¶

``PACKAGE\ PATH=D\:\\repository``\ ¶

``MORPHOLOGICAL\ DICTIONARY=D\:\\MyUnitex\\English\\Dela\\zz.bin``\ ¶

``MORPHOLOGICAL\ NODES\ COLOR=-3911728``\ ¶

``MORPHOLOGICAL\ USE\ OF\ SPACE=false``\ ¶

Les deux premières lignes sont des lignes de commentaires. Les trois
lignes suivantes indiquent le nom, le style et la taille de la police
utilisée pour afficher les textes, les dictionnaires, les unités
lexicales, les phrases de l’automate du texte, etc.

The ``CONCORDANCE FONT NAME`` et ``CONCORDANCE FONT HTML SIZE``
définissent le nom et la taille de la police à utiliser pour afficher
les concordances en HTML. La taille de la police doit être comprise
entre 1 et 7.

Les paramètres ``INPUT FONT ...`` et ``OUTPUT FONT ...`` définissent le
nom, le style et la taille des polices utilisées pour afficher les
chemins et les transductions des graphes.

Les 10 paramètres suivants correspondent aux paramètres précisés dans
les en-têtes des graphes. Le tableau [tab-parameters] décrit ces
correspondances.

+----------------------------------------------+--------------------------------------------+
| Paramètres dans le fichier ``Config`` file   | Paramètres dans un fichier ``.grf`` file   |
+==============================================+============================================+
| ``DATE``                                     | ``DDATE``                                  |
+----------------------------------------------+--------------------------------------------+
| ``FILE NAME``                                | ``DFILE``                                  |
+----------------------------------------------+--------------------------------------------+
| ``PATH NAME``                                | ``DDIR``                                   |
+----------------------------------------------+--------------------------------------------+
| ``FRAME``                                    | ``DFRAME``                                 |
+----------------------------------------------+--------------------------------------------+
| ``RIGHT TO LEFT``                            | ``DRIG``                                   |
+----------------------------------------------+--------------------------------------------+
| ``BACKGROUND COLOR``                         | ``BCOLOR``                                 |
+----------------------------------------------+--------------------------------------------+
| ``FOREGROUND COLOR``                         | ``FCOLOR``                                 |
+----------------------------------------------+--------------------------------------------+
| ``AUXILIARY NODES COLOR``                    | ``ACOLOR``                                 |
+----------------------------------------------+--------------------------------------------+
| ``COMMENT NODES COLOR``                      | ``SCOLOR``                                 |
+----------------------------------------------+--------------------------------------------+
| ``SELECTED NODES COLOR``                     | ``CCOLOR``                                 |
+----------------------------------------------+--------------------------------------------+

Table: Signification des paramètres[tab-parameters]

Le paramètre ``PACKAGE NODES`` définit la couleur des appels à des
sous-graphes du répertoire de dépôt.

Le paramètre ``CONTEXT NODES`` définit la couleur des boîtes
correspondant à des débuts ou fins de contextes.

Le paramètre ``CONTEXT NODES`` indique si la langue courante doit être
traitée en mode caractère par caractère ou non.

Le paramètre ``ANTIALIASING`` indique si les graphes ainsi que les
automates de phrases doivent être affichés par défaut avec l’effet
d’antialiasing.

Le paramètre ``HTML VIEWER`` indique le nom du navigateur à utiliser
pour afficher les concordances. Si aucun nom de navigateur n’est
précisé, les concordances sont affichées dans une fenêtre d’Unitex.

Le paramètre ``MAX TEXT FILE SIZE`` n’est plus utlisé.

Le paramètre ``ICON BAR POSITION`` définit la position de la barre
d’icônes dans les fenêtres de graphes.

Le paramètre ``PACKAGE PATH`` définit le répertoire de dépôt à utiliser
pour cette langue.

Le paramètre ``MORPHOLOGICAL DICTIONARY`` indique la liste des
dictionnaires du mode morphologique, séparés par des points virgules.

Le paramètre ``MORPHOLOGICAL NODES COLOR`` définit la couleur des
étiquettes du mode morphologique ``$<`` et ``$>``.

Le paramètre ``MORPHOLOGICAL USE OF SPACE`` indique si le programme
``Locate`` peut commencer en reconnaissant les espaces. (par défaut
c’est non)

Fichier system\_dic.def
~~~~~~~~~~~~~~~~~~~~~~~

Le fichier ``system_dic.def`` est un fichier texte décrivant la liste
des dictionnaires du système à appliquer par défaut. Ce fichier se
trouve dans le répertoire de la langue courante. Chaque ligne correspond
à un nom de fichier ``.bin`` file. Les dictionnaires du système doivent
se trouver dans le répertoire système Unitex, à l’intérieur du
sous-répertoire ``(langue courante)/Dela``. Voici un exemple de
fichier :

``delacf.bin``\ ¶

``delaf.bin``\ ¶

Fichier user\_dic.def
~~~~~~~~~~~~~~~~~~~~~

Le fichier ``user_dic.def`` est un fichier texte décrivant la liste des
dictionnaires de l’utilisateur à appliquer par défaut. Ce fichier se
trouve dans le répertoire de la langue courante et a le même format que
le fichier ``system_dic.def``. Les dictionnaires de l’utilisateur
doivent se trouver dans le sous-répertoire ``(langue courante)/Dela`` du
répertoire personnel de travail.

Fichiers (nom d’utilisateur).cfg et .unitex.cfg
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Sous Linux et Mac OS, Unitex considère que le répertoire personnel de
travail se nomme ``unitex`` et qu’il se trouve dans le répertoire racine
de l’utilisateur (``$HOME``). Si vous voulez changer cet emplacement par
défaut, un fichier ``.unitex.cfg`` est créé dans votre répertoire
racine, et il contient le chemin vers votre répertoire de travail
Unitex. Ce fichier est un fichier UTF8. Si ``.unitex.cfg`` ne contient
pas un chemin Linux valide vers un répertoire existant, il est
ignoré [1]_.

Sous Windows, il n’est pas toujours possible d’associer un répertoire
par défaut à un utilisateur. Pour remédier à cela, Unitex crée pour
chaque utilisateur un fichier ``.cfg`` contenant le chemin de son
répertoire de travail. Ce fichier est sauvegardé sous le nom
``(nom d’utilisateur).cfg`` dans le sous-répertoire ``Users`` du
répertoire système Unitex. Si l’utilisateur n’a pas les droits pour
écrire dans ce répertoire, un fichier ``.unitex.cfg`` est sauvegardé
dans le répertoire du profil utilisateur :

-  dans ``Documents and Settings\(user login)`` sous Windows XP

-  dans ``Users\(user login)`` sous WindowsVista ou une version plus
   récente.

ATTENTION : CE FICHIER N’EST PAS EN UNICODE ET LE CHEMIN DU RÉPERTOIRE
PERSONNEL DE TRAVAIL N’EST PAS SUIVI PAR UN RETOUR À LA LIGNE.

Fichiers CasSys
---------------

Fichiers de configuration CasSys csc
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Pour mémoriser la liste des transducteurs d’une cascade CasSys, nous
utilisons un fichier texte (csc) dans lequel chaque ligne contient le
chemin vers un transducteur suivi du mode de sortie (fusionner /
remplacer) à appliquer à ce transducteur. Le format d’une ligne du
fichier csc est : Name\_and\_path\_of\_transducer Merge Voici un exemple
de fichier de cascade csc:

“C:\ :math:`\backslash`\ apps\ :math:`\backslash`\ my\_unitex\ :math:`\backslash`\ French\ :math:`\backslash`\ Graphs\ :math:`\backslash`\ grf1.fst2”
Merge

“C:\ :math:`\backslash`\ apps\ :math:`\backslash`\ my\_unitex\ :math:`\backslash`\ French\ :math:`\backslash`\ Graphs\ :math:`\backslash`\ grf2.fst2”
Replace

Plusieurs autres fichiers
-------------------------

Pour chaque texte, Unitex crée plusieurs fichiers contenant des
informations destinées à être affichées dans l’interface graphique.
Cette section décrit ces différents fichiers.

Fichier dlf.n, dlc.n, err.n et tags\_err.n
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Ces trois fichiers sont des fichiers texte se trouvant dans le
répertoire du texte. Ils contiennent respectivement les nombres de
lignes des fichiers ``dlf``, ``dlc``, ``err`` et ``tags_err``. Ces
nombres sont suivis par un retour à la ligne.

Fichier stat\_dic.n
~~~~~~~~~~~~~~~~~~~

Ce fichier est un fichier texte se trouvant dans le répertoire du texte.
Il est formé de trois lignes, contenant les nombres de lignes des
fichiers ``dlf``, ``dlc`` and ``err``.

Fichier stats.n
~~~~~~~~~~~~~~~

Ce fichier texte se trouve dans le répertoire du texte et contient une
ligne de la forme suivante :

``3949 sentence delimiters, 169394 (9428 diff) tokens, 73788 (9399)``

``simple forms, 438 (10) digits``\ ¶

Les nombres indiqués s’interprètent de la façon suivante :

-  ``sentence delimiters``: nombre de séparateurs de phrases (``{S}``);

-  ``tokens``: nombre total d’unités lexicales du texte. Le nombre
   précédant ``diff`` indique le nombre d’unités différentes;

-  ``simple forms``: nombre total dans le texte d’unités lexicales
   composées de lettres. Le nombre entre parenthèses représente le
   nombre d’unités lexicales différentes qui sont composées de lettres ;

-  ``digits``: nombre total dans le texte de chiffres. Le nombre entre
   parenthèses indique le nombre de chiffres différents utilisés (au
   plus 10).

Fichier concord.n
~~~~~~~~~~~~~~~~~

Le fichier ``concord.n`` est un fichier texte qui se trouve dans le
répertoire du texte. Il contient des informations sur la dernière
recherche de motifs effectuée sur ce texte et se présente de la manière
suivante :

``6 matches``\ ¶

``6 recognized units``\ ¶

``(0.004% of the text is covered)``\ ¶

La première ligne donne le nombre d’occurrences trouvées, la seconde le
nombre d’unités couvertes par ces occurrences. La troisième ligne
indique le rapport entre le nombre d’unités couvertes et le nombre total
d’unités du texte.

Fichier concord\_tfst.n
~~~~~~~~~~~~~~~~~~~~~~~

Le fichier ``concord_tfst.n`` est un fichier texte qui se trouve dans le
répertoire du texte. Il contient des informations sur la dernière
recherche sur l’automate du texte et ressemble à ce qui suit:

``23 matches(45 outputs)``\ ¶

Fichier règles de normalisation
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

[section-normalization-file] Ce fichier est utilisé par les programmes
``Normalization`` et ``XMLizer``. Il représente règles de normalisation.
Chaque ligne représente une règle, selon le format suivant
(:math:`\longmapsto` représente le caractère de tabulation):

``input sequence`` :math:`\longmapsto` ``output sequence``

Si vous souhaitez utiliser la tabulation ou le newline, vous devez les
déspécialiser avec un antislash comme ceci:

``123\``

:math:`\longmapsto` ``ONE_TWO_THREE_NEW_LINE``

Fichier de mots interdits
~~~~~~~~~~~~~~~~~~~~~~~~~

[section-forbidden-words] Le programme ``PolyLex`` requiert un de mots
interdits pour le hollandais et le norvégien. Ce fichier texte brut est
censé s’appeler ``ForbiddenWords.txt`` . Il doit se trouver dans le
répertoire ``Dela`` correspondant à la langue courante. Chaque ligne est
censée contenir un mot interdit.

Fichier de log
~~~~~~~~~~~~~~

[section-log-file] Le programme ``UnitexToolLogger``, si le fichier
``unitex_logging_parameters.txt`` est trouvé avec un chemin (pour
enregistrer les fichiers log) crée un fichier .ulp de log de l’outil
Unitex en cours d’exécution choisi.

Il crée un fichier ``unitex_logging_parameters_count.txt`` qui contient
seulement le numéro du dernier fichier log créé.

Un fichier log (avec l’extension .ulp) est un fichiers zip non
comprimés, compatibles avec unzip et tous les outils unzip standards. On
peut le recréer avec zip d’Infozip (avec les options -0 -X). Il contient
ces fichiers:

-  ``test_info/command_line.txt``: une liste de paramètres de la ligne
   de commande utilisée pour exécuter l’outil. Il y a un paramètre sur
   chaque ligne. La première ligne contient la valeur de retour, la
   deuxième ligne le nombre de paramètres;

-  ``test_info/command_line_synth.txt``: une simple ligne avec un résumé
   de la ligne de commande utilisée pour exécuter l’outil;

-  ``test_info/list_file_in.txt``: une liste des fichiers lus par
   l’outil. La première colonne est la taille du fichier, la seconde est
   crc32, la troisième le nom du fichier;

-  ``test_info/list_file_out.txt``: une liste des fichiers créés par
   l’outil. La première colonne est la taille du fichier, la seconde est
   crc32, la troisième le nom du fichier;

-  ``test_info/std_out.txt``: le contenu de sortie standard de la
   console;

-  ``test_info/std_err.txt``: le contenu de sortie erreurs de la
   console;

-  ``src/xxx``: une copie du fichier lu par l’outil (nécessaire pour
   faire fonctionner à nouveau le log);

-  ``dest/xxx``: une copie du fichier créé par l’outil

Si la seconde ligne de unitex\_logging\_parameters.txt contient 0, ces
fichiers ne sont pas enregistrés; si cette ligne contient 1, ils sont
enregistrés;

Règles typographiques de l’arabe: arabic\_typo\_rules.txt
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Pour l’arabe, la recherche dans le dictionnaire peut être paramétrée
avec un fichier qui décrit si certaines variations typographiques sont
autorisées ou non. Ce fichier est constitué de lignes comme celles-ci:

``fatha omission=YES``

où ``fatha omission`` est le nom de la règle. Pour une description
complète de toutes les règles disponibles, il faut consulter le fichier
``Arabic.h`` dans les sources du programme.

fichier d’offsets de différence
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Les fichiers d’offsets de différence sont lu et écrit par l’outils
Unxmlize([section-Unxmlize]), DumpOffsets([section-DumpOffsets]),
Normalize([section-Normalize]), Fst2Txt([section-Fst2Txt]),
Tokenize([section-Tokenize]), Concord([section-Concord]) et GrfTest, et
lu par Tokenize([section-Tokenize]). Ces fichiers textes sont
constituées de lignes contenant 4 entiers A B C D. Chaque ligne
correspond à une modification du texte, exprimée de la façon suivante:
l’intervalle [A;B[ du texte \*\*\* avant tout traitement \*\*\* est
remplacé par l’intervalle [C;D[ après traitement, A, B, C et D étant des
positions en caractères dans les fichiers textes.

Par exemple, si on applique le programme Normalize sur le texte “Hello
world” (avec deux espaces entre les deux mots), on aura une ligne comme
ceci:

``5 7 5 6``

signifiant qu’une séquence de deux caractères (les 2 espaces) a été
remplacée par une séquence d’un seul caractère.

Le principe est donc de produire un nouveau fichier d’offsets pour
chaque application de programme modifiant le texte, en prenant en entrée
le fichier d’offsets produit par le programme précédent. Ainsi, en
regardant le dernier fichier d’offsets produit, on sait que pour chaque
ligne A B C D, l’intervalle [C;D[ dans le fichier .snt correspond à
l’intervalle [A;B[ dans le fichier .txt de départ

fichier d’offsets de zone commune
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Les fichiers d’offsets de zone commune sont lu et écrit par DumpOffsets.
Ces fichiers textes sont constituées de lignes contenant 4 entiers A B C
D. Chaque ligne correspond à une modification du texte, exprimée de la
façon suivante: l’intervalle [A;B[ du texte original correspond à
l’intervalle [C;D[ après traitement, A, B, C et D étant des positions en
caractères dans les fichiers textes. Sur chaque ligne, B-A=D-C.

Par exemple, si on applique le programme Normalize sur le texte “Hello
world” (avec deux espaces entre les deux mots), on aura une ligne comme
ceci:

``0 5 0 5`` ``7 12 6 11``

signifiant que les caractère de 0 (inclus) à 5 (non inclus) des deux
fichiers contiennent exactement le même texte, et que ceux de 7 (inclus)
à 12 (non inclus) du premier texte contiennent exactement le même texte
que ceux de 6 (inclus) à 11 (non inclus) du second.

fichier d’offsets uima
~~~~~~~~~~~~~~~~~~~~~~

Les fichiers d’offsets uima sont écrit par Tokenize et lu par Concord
(avec les options ``--uima=``, ``--xml-with-header=`` ou ``--xml=``).
Ces fichiers établissent la correspondance entre chaque token successif
et une position dans le fichier d’origine.

Ces fichiers textes sont constituées de lignes contenant 3 entiers A B C
et de texte entre < et >.

Chaque ligne correspond à un token, exprimée de la façon suivante: Le
token numéro A correspond au texte de la position B (inclue) à la
position C (non inclus) du fichier d’origine, et le texte de ce token
est mentionné entre < et >. Le numéro de token A correspond au numéro de
ligne de tokens.txt où figure ce token (après avoir ajouté 1 pour la
ligne d’en-tête de tokens.txt([fichier-tokens-txt]))

.. [1]
   Cela permet de lancer Unitex tantôt sous Linux, tantôt sous Windows,
   sur des fichiers partagés : le chemin Windows vers le répertoire
   personnel de travail Unitex est indiqué dans ``.unitex.cfg``, et
   Unitex l’ignore quand on le lance sous Linux.

.. |image| image:: resources/img/korean_letters.png
   :height: 0.50000cm
.. |image| image:: resources/img/thai_letter.png
   :height: 0.30000cm
