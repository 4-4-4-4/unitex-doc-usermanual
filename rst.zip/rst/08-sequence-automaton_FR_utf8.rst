Automate de Séquences
=====================

La construction de grammaires locales peut être un long processus durant
lequel le linguiste répète de nombreuses fois les mêmes opérations. La
finalité du programme ``Seq2Grf`` est de produire rapidement et
automatiquement des grammaires locales.

Ce programme peut être utilisé en ligne de commande ou en cliquant sur
“Construct Sequences Automaton” dans le menu “Text”. L’utilisation de la
commande ``Seq2Grf`` est décrite à la section [Seq2Grf].

Pour un document donné (``TEILite`` ou des fichiers au format ``txt`` ou
``SNT`` quand ils sont prétraités pour cette tâche avec des marqueurs
``{STOP}``) ce programme construit un unique automate qui reconnaît
toutes les séquences contenues dans le document.

On doit porter une attention particulière à la construction de la liste
de séquences qui doivent être reconnues par le graphe.

Ce chapitre présente les formats de fichiers supportés par le programme
``Seq2Grf``, la construction de l’automate de séquences et l’utilisation
de jokers.

Corpus de séquences
-------------------

Nous appelons *corpus de séquences* ou *corpus qualifié* une liste de
séquences d’un ou plusieurs mots que l’on veut reconnaître par une
grammaire locale représentée par un seul graphe.

Le corpus de séquences est stocké dans un seul fichier qui peut avoir
l’un des formats suivants :

-  fichiers texte brut, dans lequel les séquences sont délimitées par
   des fins de lignes

-  fichiers ``SNT`` déjà prétraités par ce menu : les séquences sont
   délimitées par ``{STOP}``

-  fichiers ``TEILite`` dont les séquences sont délimitées par un tag
   ``xml`` de la forme : ``<seg type="sequence">example</seg>}``

Puisque le corpus contient des séquences spécifiques, il doit être fait
à la main. Cela signifie que vous devez soit écrire toutes les séquences
dans un fichier texte brut et les séparer par une fin de ligne
(figure [fig8-1CorpusTxt]), soit insérer la balise ``XML`` spécifique
dans un document existant ``TEILite`` (figure [fig8-3CorpusTEI]). Le
prétraitement des documents ``TXT`` ou ``XML`` génère un fichier ``SNT``
qui est utilisé pour la construction de l’automate de séquences
(figure [fig8-2CorpusSNT]). Ce fichier peut être utilisé comme une
entrée. Le graphe produit ne reconnaîtra que les séquences qui sont
correctement délimitées. La production de grammaires locales est
automatique uniquement à partir d’un corpus de séquences bien définies.
Si vous disposez d’un tel corpus, alors le gain de temps est
considérable.

[h!]0.5 |SNT[fig8-2CorpusSNT]|

[h!]0.5 |SNT[fig8-2CorpusSNT]|

[h!] |TEILite[fig8-3CorpusTEI]|

Utilisation
-----------

Pour créer un automate de séquences, cliquez sur “Séquence Construct
Automate” dans le menu “Text”. Vous verrez alors apparaître la fenêtre
de la figure [fig8-4Menu1].

Cette fenêtre vous permet de définir les paramètres pour produire un
automate séquence. Vous devez suivre ces trois étapes :

-  choisissez le corpus séquences : celui-ci peut être un fichier dont
   le format est l’un des trois formats décrits dans la section
   précédente. Le format de fichier est automatiquement détecté en
   fonction de l’extension de fichier.

-  définissez les options spécifiques : “Apply the beautifying
   algorithm” placera chaque boîte de manière à ce que le graphe
   résultant soit le plus petit et le plus facile à lire que possible.
   “Exact case matching” mettra les tokens littéraux entre accolades
   dans le graphe afin que ceui-ci ne reconnaisse pas des tokens avec
   les mêmes lettres mais avec des différences de casse.

   Vous pouvez définir des options supplémentaires pour produire un
   graphe qui permet une reconnaissance approximative : vous pouvez
   fixer le nombre de jokers à utiliser pour produire de nouvelles
   séquences dérivées des séquences du corpus original, et choisir le
   joker approprié. Tous les détails sur l’utilisation des jokers se
   trouvent dans la section [approximation]

-  choisissez le répertoire où le graphe sera enregistré.

[h!]0.5 |Menu options de l’automate de séquences[fig8-4Menu2]|

[h!]0.5 |Menu options de l’automate de séquences[fig8-4Menu2]|

Vous pouvez voir figures [fig8-5GRFnoBeautify] et  [fig8-6GRFBeautify]
les graphes sans jokers produits avec ou sans “beautify”.

[h!]0.5 |Automate avec l’option “beautify”[fig8-6GRFBeautify]|

[h!]0.5 |Automate avec l’option “beautify”[fig8-6GRFBeautify]|

Recherche par approximation
---------------------------

Lorsque vous effectuez un “Locate” sur un texte en utilisant un graphe
produit avec le programme ``Seq2Grf``, vous trouverez uniquement des
séquences présentes dans le corpus de séquences original. Des séquences
proches de celles du corpus original peuvent être présentes dans le
texte et être ignorées parce qu’elles ne figurent pas dans ce corpus.
Ces séquences devraient être incluses dans l’automate de séquences. Afin
d’inclure ces séquences, vous devez appliquer les trois sortes de jokers
et produire ainsi un graphe qui reconnaît toutes les séquences du
corpus, et les nouvelles séquences . Chaque joker, permet d’appliquer
une opération pour générer de nouvelles séquences.

-  insertion : pour chaque séquence, ajouter à l’automate toutes les
   séquences où ``<TOKEN>`` a été inséré entre deux mots de la séquence
   originale.

-  remplacement : pour chaque séquence, ajouter à l’automate toutes les
   séquences où :math:`i` tokens ont été remplacés par ``<TOKEN>``

-  suppression: pour chaque séquence, ajouter à l’automate toutes les
   séquences où un token a été supprimé

Chacune de ces opérations peut être appliquée plusieurs fois aux
séquences originales. L’application de cette grammaire à un texte permet
d’introduire des approximations dans la recherche des séquences du
texte.

Si les jokers sont utilisés, les graphes produits suivent les règles
suivantes :

-  les séquences originales et les séquences dérivées sont incluses dans
   l’automate,

-  aucune séquence vide, ni une séquence composée uniquement de jokers
   ne seront ajoutées à ce graphe (de telles séquences peuvent être
   produites par des suppressions ou des remplacements sur des séquences
   courtes)

-  pas d’insertion de jokers au début ou à la fin d’une séquence

-  chaque token d’une séquence y compris le premier et le dernier
   peuvent être remplacés par un joker

Les graphes produits en utilisant des jokers contiennent de nombreuses
séquences erronées et doivent être confrontées avec le corpus au moyen
de ``Locate`` pour ne garder que les séquences pertinentes. Ces
séquences peuvent être utilisées pour produire un nouveau graphe, que
vous voudrez peut-être garder.

Le graphe de la figure  [fig8-7GRF1replace] a été produit avec
remplacement de 1 token et avec l’option “beautifying” activée. (cf.
figure  [fig8-2CorpusSNT])

.. figure:: resources/img/fig8-7GRF1replace.png
   :alt: Automate avec un remplacement permis[fig8-7GRF1replace]
   :width: 8.00000cm

   Automate avec un remplacement permis[fig8-7GRF1replace]

.. |SNT[fig8-2CorpusSNT]| image:: resources/img/fig8-1tomorrow.png
.. |SNT[fig8-2CorpusSNT]| image:: resources/img/fig8-2tomorrowSNT.png
.. |TEILite[fig8-3CorpusTEI]| image:: resources/img/fig8-3tomorrowTEI.png
   :width: 14.00000cm
.. |Menu options de l’automate de séquences[fig8-4Menu2]| image:: resources/img/fig8-4Menu1.png
   :width: 8.00000cm
.. |Menu options de l’automate de séquences[fig8-4Menu2]| image:: resources/img/fig8-4Menu2.png
   :width: 8.00000cm
.. |Automate avec l’option “beautify”[fig8-6GRFBeautify]| image:: resources/img/fig8-5GRFnoBeautify.png
   :width: 8.00000cm
.. |Automate avec l’option “beautify”[fig8-6GRFBeautify]| image:: resources/img/fig8-6GRFBeautify.png
   :width: 8.00000cm
