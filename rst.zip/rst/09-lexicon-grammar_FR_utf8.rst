Lexique-grammaire
=================

Les tables de lexique-grammaire sont un moyen compact de représenter les
propriétés syntaxiques des éléments d’une langue. Il est possible de
construire automatiquement des grammaires locales à partir de ces
tables, grâce à un mécanisme de graphes paramétrés.

La première partie de ce chapitre présente le formalisme de ces tables.
La seconde partie décrit les graphes paramétrés et le mécanisme de
génération automatique de graphes à partir d’une table de
lexique-grammaire.

Les tables de lexique-grammaire
-------------------------------

Le lexique-grammaire est une méthodologie qui a été développée par
Maurice Gross et son équipe du LADL (:raw-latex:`\cite{L}`,
:raw-latex:`\cite{BGL}`, :raw-latex:`\cite{methodes-en-syntaxe}`,
:raw-latex:`\cite{GL}`, :raw-latex:`\cite{gross1994}`,
:raw-latex:`\cite{gross1994b}`, :raw-latex:`\cite{gross1991}`,
:raw-latex:`\cite{gross1986}`, :raw-latex:`\cite{gross1984}`,
:raw-latex:`\cite{gross1984b}`, :raw-latex:`\cite{gross1983}`,
:raw-latex:`\cite{gross1982}`, :raw-latex:`\cite{gross1978}`,
:raw-latex:`\cite{leclere2005}`, :raw-latex:`\cite{salkoff2004}`) sur le
principe suivant : chaque verbe a des propriétés syntaxiques quasiment
uniques. De ce fait, ces propriétés doivent être systématiquement
décrites, car il est impossible de prévoir le comportement précis d’un
verbe. Ces descriptions systématiques sont représentées au moyen de
matrices où les lignes correspondent aux verbes, et les colonnes aux
propriétés syntaxiques. Les propriétés considérées sont des propriétés
formelles telles que le nombre et la nature des compléments admis par le
verbe et les différentes transformations que ce verbe peut subir
(passivation, nominalisation, extraposition, etc.). Les matrices, plus
souvent appelées tables, sont binaires : un signe ``+`` apparaît à
l’intersection d’une ligne et d’une colonne d’une propriété si le verbe
vérifie la propriété, un signe ``-`` sinon. Pour plus d’information
consulter http://infolingu.univ-mlv.fr, où des tables du
lexique-grammaire sont librement téléchargeables.

Ce type de description a aussi été utilisé pour les adjectifs
(:raw-latex:`\cite{these-annie}`), les noms prédicatifs
(:raw-latex:`\cite{les-nominalisations}`,
:raw-latex:`\cite{les-predicats-nominaux}`,
:raw-latex:`\cite{giry1978}`, :raw-latex:`\cite{gross1976}`,
:raw-latex:`\cite{ranchhod2001}`), adverbes
(:raw-latex:`\cite{syntaxe-de-ladverbe}`,
:raw-latex:`\cite{grammaire-des-adverbes}`), ou les expressions figées,
dans de nombreuses langues
(:raw-latex:`\cite{lexique-grammaire-allemand2}`,
:raw-latex:`\cite{lexique-grammaire-italien2}`,
:raw-latex:`\cite{lexique-grammaire-italien}`,
:raw-latex:`\cite{lexique-grammaire-coreen2}`,
:raw-latex:`\cite{lexique-grammaire-coreen}`,
:raw-latex:`\cite{lexique-grammaire-malgache}`,
:raw-latex:`\cite{lexique-grammaire-espagnol}`,
:raw-latex:`\cite{lexique-grammaire-allemand}`,
:raw-latex:`\cite{lexique-grammaire-hongrois}`,
:raw-latex:`\cite{ranchhod1996}`, :raw-latex:`\cite{ranchhod1991}`,
:raw-latex:`\cite{gross1986b}`).

La figure [fig-table-32NM] montre un exemple de table de
lexique-grammaire. Cette table concerne les verbes admettant un
complément numérique.

.. figure:: resources/img/fig8-1.png
   :alt: Table de lexique-grammaire 32NM[fig-table-32NM]
   :width: 15.00000cm

   Table de lexique-grammaire 32NM[fig-table-32NM]

Conversion d’une table en graphes
---------------------------------

Principe des graphes paramétrés
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

La conversion d’une table en graphes s’effectue au moyen du mécanisme
des graphes paramétrés. Le principe est le suivant : on construit un
graphe qui décrit des constructions possibles. Ce graphe fait référence
aux colonnes de la table grâce à des variables. On génère ensuite, pour
chaque ligne de la table, une copie de ce graphe dans laquelle les
variables sont remplacées en fonction du contenu des cellules situées à
l’intersection des colonnes correspondantes et de la ligne traitée. Si
une cellule de la table contient le signe ``+`` la variable
correspondante est remplacée par ``<E>``. Si la cellule contient le
signe ``-``,la boîte contenant la variable correspondante est supprimée,
ce qui détruit du même coup les chemins passant par cette boîte. Dans
tous les autres cas, la variable est remplacée par le contenu de la
cellule.

Format de la table
~~~~~~~~~~~~~~~~~~

Les tables de lexique-grammaire sont généralement codées à l’aide d’un
tableur comme OpenOffice.org Calc (:raw-latex:`\cite{OpenOffice}`). Pour
pouvoir être utilisées par Unitex, les tables doivent être codées en
texte Unicode selon la convention suivante : les colonnes doivent être
séparées par des tabulations et les lignes par des retours à la ligne.

Pour convertir une table avec OpenOffice.org Calc, sauvegardez-la au
format texte (extension ``.csv``). Le programme vous propose ensuite de
paramétrer la sauvegarde au moyen d’une fenêtre comme celle de la
figure [fig-csv-export]. Choisissez le codage “Unicode”, sélectionnez la
tabulation comme séparateur de colonnes, et ne précisez pas de
délimiteur de texte.

.. figure:: resources/img/fig8-2.png
   :alt: Configuration de la sauvegarde d’une table avec OpenOffice.org
   Calc[fig-csv-export]
   :width: 12.00000cm

   Configuration de la sauvegarde d’une table avec OpenOffice.org
   Calc[fig-csv-export]

Lors de la génération des graphes, Unitex saute la première ligne,
considérée comme donnant les en-têtes des colonnes. Vous devez donc vous
assurer que les en-têtes des colonnes occupent exactement une ligne.
S’il n’y a pas de ligne d’en-tête, la première ligne de la table sera
ignorée, et s’il y a plusieurs lignes d’en-tête, elles seront
interprétées à partir de la deuxième comme des lignes de la table.

Les graphes paramétrés
~~~~~~~~~~~~~~~~~~~~~~

Les graphes paramétrés sont des graphes dans lesquels apparaissent des
variables fai- sant référence aux colonnes d’une table de
lexique-grammaire. On utilise généralement ce mécanisme avec des graphes
syntaxiques, mais rien n’empêcherait de construire des graphes
paramétrés de flexion, de prétraitement ou de normalisation.

Les variables qui font référence aux colonnes sont formées du caractère
``@`` suivi d’un nom de colonne en lettres majuscules (les colonnes sont
numérotées en partant de ``A``).

Exemple: ``@C`` fait référence à la troisième colonne de la table.

Lorsqu’une variable doit être remplacée par un ``+`` ou un ``-``, le
signe ``-`` correspond à la suppression du chemin passant par cette
variable. Il est possible d’effectuer l’opération contraire en faisant
précéder le caractère ``@`` d’un point d’exclamation. Dans ce cas, c’est
lorsque la variable renvoie à un signe ``+`` que le chemin est supprimé.
Si la variable ne renvoie ni à un signe ``+`` ni à un signe ``-``, elle
est remplacée par le contenu de la cellule.

Il existe également une variable spéciale ``@%`` qui est remplacée par
le numéro de la ligne dans la table. Le fait que sa valeur soit
différente pour chaque ligne permet de l’utiliser pour caractériser
facilement une ligne. Cette variable n’est pas affectée par la présence
d’un point d’exclamation à sa gauche.

La figure [fig-reference-graph] montre un exemple de graphe paramétré
conçu pour être appliqué à la table de lexique-grammaire table 31H
présentée sur la figure [fig-table-31H].

.. figure:: resources/img/fig8-3.png
   :alt: Exemple de graphe paramétré[fig-reference-graph]
   :width: 15.00000cm

   Exemple de graphe paramétré[fig-reference-graph]

.. figure:: resources/img/fig8-4.png
   :alt: Table de lexique-grammaire 31H[fig-table-31H]
   :width: 15.00000cm

   Table de lexique-grammaire 31H[fig-table-31H]

Génération automatique de graphes
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Pour pouvoir générer des graphes à partir d’un graphe paramétré et d’une
table, il faut tout d’abord ouvrir la table en cliquant sur “Open...”
dans le menu “Lexicon-Grammar” (voir figure [fig-lexicon-grammar-menu]).
La table doit avoir été préalablement convertie en texte Unicode.

.. figure:: resources/img/fig8-5.png
   :alt: Menu “Lexicon-Grammar”[fig-lexicon-grammar-menu]
   :width: 12.00000cm

   Menu “Lexicon-Grammar”[fig-lexicon-grammar-menu]

La table sélectionnée est alors affichée dans une fenêtre (voir
figure [fig-table-display]). Si elle n’apparaît pas sur l’écran, elle
peut être occultée par d’autres fenêtres Unitex.

.. figure:: resources/img/fig8-6.png
   :alt: Displaying a table[fig-table-display]
   :width: 15.00000cm

   Displaying a table[fig-table-display]

Pour générer automatiquement des graphes à partir d’un graphe paramétré,
cliquez sur “Compile to GRF...” dans le menu “Lexicon-Grammar”. La
fenêtre de la figure [fig-configuration-graph-generation] apparaît
alors.

.. figure:: resources/img/fig8-7.png
   :alt: Configuration de la génération automatique de
   graphes[fig-configuration-graph-generation]
   :width: 9.00000cm

   Configuration de la génération automatique de
   graphes[fig-configuration-graph-generation]

Dans le cadre “Reference Graph (in GRF format)”, indiquez le nom du
graphe paramétré à utiliser. Dans le cadre “Resulting GRF grammar”,
indiquez le nom du graphe principal qui sera généré. Ce graphe principal
est un graphe faisant appel à tous les graphes qui auront été générés.
En lançant une recherche dans un texte avec ce graphe, vous appliquerez
ainsi simultanément tous les graphes générés.

Le cadre “Name of produced subgraphs” permet de préciser le nom des
graphes qui seront générés. Afin d’être certain que tous les graphes
auront des noms distincts, il est conseillé d’utiliser la variable
``@%``, cette variable sera remplacée pour chaque entrée par le numéro
de celle-ci, garantissant ainsi que tous les graphes auront un nom
différent. Par exemple, si l’on remplit ce cadre avec le nom
“``TestGraph.grf``” et si les sous-graphes sont nommés
“``TestGraph_@%.grf``”, le sous-graphe généré à partir de la 16 ligne
sera nommé “``TestGraph_0016.grf``”.

Les figures [fig-archaiser] et [fig-badauder] montrent deux graphes
générés en appliquant le graphe paramétré de la
figure [fig-reference-graph] à la table 31H.

La figure [fig-main-graph] montre le graphe principal obtenu.

.. figure:: resources/img/fig8-8.png
   :alt: Graphe généré pour le verbe ``archaïser``\ [fig-archaiser]
   :width: 15.00000cm

   Graphe généré pour le verbe ``archaïser``\ [fig-archaiser]

.. figure:: resources/img/fig8-9.png
   :alt: Graphe généré pour le verbe ``badauder``\ [fig-badauder]
   :width: 15.00000cm

   Graphe généré pour le verbe ``badauder``\ [fig-badauder]

.. figure:: resources/img/fig8-10.png
   :alt: Graphe principal appelant tous les graphes
   générés[fig-main-graph]
   :width: 10.00000cm

   Graphe principal appelant tous les graphes générés[fig-main-graph]
