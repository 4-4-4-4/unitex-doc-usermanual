Recherche d’expressions rationnelles
====================================

Nous allons voir dans ce chapitre comment rechercher des motifs simples
dans un texte au moyen des expressions rationnelles.

Définition
----------

Le but de ce chapitre n’est pas de faire une introduction aux langages
formels, mais de montrer comment utiliser les expressions rationnelles
dans Unitex pour rechercher des motifs simples. Le lecteur intéressé par
une présentation plus formelle pourra se reporter aux nombreux ouvrages
qui traitent du sujet.

Une expression rationnelle, ou expression régulière, peut-être:

-  une unité lexicale (``livre``) ou un masque lexical (``<manger.V>``);

-  une position particulière du texte : le début ``{^}``\ ou la fin
   ``{$}``

-  la concaténation de deux expressions rationnelles (``je mange``);

-  l’union de deux expressions rationnelles (``Pierre+Paul``);

-  l’étoile de Kleene d’une expression rationnelle (``très*``).

Unités lexicales
----------------

Dans une expression rationnelle, l’unité lexicale a la même définition
qu’en [tokenization] (page ). Notons que les symboles point, plus,
étoile, inférieur ainsi que les parenthèses ouvrantes et fermantes ont
une signification particulière, il faut donc les déspécialiser avec le
caractère ``\`` si l’on souhaite les rechercher. Voici quelques exemples
d’unités lexicales valides:

::

    chat
    \.
    <N:ms>
    {S}

Par défaut, Unitex tolère que des mots avec des minuscules reconnaissent
des mots écrits avec des majuscules. Il est possible de forcer le
respect de la casse en utilisant les guillemets. Ainsi, ``"pierre"`` ne
reconnaît que la forme ``pierre`` et non pas ``Pierre`` ou ``PIERRE``.

NOTE: si l’on souhaite rendre la présence d’un espace obligatoire, il
faut le mettre entre guillemets.

Masques lexicaux
----------------

Un masque lexical est une requête qui reconnaît une unité lexicale ou
une suite d’unités lexicales.

Symboles spéciaux
~~~~~~~~~~~~~~~~~

Il y a deux sortes de masques lexicaux. La première catégorie regroupe
les symboles spéciaux ou méta-symboles présentés dans la
section [section-sentence-splitting], sauf ``<PNC>`` et ``<^>``. (Le
symbole ``<PNC>``, qui reconnaît des signes de ponctuation, n’est valide
que pendant le prétraitement ; ``<^>`` reconnaît un retour à ligne, mais
tous les retours à la ligne ayant été remplacés par des espaces, ce
symbole n’a plus aucune utilité lors de la recherche de motifs.) Les
méta-symboles utilisables pour rechercher des motifs dans un texte sont
les suivants :

-  ``<E>`` : mot vide, ou epsilon. Reconnaît la séquence vide;

-  ``<TOKEN>`` : reconnaît n’importe quelle unité lexicale sauf l’espace
   utilisé par défaut pour les filtres morphologiques;

-  ``<WORD>`` : reconnaît n’importe quelle unité lexicale formée de
   lettres;

-  ``<LOWER>`` : reconnaît n’importe quelle unité lexicale formée de
   lettres minuscules;

-  ``<UPPER>`` : reconnaît n’importe quelle unité lexicale formée de
   lettres majuscules;

-  ``<FIRST>`` : reconnaît n’importe quelle unité lexicale formée de
   lettres et commençant par une majuscule;

-  ``<DIC>`` : reconnaît n’importe quel mot figurant dans les
   dictionnaires du texte;

-  ``<SDIC>`` : reconnaît n’importe quel mot simple figurant dans les
   dictionnaires du texte;

-  ``<CDIC>`` : reconnaît n’importe quel mot composé figurant dans les
   dictionnaires du texte;

-  ``<TDIC>`` : reconnaît n’importe quelle unité lexicale tagguée comme
   ``{XXX,XXX.XXX}``;

-  ``<NB>`` : reconnaît n’importe quelle suite de chiffres contigus
   (1234 est reconnue mais pas 1 234) ;

-  ``#`` : interdit la présence de l’espace.

Les anciens codes correspondant à ``<WORD>``, ``<LOWER>``, ``<UPPER>``
et ``<FIRST>`` étaient respectivement ``<MOT>``, ``<MIN>``, ``<MAJ>`` et
``<PRE>``. Ils restent opérationnels afin de conserver la compatibilité
descendante du système avec les graphes existants. Même s’il n’est pas
prévu de supprimer ces codes, on recommande de les éviter dans les
graphes conçus pour fonctionner avec les versions plus récentes [1]_,
pour ne pas faire augmenter inutilement le nombre de masques lexicaux en
usage.

NOTE : comme il a été dit en section [tokenization], AUCUN des métas ne
peut être utilisé pour reconnaître le marqueur ``{STOP}``, pas même
``<TOKEN>``.

Référence aux informations fournies par les dictionnaires
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

La seconde sorte de masques lexicaux regroupe ceux qui font appel aux
informations contenues dans les dictionnaires du texte. Les quatre
formes possibles sont :

-  ``<lire>``: reconnaît toutes les entrées qui ont ``lire`` comme forme
   canonique. On remarque que cette forme est ambiguë si ``lire`` est
   aussi un code grammatical ou sémantique;

-  ``<lire.>``: reconnaît toutes les entrées qui ont ``lire`` comme
   forme canonique. Ce masque lexical n’est pas ambigu avec le
   précédent;

-  ``<lire.V>``: reconnaît toutes les entrées qui ont ``lire`` comme
   forme canonique et qui ont le code grammatical ``V``;

-  ``<V>``: reconnaît toutes les entrées qui ont le code grammatical
   ``V``. Ce masque lexical est ambigu comme le premier. Pour lever
   l’ambiguïté, on peut utiliser ``<.V>`` ou ``<+V>``;

-  ``{lirons,lire.V}`` ou ``<lirons,lire.V>``: reconnaît toutes les
   entrées qui ont ``li-``\ ``rons`` comme forme fléchie, ``lire`` comme
   forme canonique et qui ont le code grammatical ``V``. Ce type de
   masque n’a d’intérêt que si l’on travaille sur l’automate du texte où
   sont explicitées les ambiguïtés des mots. Lorsque l’on effectue une
   recherche sur le texte, ce masque reconnaît la même chose que la
   simple unité lexicale ``lirons``.

Contraintes grammaticales et sémantiques
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Les masques lexicaux des exemples précédents sont simples. Il est
possible d’exprimer des motifs plus complexes en indiquant plusieurs
codes grammaticaux ou sémantiques, séparés par le caractère ``+``. Si
plusieurs codes sont présents, le caractère ``+`` est interprété comme
‘’et’’ : une entrée de dictionnaire ne sera alors reconnue que si elle
possède tous les codes présents dans le masque. Le masque ``<N+z1>``
reconnaît ainsi les entrées :

``broderies,broderie.N+z1:fp``

``capitales européennes,capitale européenne.N+NA+Conc+HumColl+z1:fp``

mais pas:

``Descartes,René Descartes.N+Hum+NPropre:ms``

``habitué,.A+z1:ms``

On peut exclure des codes en les faisant précéder du caractère ``~`` au
lieu de ``+``. Pour être reconnue, une entrée doit contenir tous les
codes exigés par le masque, sans aucun des codes qu’il interdit. Par
exemple, ``<A~z3>`` reconnaît toutes les entrées qui ont le code ``A``
sans le code ``z3`` (cf. table [tab-semantic-codes]) [2]_. Si on veut
faire référence à un code contenant le caractère ``~``, on doit le
déspécialiser en le faisant précéder d’un ``\``.

REMARQUE: Avant la version 2.1, l’opérateur de négation était le signe
moins. Si l’on veut utiliser d’anciens graphes sans les modifier, il
faut appeler ``Locate`` en ligne de commande avec l’option ``-g minus``.

La syntaxe des masques lexicaux ne fait aucune différence entre les
codes grammaticaux (table [tab-grammatical-codes]) et sémantiques
(table [tab-semantic-codes]). Dans le format de dictionnaires
électroniques DELAF, les codes grammaticaux sont ceux qui apparaissent
en premier et codent la catégorie grammaticale, mais dans les masques
lexicaux d’Unitex, l’ordre dans lequel apparaissent les codes
grammaticaux et sémantiques n’a pas d’importance. Les trois masques
lexicaux suivants sont équivalents :

::

    <N~Hum+z1>
    <z1+N~Hum>
    <~Hum+z1+N>

Un masque lexical peut contenir un code sémantique sans code de
catégorie grammaticale.

NOTE: il n’est pas possible d’utiliser un masque n’ayant que des codes
d’interdiction. ``<~N>`` et ``<~A~z1>`` sont donc des masques
incorrects. Il est toutefois possible d’exprimer de telles contraintes
en utilisant des contextes (voir section  [section-contexts]).

Contraintes flexionnelles
~~~~~~~~~~~~~~~~~~~~~~~~~

On peut également spécifier des contraintes portant sur les codes
flexionnels. Ces contraintes doivent obligatoirement être précédées par
au moins un code grammatical ou sémantique. Elles suivent les mêmes
conventions de format que les codes flexionnels présents dans les
dictionnaires. Voici quelques exemples de masques lexicaux utilisant des
contraintes flexionnelles :

-  ``<A:m>`` reconnaît un adjectif au masculin ;

-  ``<A:mp>`` reconnaît un adjectif au masculin pluriel.

Un code flexionnel est introduit par le caractère ``:`` et constitué
d’un ou plusieurs caractères, qui représentent une information chacun.
Commençons par le cas simple d’entrées lexicales et de masques qui ont
un seul code flexionnel. Pour qu’une entrée lexicale :math:`E` soit
reconnue par un masque :math:`M`, il faut que le code flexionnel de
:math:`E` contienne tous les caractères du code flexionnel de
:math:`M` :

:math:`E`\ =\ ``sépare,séparer.V:Y2s``

:math:`M`\ =\ ``<V:Y2>``

Le code ``Y2s`` de :math:`E` contient les caractères ``Y`` et ``2``. Le
code ``Y2`` est inclus dans au moins un code de :math:`E`, le masque
lexical :math:`M` reconnaît donc l’entrée :math:`E`.

L’ordre des caractères à l’intérieur d’un code flexionnel est sans
importance. Tous les codes grammaticaux et sémantiques doivent précéder
les codes flexionnels.

Si plusieurs codes flexionnels sont présents dans un masque lexical, le
caractère ``:`` est interprété comme ‘’ou’’ :

-  ``<A:mp:f>`` correspond à la fois à ``<A:mp>``\ et à ``<A:f>`` ; il
   reconnaît un adjectif qui est soit au masculin pluriel, soit au
   féminin ;

-  ``<V:2:3>`` reconnaît un verbe à la 2 ou à la 3 personne ; cela
   exclut tous les temps qui n’ont ni 2 ni 3 personne (infinitif,
   participe passé et participe présent) ainsi que les temps conjugués à
   la première personne.

Pour qu’une entrée de dictionnaire :math:`E` soit reconnue par un masque
:math:`M`, il faut qu’au moins un code flexionnel de :math:`E` contienne
tous les caractères d’au moins un code flexionnel de :math:`M`.
Considérons l’exemple suivant :

:math:`E`\ =\ ``sépare,séparer.V:W:P1s:P3s:S1s:S3s:Y2s``

:math:`M`\ =\ ``<V:P2s:Y2>``

Aucun code flexionnel de :math:`E` ne contient à la fois les caractères
``P``, ``2`` et ``s``. Cependant, le code ``Y2s`` de :math:`E` contient
bien les caractères ``Y`` et ``2``. Le code ``Y2`` est inclus dans au
moins un code de :math:`E`, le masque lexical :math:`M` reconnaît donc
l’entrée :math:`E`.

Négation d’un masque lexical
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Il est possible de faire la négation d’un motif au moyen du
caractère \ ``!`` placé immédiatement après le caractère  ``<``. La
négation est possible sur les métas ``<WORD>``, ``<LOWER>``,
``<UPPER>``, ``<FIRST>``\  [3]_, ``<DIC>`` ainsi que sur les masques
lexicaux ne comportant que des codes grammaticaux, sémantiques ou
flexionnels (*i.e.* ``<!V~z3:P3>``). Les motifs ``#`` et ``" "`` sont la
négation l’un de l’autre. Le méta ``<!WORD>`` peut reconnaître toutes
les unités lexicales qui ne sont pas formées de lettres, sauf le
séparateur de phrases ``{S}`` et, bien sûr, le marqueur ``{STOP}``. La
négation est sans effet sur ``<NB>``, ``<SDIC>``, ``<CDIC>``, ``<TDIC>``
et ``<TOKEN>``.

La négation est interprétée d’une façon particulière dans les métas
``<!DIC>``, ``<!LOWER>``, ``<!UPPER>`` et ``<!FIRST>``\  [4]_. Au lieu
de reconnaître toutes les formes qui ne sont pas reconnues par le méta
sans la négation, ces motifs ne donnent que des formes qui sont des
séquences de lettres. Ainsi, le méta ``<!DIC>`` permet d’obtenir les
mots inconnus du texte (cf. figure [fig-search-<!DIC>]). Ces formes
inconnues sont le plus souvent des noms propres, des néologismes et des
fautes d’orthographe.

.. figure:: resources/img/fig4-1.png
   :alt: Résultat de la recherche du méta
   ``<!DIC>``\ [fig-search-<!DIC>]
   :width: 15.00000cm

   Résultat de la recherche du méta ``<!DIC>``\ [fig-search-<!DIC>]

La négation d’un masque lexical comme ``<V:G>`` reconnaît tous les mots
sauf ceux qui peuvent être reconnus par ce masque. Ainsi, le masque
``<!V:G>`` ne reconnaîtra pas la forme anglaise *being*, même s’il
existe dans les dictionnaires du texte des entrées non verbales pour ce
mot:

::

    being,.A
    being,.N+Abst:s
    being,.N+Hum:s

Voici plusieurs exemples de motifs mélangeant les différentes sortes de
contraintes:

-  ``<A~Hum:fs>`` : adjectif non humain au féminin singulier;

-  ``<lire.V:P:F>`` : le verbe *lire* au présent ou au futur;

-  ``<suis,suivre.V>`` : le mot *suis* en tant que forme conjuguée du
   verbe *suivre* (par opposition à la forme du verbe *être*);

-  ``<facteur.N~Hum>`` : toutes les entrées nominales ayant *facteur*
   comme forme canonique et ne possédant pas le code sémantique ``Hum``;

-  ``<!ADV>`` : tous les mots qui ne sont pas des adverbes;

-  ``<!WORD>`` : tous les caractères qui ne sont pas des lettres, sauf
   le séparateur de phrases (voir figure [fig-search-<!WORD>]). Ce
   masque ne reconnait pas le séparateur de phrase ``{S}`` ni le tag
   ``{STOP}``.

.. figure:: resources/img/fig4-2.png
   :alt: Résultat de la recherche du méta
   ``<!WORD>``\ [fig-search-<!WORD>]
   :width: 15.00000cm

   Résultat de la recherche du méta ``<!WORD>``\ [fig-search-<!WORD>]

Concaténation
-------------

On peut concaténer des expressions rationnelles de trois façons. La
première consiste à utiliser l’opérateur de concaténation représenté par
le point. Ainsi, l’expression:

::

    <DET>.<N>

reconnaît un déterminant suivi par un nom. L’espace peut également
servir à concaténer. L’expression de l’exemple suivant:

::

    le <A> chat
    le<A>chat

reconnaît l’unité lexicale *le*, suivie d’un adjectif et de l’unité
lexicale *chat*. Les parenthèses servent à délimiter une expression
rationnelle. Toutes les expressions suivantes sont équivalentes:

::

    le <A> chat
    (le <A>)chat
    le.<A>chat
    (le).<A> chat
    (le.(<A>)) (chat)

Union
-----

L’union d’expressions rationnelles se fait en les séparant par le
caractère ``+``. L’expression:

::

    (je+tu+il+elle+on+nous+vous+ils+elles) <V>

reconnaît un pronom suivi par un verbe. Si l’on veut rendre un élément
facultatif dans une expression, il suffit de faire l’union de cet
élément avec le mot vide epsilon. Exemples:

``le(petit+<E>)chat`` reconnaît les séquences *le chat* et *le petit
chat*

``(<E>+franco-)(anglais+belge)`` reconnaît *anglais*, *belge*,
*franco-anglais* et *franco-belge*

Étoile de Kleene
----------------

L’étoile de Kleene, représentée par le caractère ``*``,permet de
reconnaître zéro, une ou plusieurs occurrences d’une expression.
L’étoile doit être placée à droite de l’élément concerné. L’expression :

::

    il fait très* froid

reconnaît *il fait froid*, *il fait très froid*, *il fait très très
froid*, etc. L’étoile est prioritaire sur les autres opérateurs. Il faut
utiliser les parenthèses pour appliquer l’étoile à une expression
complexe. L’expression :

::

    0,(0+1+2+3+4+5+6+7+8+9)*

reconnaît un zéro, suivie d’une virgule et d’une suite éventuellement
vide de chiffres.

ATTENTION : il est interdit de rechercher le mot vide avec une
expression rationnelle. Si l’on essaye de chercher
``(0+1+2+3+4+5+6+7+8+9)*``, le programme signalera une erreur comme le
montre la figure [fig-epsilon-error].

.. figure:: resources/img/fig4-3.png
   :alt: Erreur lors de la recherche d’une expression reconnaissant le
   mot vide [fig-epsilon-error]
   :width: 14.00000cm

   Erreur lors de la recherche d’une expression reconnaissant le mot
   vide [fig-epsilon-error]

Filtres morphologiques
----------------------

Il est possible d’appliquer des filtres morphologiques aux unités
lexicales recherchées. Pour cela, il faut faire suivre immédiatement
l’unité lexicale considérée par un filtre entre doubles angles:

| *motif*\ ``<<``\ *motif morphologique*\ ``>>``
| Les filtres morphologiques s’expriment sous la forme d’expressions
  régulières au format POSIX (voir :raw-latex:`\cite{TRE}` pour une
  syntaxe détaillée). Voici quelques exemples de filtres élémentaires:

-  ``<<ss>>``: contient ``ss``

-  ``<<^a>>``: commence par ``a``

-  ``<<ez$>>``: finit par ``ez``

-  ``<<a.s>>``: contient ``a`` suivi par un caractère quelconque, suivi
   par ``s``

-  ``<<a.*s>>``: contient ``a`` suivi par un nombre de caractères
   quelconque, suivi par ``s``

-  ``<<ss|tt>>``: contient ``ss`` ou ``tt``

-  ``<<[aeiouy]>>``: contient une voyelle non accentuée

-  ``<<[aeiouy]{3,5}>>``: contient une séquence de voyelles non
   accentuées, de longueur comprise entre 3 et 5

-  ``<<es?>>``: contient ``e`` fsuivi par un ``s`` facultatif

-  ``<<ss[^e]?>>``: contient ``ss`` suivi par un caractère qui n’est pas
   une voyelle ``e``

Il est possible de combiner ces filtres élémentaires pour former des
filtres plus complexes:

-  ``<<[ai]ble$>>``: finit par ``able`` ou ``ible``

-  ``<<^(anti|pro)-?>>``: commence par ``anti`` ou ``pro``, suivi par un
   tiret facultatif

-  ``<<^([rst][aeiouy]){2,}$>>``: mot formé de 2 ou plus séquences
   commençant par un ``r``, ``s`` ou ``t`` suivi d’une voyelle non
   accentuée

-  ``<<^([^l]|l[^e])>>``: ne commence pas par ``l`` ou alors la deuxième
   lettre n’est pas un ``e``, c’est-à-dire n’importe quel mot sauf ceux
   qui commencent par ``le``. De telles contraintes peuvent être
   exprimées plus simplement en utilisant des contextes
   (voir [section-contexts]).

Par défaut, un filtre morphologique tout seul est considéré comme
s’appliquant au méta ``<TOKEN>``, c’est-à-dire à n’importe quelle unité
lexicale sauf l’espace et le marqueur ``{STOP}``. En revanche, lorsqu’un
filtre suit immédiatement un motif, il s’applique à ce qui est reconnu
par le motif. Voici quelques exemples de telles combinaisons:

-  ``<V:K><<i$>>``: participe passé finissant par ``i``

-  ``<CDIC><<->>``: mot composé contenant un tiret

-  ``<CDIC><< .* >>``: mot composé contenant deux espaces

-  ``<A:fs><<^pro>>``: adjectif féminin singulier commençant par ``pro``

-  ``<DET><<^([^u]|(u[^n])|(un.+))>>``: déterminant différent de ``un``

-  ``<!DIC><<es$>>``: mot qui n’est pas dans le dictionnaire et qui se
   termine par ``es``

-  ``<V:S:T><<uiss>>``: verbe au subjonctif passé ou présent, contenant
   ``uiss``

NOTE : par défaut, les filtres morphologiques sont soumis aux même
variations de casse que les masques lexicaux. Ainsi, le filtre
``<<^é>>`` va reconnaître tous les mots commençant par ``é,``, mais
également ceux qui commencent par ``E`` ou ``É``. Pour forcer le respect
exact de la casse du filtre, il faut ajouter ``_f_`` immédiatement après
celui-ci. Exemple : ``<A><<^é>>_f_``.

Recherche
---------

Configuration de la recherche
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Pour pouvoir rechercher une expression, il faut tout d’abord ouvrir un
texte (voir chapitre  [chap-text]). Cliquez ensuite sur “Locate
Pattern...” dans le menu “Text”. La fenêtre de la
figure [fig-regexp-search-configuration] apparaît alors.

.. figure:: resources/img/fig4-4.png
   :alt: Fenêtre de recherche
   d’expressions[fig-regexp-search-configuration]
   :width: 8.80000cm

   Fenêtre de recherche d’expressions[fig-regexp-search-configuration]

Le cadre “Locate Pattern” permet de choisir entre une expression
rationnelle et une grammaire. Cliquez sur “Regular expression”.

Le cadre “Index” permet de sélectionner le mode de reconnaissance:

-  “Shortest matches” : donne la priorité aux séquences les plus courtes
   For instance, if your grammar can recognize the sequences *very hot
   chili* and *very hot*, the first one will be discarded;

-  “Longest matches” : donne la priorité aux séquences les plus longues.
   C’est le mode utilisé par défaut;

-  “All matches” : donne toutes les séquences reconnues.

Le cadre “Search limitation” permet de limiter ou non la recherche à un
certain nombre d’occurrences. Par défaut, la recherche est limitée aux
200 premières occurrences.

Les options du cadre “Grammar outputs” ne concernent pas les expressions
rationnelles. Elles sont décrites à la section
 [section-applying-graphs-to-text]. De même pour les options de l’onglet
“Advanced options” (voir section [section-advanced-search-options]).

Dans le cadre “Search algorithm”, on définit si l’on veut effectuer la
recherche dans le texte avec le programme ``Locate`` ou dans l’automate
du texte avec le programme ``LocateTfst``. Par défaut la recherche est
effectuée avec le programme ``Locate``. Pour utiliser ``LocateTfst``, il
est utile de se référer à la section [section-locate-tfst].

Entrez une expression et cliquez sur “Search” pour lancer la recherche.
Unitex va transformer l’expression en une grammaire au format ``.grf``.
Cette grammaire va ensuite être compilée en une grammaire au format
``.fst2`` qui sera utilisée par le programme de recherche.

Affichage des résultats
~~~~~~~~~~~~~~~~~~~~~~~

Une fois la recherche terminée, la fenêtre de la
figure [fig-search-results] apparaît, indiquant le nombre d’occurrences
trouvées, le nombre d’unités lexicales reconnues, ainsi que le rapport
entre ce nombre et le nombre total d’unités lexicales du texte.

.. figure:: resources/img/fig4-5.png
   :alt: Résultats de la recherche [fig-search-results]
   :width: 6.50000cm

   Résultats de la recherche [fig-search-results]

Après avoir cliqué sur “OK”, vous verrez apparaître la fenêtre de la
figure [fig-configuration-concordance] permettant de configurer
l’affichage de la liste des occurrences trouvées. Vous pouvez également
faire apparaître cette fenêtre en cliquant sur “Display Located
Sequences...” dans le menu “Text”. On appelle *concordance* la liste
d’occurrences.

.. figure:: resources/img/fig4-6.png
   :alt: Configuration de l’affichage des occurrences
   trouvées[fig-configuration-concordance]
   :width: 11.00000cm

   Configuration de l’affichage des occurrences
   trouvées[fig-configuration-concordance]

Le cadre “Modify text” offre la possibilité de remplacer les occurrences
trouvées par les sorties produites. Cette possibilité sera examinée au
chapitre  [chap-advanced-grammars].

Le cadre “Extract units” vous permet de construire un fichier texte avec
toutes les phrases contenant ou non des occurrences. Le bouton “Set
File” vous permet de sélectionner le fichier de sortie. Cliquez ensuite
sur “Extract matching units” ou “Extract unmatching units” selon que
vous voulez extraire les phrases contenant les occurrences ou non.

Dans le cadre “Show Matching Sequences in Context”, vous pouvez
sélectionner la longueur en caractères des contextes gauche et droit des
occurrences qui seront affichées dans la concordance. Si une occurrence
a une longueur inférieure à la taille du contexte droit, la ligne de
concordance sera complétée avec le nombre de caractères nécessaire. Si
une occurrence a une longueur supérieure à la taille du contexte droit,
elle est affichée en entier.

NOTE: en thaï, la taille des contextes est mesurée en caractères
affichables et non en caractères réels. Cela permet de conserver
l’alignement des lignes de concordance malgré la présence de caractères
diacritiques qui se combinent à d’autres lettres au lieu de s’afficher
comme des caractères normaux.

Vous pouvez sélectionner le mode de tri à appliquer dans la liste “Sort
According to”. Le mode “Text Order” affiche les occurrences dans l’ordre
où elles apparaissent dans le texte. Les six autres modes permettent de
trier en colonnes. Les trois zones d’une ligne sont le contexte gauche,
l’occurrence et le contexte droit. Les occurrences et les contextes
droits sont triés de gauche à droite. Les contextes gauches sont triés
de droite à gauche. Le mode utilisé par défaut est “Center, Left Col.”.
La concordance est produite sous la forme d’un fichier HTML.

Lorsque les concordances atteignent plusieurs milliers d’occurrences, il
est préférable de les afficher avec un navigateur web (Firefox
:raw-latex:`\cite{Firefox}`, Netscape :raw-latex:`\cite{Netscape}`,
Internet Explorer, etc.). Pour cela, cochez la case “Use a web browser
to view the concordance” (voir figure  [fig-configuration-concordance]).
Cette option est activée par défaut lorsque le nombre d’occurrences est
supérieur à 3000. Pour définir le navigateur qui sera utilisé, cliquez
sur “Preferences...” dans le menu “Info”. Cliquez sur l’onglet “Text
Presentation” et sélectionnez le programme à utiliser dans le cadre
“Html Viewer” (voir figure [fig-browser-selection]).

Si vous choisissez d’ouvrir la concordance à l’intérieur d’Unitex, vous
verrez une fenêtre comme celle de la figure [fig-example-concordance].
L’option “Enable links” activée par défaut permet de considérer les
occurrences comme des liens hypertextes. Ainsi, quand on clique sur une
occurrence, cela ouvre la fenêtre du texte et y sélectionne la séquence
reconnue. De plus, si l’automate du texte est construit et que cette
fenêtre n’est pas réduite sous forme d’icône, l’automate de la phrase
contenant l’occurrence cliquée est chargé. Si l’on sélectionne l’option
“Allow concordance edition”, on ne peut pas cliquer ainsi sur les
occurrences, mais on peut éditer la concordance comme du texte. Cela
permet entre autres de s’y déplacer avec un curseur, ce qui peut être
pratique si l’on travaille sur une concordance avec de grands contextes.

.. figure:: resources/img/fig4-7.png
   :alt: Sélection d’un navigateur pour l’affichage des
   concordances[fig-browser-selection]
   :width: 8.00000cm

   Sélection d’un navigateur pour l’affichage des
   concordances[fig-browser-selection]

.. figure:: resources/img/fig4-8.png
   :alt: Exemple de concordance[fig-example-concordance]
   :height: 18.00000cm

   Exemple de concordance[fig-example-concordance]

Statistiques
~~~~~~~~~~~~

Si l’on sélectionne l’onglet “Statistics” dans le cadre “Located
sequences..”, le panneau de la figure [fig-statistics] apparaît. Ce
panneau permet d’effectuer des calculs statistiques sur les séquences
préalablement indexées.

.. figure:: resources/img/fig4-9.png
   :alt: Panneau statistiques [fig-statistics]
   :width: 11.00000cm

   Panneau statistiques [fig-statistics]

Dans le panneau “Mode” il est possible de choisir le type de
statistiques désiré:

-  collocates by frequency: montre les unités lexicales présentes dans
   le contexte de la séquence reconnu.

-  collocates by z-score: le me mêmes informations avec, en plus (number
   of occurrences of the collocate in the match context and in the whole
   corpus, z-score of the collocate)

-  contexts by frequency: montre les unités lexicales avec les contextes
   gauche et droit (voir au dessous). “count” est le nombre
   d’occurrences d’une séquence reconnue donnée (munie de contexte)

Dans le second panneau, on choisit la longueur des contextes gauche et
droit à utiliser en tokens sans espace. NOTE: Cette notion de contexte
n’a rien à voir avec celle utilisée dans les grammaires.

Dans le dernier panneau, on peut permettre ou non la variation de casse.
Si cette variation est permise, ``the`` et ``THE`` sont considérées
comme la même unité lexicale, et le résultat est la somme de ceux
obtenus pour ``the`` et ``THE``.

Les figures suivantes montrent les statistiques calculées pour chaque
mode pour la requête ``<have>`` sur ``ivanhoe.snt``.

.. figure:: resources/img/fig4-10.png
   :alt: contexte gauche+match+contexte droit+nombre
   d’occurrence[fig-statistics-mode0]
   :width: 11.00000cm

   contexte gauche+match+contexte droit+nombre
   d’occurrence[fig-statistics-mode0]

.. figure:: resources/img/fig4-11.png
   :alt: collocate count[fig-statistics-mode1]
   :width: 11.00000cm

   collocate count[fig-statistics-mode1]

.. figure:: resources/img/fig4-12.png
   :alt: collocate, count et d’autres informations[fig-statistics-mode2]
   :width: 12.00000cm

   collocate, count et d’autres informations[fig-statistics-mode2]

.. [1]
   À partir de la version 3.1bêta, révision 4072 du 2 octobre 2015.

.. [2]
   Si les dictionnaires décrivent un mot par deux entrées dont une avec
   ``A+z3`` et l’autre avec seulement ``A``, ce mot est reconnu par
   ``<A+z3>`` à cause de la première entrée et par ``<A~z3>`` à cause de
   l’autre.

.. [3]
   Et sur leurs équivalents anciens <MOT>,<MIN>, <MAJ>, <PRE>. Voir
   section [section-special-symbols].

.. [4]
   Et dans leurs équivalents anciens <MIN>, <MAJ> et <PRE>. Voir
   section [section-special-symbols].
