Utilisation des programmes externes
===================================

Ce chapitre présente l’utilisation des différents programmes qui
composent Unitex. Ces programmes, qui se trouvent dans le répertoire
``Unitex/App``, sont appelés automatiquement par l’interface (en fait,
``UnitexToolLogger`` est appelé, afin de réduire de manière importante
la taille du fichier zip). Il est possible de voir les commandes qui ont
été exécutées en cliquant sur “Info>Console”. Il est aussi possible de
voir les options des differents programmes dans “Info>Help on commands”
(voir Figure [fig-help]). Remarquons que tous les programmes Unitex
possèdent l’option ``-h``/``--help``.

.. figure:: resources/img/fig11-1.png
   :alt: Help on commands[fig-help]
   :width: 14.00000cm

   Help on commands[fig-help]

IMPORTANT: plusieurs programmes utilisent le répertoire du texte
(``mon_texte_snt``). Ce répertoire est créé par l’interface graphique
après la normalisation du texte. Si vous travaillez en ligne de
commande, vous devrez créer ce répertoire vous-même après l’exécution du
programme ``Normalize``.

IMPORTANT (2): lorsqu’un paramètre contient des espaces, vous devez
l’entourer de guillemets pour qu’il ne soit pas considéré comme
plusieurs paramètres.

ATTENTION (3): beaucoup de programmes utilisent un fichier
``Alphabet.txt``. Cette information peut être omise pour l’ensemble de
ces programmes. Dans ce cas, une définition (par défaut) de lettres est
utilisée (voir ``u_is_letter`` dans le fichier source\ ``Unicode.cpp``).

Création de fichiers log
------------------------

[section-creating-log-files]

.. figure:: resources/img/fig11-1a.png
   :alt: Configuration de fichiers log[fig-logging-config]
   :width: 10.00000cm

   Configuration de fichiers log[fig-logging-config]

Vous pouvez créer des fichiers ``log`` des programmes externes exécutés.
Ces fichiers log peuvent être utiles pour le débogage ou des tests de
régression. Vous avez juste besoin d’activer cette fonctionnalité dans
le cadre Préférences. Vous devez simplement choisir un répertoire de
fichiers log dans lequel tous les fichiers sont stockés, et cocher la
case “Produce log” En cliquant sur le bouton “Clear all logs” vous
supprimez tous les fichiers log éventuellement contenus dans ce
répertoire. Désormais, toute nouvelle exécution du promme produit un
fichier ``unitex_log_XXX.ulp`` dans le répertoire de fichiers log.
``XXX`` représente le numéro de log qui se trouve dans la console (voir
section suivante).

La console
----------

[section-console] Lorsque Unitex lance un programme externe, la ligne de
commande appelée est mémorisée dans la console. Pour la voir, cliquez
sur Info “> Console”. Quand une commande n’émet aucun message d’erreur,
elle est affichée avec une icône verte. Sinon, l’icône est un triangle
rouge sur lequel vous pouvez cliquer pour voir les messages d’erreur,
comme indiqué sur la figure [fig-console] . Ceci est utile lorsque un
message d’erreur se produit si vite que vous ne pouvez pas le lire. Si
une commande a été enregistrée, son numéro de log apparaît dans la
deuxième colonne. Notez que vous pouvez exporter toutes les commandes
affichées dans la console vers le presse-papiers avec Ctrl + C.

.. figure:: resources/img/fig11-2.png
   :alt: Console[fig-console]
   :width: 15.00000cm

   Console[fig-console]

Unitex JNI
----------

[section-unitex-JNI]

Vous pouvez utilisez Unitex avec JNI by en incluant les imports suivants
:

::

    import fr.umlv.unitex.jni.UnitexJni;
    import java.io.*;
    import fr.umlv.unitex.*;

Ceci vous permet de charger en mémoire les dictionnaires (.bin), les
grammaires ou graphes dictionnaires (.fst2) et les fichiers alphabet et
de les garder en mémoire de manière persistante. Vous utilisez alors le
nom de fichier renvoyé par la foncton loadPersistent\*.

::

    String persistentAlphabet = UnitexJni.loadPersistentAlphabet("/.../unitex/French/Alphabet.txt");
    String persistentFst2 = UnitexJni.loadPersistentFst2("/.../unitex/French/Dela/fogg-r.fst2");
    String persistentDictionary = UnitexJni.loadPersistentDictionary(
            "/.../unitex/French/Dela/communesFR+.bin");

Paramètres de codage des fichiers textes
----------------------------------------

[section-text-file-encoding-parameters] Unitex utilise Unicode pour les
fichiers textes [unicode-encoding]. Tous les programmes qui lisent ou
écrivent des fichiers textes partagent les mêmes paramètres d’encodage.
Les formats possibles sont utf16le-bom, utf16le-no-bom, utf16be-bom,
utf16be-no-bom, utf8-bom, utf8-no-bom, qui correspondent à Unicode
Big-Endian, Little-Endian et UTF-8, avec ou sans “Unicode byte order
mark” (bom) au début du fichier. Pour le format d’entrée, vous pouvez
spécifier plusieurs encodages \*-bom (avec bom) codage séparées par des
virgules, mais seulement un encodage \*-no-bom (sans bom).

**OPTIONS:**

-  ``-k=ENCODING``/``--input_encoding=ENCODING``: format du texte
   source. Peut contenir plusieurs valeurs séparées par des virgules;

-  ``-q=ENCODING``/``--output_encoding=ENCODING``: format du texte de
   sortie.

Par défaut, les valeurs sont:
``--input_encoding=utf16le-bom,utf16be-bom,utf8-bom``
``--output_encoding=utf16le-bom``.

BuildKrMwuDic
-------------

``BuildKrMwuDic [OPTIONS] dic``

Ce programme génère des graphes de flexion pour les mots composés à
partir d’un tableau ``dic`` qui décrit chaque constituant de chaque mot
composé **OPTIONS:**

-  ``-o GRF``/``--output=GRF``: fichier ``.grf`` à produire;

-  ``-d DIR``/``--directory=DIR``: répertoire de flexion qui contient
   les graphes de flexion nécéssaires pour produire les variantes
   morphologiques des racines;

-  ``-a ALPH``/``--alphabet=ALPH``: fichier alphabet à utiliser;

-  ``-b BIN``/``--binary=BIN``: dictionnaire des mots simples de type
   ``.bin`` à utiliser;

CasSys
------

``Cassys [OPTIONS] <snt>``

Ce programme applique une liste ordonnée de grammaires à un texte et
construit un index des occurrences trouvées. **OPTIONS:**

-  ``-a ALPH``/``--alphabet=ALPH``: fichier alphabet de la langue;

-  ``-r X``/``--transducer_dir=X``: prend un transducteur dans le
   répertoire ``X`` (ainsi ne donnez pas le chemin complet pour chaque
   transducteur; remarquons que ``X`` doit se terminer par un antislash;

-  ``-w DIC/--morpho=DIC``: indique que ``DIC`` est un ``.bin``
   dictionnaire à utiliser en mode morphologique. Utiliser autant de
   ``-m XXX`` qu’il y a de ``.bin``. Vou pouvez égalemnt séparer
   plusieurs ``.bin`` par des deux-points.

-  ``-l TRANSDUCERS_LIST``/``--transducers_list=TRANSDUCERS_LIST``:
   fichier contenant la liste des transducteurs avec leur mode
   d’application;

-  ``-s transducer.fst2``/``--transducer_file=transducer.fst2``: un
   transducteur à appliquer;

-  ``-m output_policy``/``--transducer_policy=output_policy``: le mode
   d’application du transducteur spécifié;

-  ``-t TXT``/``--text=TXT``: le fichier texte avec l’extension ``.snt``
   à modifier;

-  ``-i``/``--in_place``: sigifie qu’il faut utiliser les mêmes
   répertoires ``csc/snt`` pour chaque transducteur;

-  ``-d``/``--no_create_directory``: signifie que tous les répertoires
   ``snt/csc`` existent déjà et n’ont pas besoin d’être crées;

-  ``-g minus``/``--negation_operator=minus``: utilise ``moins`` comme
   opérateur de négation pour les graphes version Unitex 2.0;

-  ``-g tilde``/``--negation_operator=tilde``: utilise ``tilde`` comme
   opérateur de négation (par défaut);

-  ``-h``/``--help``: affiche cette aide

CasSys applique une liste de grammaires à un texte et sauve les
séquences reconnues dans un fichier index nommé ``concord.ind`` stocké
dans le répertoire texte. Le fichier cible doit être un fichier snt avec
son répertoire ``\_snt/``. Le fichier contenant la liste des
transducteurs est un fichier dans lequel chaque ligne contient le nom
complet du transducteur suivi de son mode d’application.

A la place d’une liste, vous pouvez spécifier chaque fichier et mode
d’application par un ensemble de couple d’arguments pour représenter la
liste ``-s/--transducer\_file`` et ``-m/--transducer\_policy``

Le mode d’application peut être MERGE ou REPLACE.

L’option de fichier, l’option alphabet et l’option fichier liste de
transducteurs sont obligatoires

Comme le programme Locate, ce programme enregistre les références des
occurrences dans un fichier ``concord.ind`` stocké dans le répertoire
``\_snt\verb`` du texte. Le fichier ``concord.ind`` produit est dans le
même format que celui décrit chapitre [chap-file-formats] , mais la
cascade peut être formée de graphes appliqués en mode merge ou replace,
de ce fait #M ou #R à la première ligne du fichier ``concord.ind`` n’a
pas de sens dans ce contexte.

CheckDic
--------

``CheckDic [OPTIONS] dic``

Ce programme effectue la vérification du format d’un dictionnaire de
type DELAS ou DELAF.\ ``dic`` qui correspond au nom du dictionnaire à
vérifier

**OPTIONS:**

-  ``-f``/``--delaf``: vérifie un dictionnaire de formes fléchies;

-  ``-s``/``--delas``: vérifie un dictionnaire de formes canoniques;

-  ``-r``/``--strict``: vérification stricte de la syntaxe, la
   déspécialisation des points et virgules;

-  ``-t``/``--tolerate``: tolère des points et des virgules non
   déspécialisés (par défaut);

-  ``-n``/``--no_space_warning``: tolère des espaces dans les codes
   grammaticaux/sémantiques/flexionnels;

-  ``-p``/``--skip_path``: n’affiche pas le chemin complet du
   dictionnaire (utiles pour la compatibilité de fichiers de log sur
   plusieurs systèmes);

-  ``-a ALPH``/``--alphabet=ALPH``: indique le fichier alphabet à
   utiliser.

Le programme teste la syntaxe des lignes du dictionnaire. Il dresse
également la liste des caractères présents dans les formes fléchies et
canoniques, la liste des codes grammaticaux et syntaxiques ainsi que la
liste des codes flexionnels utilisés. Les résultats de la vérification
sont stockés dans un fichier nommé ``CHECK_DIC.TXT``.

Le choix de ``--strict`` permet de détecter l’utilisation de points non
déspécialisés dans la forme fléchie ou de virgules non déspécialisées
dans la forme canonique. L’option ``--tolerate`` se comporte comme dans
les versions Unitex 2.0 et antérieures et ne les détecte pas.

Compress
--------

[section-compress] ``Compress [OPTIONS] dictionary``

**OPTIONS:**

-  ``-o BIN``/``--output=BIN``: définit le fichier de sortie. Par
   défaut, un fichier ``xxx.dic`` produit un fichier ``xxx.bin``;

-  ``-f``/``--flip``: indique que les formes fléchies et canoniques
   doivent être inversées dans le dictionnaire comprimé. Cette option
   est utilisée pour construire un dictionnaire inversé nécessaire au
   programme ``Reconstrucao``;

-  ``-s``/``--semitic``: indique que l’algorithme de compression pour
   langue sémitique doit être utilisé. Cette option utilisée avec des
   langues sémitiques comme l’arabe réduit sensiblement la taille du
   dictionnaire produit;

-  ``--v1``: produit un fichier ``.bin`` ancienne manière;

-  ``--v2``: produit un fichier ``.bin`` nouvelle manière, mieux
   comprimé et sans limitation de taille de fichier à 16 Mb (par défaut)

Ce programme prend en paramètre un dictionnaire DELAF et le compresse.

La compression d’un dictionnaire ``dico.dic`` produit deux fichiers:

-  ``dico.bin``: fichier binaire contenant l’automate minimal des formes
   fléchies du dictionnaire ;

-  ``dico.inf``: fichier texte contenant des formes comprimées
   permettant de reconstruire les lignes du dictionnaire à partir des
   formes fléchies contenues dans l’automate.

Pour plus de détails sur les formats de ces fichiers, voir chapitre
[chap-file-formats].

Concord
-------

[section-Concord] ``Concord [OPTIONS] <index>``

Ce programme prend en paramètre un fichier d’index de concordance
produit par le programme ``Locate`` et produit une concordance. Il peut
également produire une version du texte modifiée prenant en compte les
transductions associées aux occurrences. Voici la description des
paramètres:

**OPTIONS:**

-  ``-f FONT``/``--font=FONT``: nom de la police de caractères à
   utiliser si la sortie est fichier HTML;

-  ``-s N``/``--fontsize=N``: taille de la police si la sortie est
   fichier HTML. Les paramètres concernant la police sont ignorés si la
   sortie n’est pas au format HTML;

-  ``--only_ambiguous``: Affiche seulement les occurrences identiques
   avec une sortie ambiguë, dans l’odre du texte.

-  ``--only_matches``: cette option définit un mode sans contexte. En
   outre si elle est utilisée avec ``-t/--text``, Concord n’entoure pas
   les séquences reconnues de tabulations

-  ``-l X``/``--left=X``: nombre de caractères à gauche des occurrences
   (par défaut=0). Dans le mode Thai, ceci correspond au nombre de
   caractères non diacritiques.

-  ``-r X``/``--right=X``: nombre de caractères (non diacritiques dans
   le mode Thai) à droite des occurrences (par défaut=0). Si
   l’occurrence est plus petite que cette valeur, la ligne de
   concordance est complétée jusqu’à ``right``. Si l’occurrence est plus
   longue que la valeur définie par ``right``, elle est néanmoins
   entièrement conservée.

   NOTE: Pour ``--left`` et ``--right``, vous pouvez ajouter le
   caractère ``s`` pour arrêter au premier symbole de fin de phrase
   ``{S}``. Par exemple, si vous mettez ``40s`` comme valeur de gauche,
   le contexte gauche sera au plus à 40 caractères, moins si le ``{S}``
   est trouvé avant.

**Options de tri:**

-  ``--TO``: ordre dans lequel les occurrences apparaissent dans le
   texte (par défaut);

-  ``--LC``: contexte gauche comme premier tri, occurrence comme second
   tri;

-  ``--LR``: contexte gauche, contexte droit;

-  ``--CL``: occurrence, contexte gauche;

-  ``--CR``: occurrence, contexte droit;

-  ``--RL``: contexte droit, contexte gauche;

-  ``--RC``: contexte droit, occurrence.

Pour plus de détails sur ces modes de tri, voir la section
[section-display-occurrences].

**Options de sortie:**

-  ``-H``/``--html``: produit une concordance au format HTML codée en
   UTF-8; (par défaut);

-  ``-t``/``--text``: produit une concordance au format texte Unicode;

-  ``-g SCRIPT``/``--glossanet=SCRIPT``: produit une concordance pour
   GlossaNet au format HTML. Le fichier HTML produit est codé en UTF-8;

-  ``-p SCRIPT``/``--script=SCRIPT``: produit une concordance au format
   HTML où les occurrences sont liens décrits par ``SCRIPT``. Par
   exemple, si vous utilisez

   ``-phttp://www.google.com/search?q=``, vous obtiendrez une
   concordance au format HTML où les occurrences sont des liens vers des
   requêtes Google;

-  ``-i``/``--index``: produit un index de la concordance, qui comporte
   les occurrences (avec les sorties des grammaires, s’il y en a),
   précédées par les positions des occurrences, dans le fichier texte,
   exprimées en caractères;

-  ``-u`` ``offsets``/``--uima=offsets``: produit un index de la
   concordance relatif fichier texte original, avant toute opération
   effectuée par Unitex. Offsets est le fichier produit par Tokenize
   avec l’option ``--output_offsets``

-  ``-e``/``--xml``: produit un index xml de la concordance;

-  ``-w``/``--xml-with-header``: produit un index xml de la concordance
   avec une en-tête xml complète;

-  ``--lemmatize``: produit un fichier de concordance HTML spécial
   utilisé par l’interface de lemmatisation de l’interface graphique
   d’Unitex.

   REMARQUE: les options -e et -w acceptent toutes deux un fichier
   d’offset, comme l’accepte -u

-  ``--PRLG=X,Y``: produit une concordance pour des corpus PRLG où
   chaque ligne est préfixée par l’information extraite avec l’option
   ``--PRLG`` de Unxmlize. X est le fichier produit par l’option
   ``--PRLG`` de Unxmlize et Y est le fichier produit par l’option
   ``--output_offsets`` de Tokenize. Remarquons que si cette option est
   utilisée en plus avec ``-u``, l’argument Y remplace l’argument de
   ``-u``;

-  ``-A``/``--axis``: presque pareil que ``--index``, mais les nombres
   représentent le caractère médian de chaque occurrence. Pour plus
   d’information, consultez :raw-latex:`\cite{axis}`;

-  ``-x``/``--xalign``: un autre fichier index, utilisé par le module
   d’alignement de texte. Chaque ligne est formée de 3 entiers :math:`X`
   :math:`Y` :math:`Z` suivi du contenu de l’occurrence. :math:`X` est
   numéro de la phrase, partant de 1. :math:`Y` et :math:`Z` sont les
   positions de début et de fin de l’occurrence dans la phrase exprimée
   en caractères;

-  ``-m TXT``/``--merge=TXT``: indique au programme qu’il doit produire
   une version modifiée du texte et l’enregistrer dans le fichier
   dénommé ``TXT`` (voir section [section-modifying-text]).

-  | ``T--export_csv``: produit un fichier avec le séparateur tabulation
     export.csv dans l’ordre du texte avec le format suivant: A B C D E
     F, où: A=nombre de lignes dans le fichier .csv B=nombre de phrases
     C= référence PRLG, si elle existe D=la forme fléchie présente dans
     le texte E=le lemme, s’il existe F=les codes, s’il y en a
   | Pour fonctionner, cette option doit re appelée pour des fichier
     concord.ind, qui ne contiennent pas de token S ni espace

**Autres options:**

-  ``-d DIR``/``--directory=DIR``: indique au programme qu’il ne doit
   pas travailler avec le même répertoire que ``<index>`` mais avec
   ``DIR``;

-  ``-a ALPH``/``--alphabet=ALPH``: fichier alphabet utilisé pour le
   tri;

-  ``-T``/``--thai``: option à utiliser pour les concordances en Thai.

Le résultat de l’application de ce programme est un fichier
``concord.txt`` si la concordance a été construite en mode texte, un
fichier ``concord.html`` pour les modes ``--html``, ``--glossanet`` ou
``--script``, et un fichier texte dont le nom a été défini par
l’utilisateur si le programme a construit une version modifiée du texte.

En mode ``--html``, l’occurrence est codée comme un lien. La référence
associée à ce lien est de la forme ``<a href="X Y Z">``. ``X`` et ``Y``
représentent les positions de début et de fin de l’occurrence en
caractères dans le fichier ``text_name.snt``. ``Z`` représente le numéro
de la phrase dans laquelle apparaît l’occurrence.

ConcorDiff
----------

``ConcorDiff [OPTIONS] <concor1> <concor2>``

Ce programme prend deux fichiers de concordance et produit une page HTML
montrant les différences entre ces deux concordances (voir section
[section-comparing-concordances], page ). ``<concor1>`` et ``<concor2>``
fichiers de concordances (.ind) doivent avoir des noms absolus, car
Unitex en déduit le texte sur lequel elles ont été calculées;

**OPTIONS:**

-  ``-o X``/``--out=X``: page HTML de sortie;

-  ``-f FONT``/``--font=FONT``: police à utiliser dans le page HTML de
   sortie;

-  ``-s N``/``--size=N``: taille de police à utiliser dans le page HTML
   de sortie;

-  ``-d/--diff_only``: ne pas afficher les séquences identiques;

Convert
-------

``Convert [OPTIONS] <text_1> [<text_2> <text_3> ...]``

Ce programme permet de transcoder des fichiers textes.

**OPTIONS:**

-  ``-s X``/``--src=X``: encodage d’entrée;

-  ``-d X``/``--dest=X``: encodage de sortie (par
   défaut=\ ``LITTLE-ENDIAN``);

**Options de translitération (seulement pour l’arabe):**

-  ``-F``/``--delaf``: l’entrée est un DELAF et l’on veut seulement
   translitérer les formes fléchies et canoniques;

-  ``-S``/``--delas``: l’entrée est un DELAS et l’on veut seulement
   translitérer les formes canoniques.

**Options de sortie:**

-  ``-r``/``--replace``: la conversion écrase les fichiers source (par
   défaut);

-  ``-o file``/``--output=file``: nom du fichier de destination
   (seulement un fichier à convertir);

-  ``--ps=PFX``: les fichiers sources sont renommés avec le préfixe
   ``PFX``; (``toto.txt`` :math:`\Rightarrow` ``PFXtoto.txt``);

-  ``--pd=PFX``: les fichiers destinations sont renommés avec le préfixe
   ``PFX``;

-  ``--ss=SFX``: les fichiers sources sont renommés avec le suffixe
   ``SFX``; (``toto.txt`` :math:`\Rightarrow` ``totoSFX.txt``);

-  ``--sd=SFX``: les fichiers destinations sont renommés avec le suffixe
   ``SFX``.

**Options HTML:**

``Convert`` offre des options spéciales pour les fichiers HTML. Vous
pouvez utiliser une combinaison des options suivantes:

-  ``--dnc`` (Decode Normal Chars): des séquences comme ``&eacute;``
   ``&#120;`` et ``&#xF8;`` sont décodées comme un unique caractère
   unicode, sauf si elles representent un caractère de contrôle HTML;

-  ``--dcc`` (Decode Control Chars): ``&lt;`` ``&gt;`` ``&amp;`` et
   ``&quot;`` sont décodés comme ``<`` ``>`` ``&`` et les quote (de même
   pour leur représentation décimales et hexadécimales);

-  ``--eac`` (Encode All Chars): chaque caractère non supporté par
   l’encodage de sortie est représenté par une chaîne comme ``&#457;``

-  ``--ecc`` (Encode Control Chars): ``<`` ``>`` ``&`` et les quote sont
   encodés par ``&lt;`` ``&gt;`` ``&amp;`` et ``&quot;``

Par défaut, toutes les options HTML sont désactivées.

**Autres options:**

-  ``-m``/``--main-names``: imprime la liste des noms principaux des
   encodage;

-  ``-a``/``--aliases``: imprime la liste des alias d’encodage;

-  ``-A``/``--all-infos``: imprime toutes les information concernant
   tous les encodages;

-  ``-i X``/``--info=X``: imprime toutes les information concernant
   l’encodage X.

Les encodages prennent leurs valeurs dans la liste suivante (liste non
exhaustive, voir ci-dessous):

``FRENCH``

``ENGLISH``

``GREEK``

``THAI``

``CZECH``

``GERMAN``

``SPANISH``

``PORTUGUESE``

``ITALIAN``

``NORWEGIAN``

``LATIN`` (default latin code page)

``windows-1252``: Microsoft Windows 1252 - Latin I (Western Europe &
USA)

``windows-1250``: Microsoft Windows 1250 - Central Europe

``windows-1257``: Microsoft Windows 1257 - Baltic

``windows-1251``: Microsoft Windows 1251 - Cyrillic

``windows-1254``: Microsoft Windows 1254 - Turkish

``windows-1258``: Microsoft Windows 1258 - Viet Nam

``iso-8859-1  ``: ISO 8859-1 - Latin 1 (Europe de l’ouest & USA)

``iso-8859-15 ``: ISO 8859-15 - Latin 9 (Western Europe & USA)

``iso-8859-2  ``: ISO 8859-2 - Latin 2 (Eastern and Central Europe)

``iso-8859-3  ``: ISO 8859-3 - Latin 3 (Southern Europe)

``iso-8859-4  ``: ISO 8859-4 - Latin 4 (Northern Europe)

``iso-8859-5  ``: ISO 8859-5 - Cyrillic

``iso-8859-7  ``: ISO 8859-7 - Greek

``iso-8859-9  ``: ISO 8859-9 - Latin 5 (Turkish)

``iso-8859-10 ``: ISO 8859-10 - Latin 6 (Nordic)

``next-step   ``: NextStep code page

``LITTLE-ENDIAN``

``BIG-ENDIAN``

``UTF8``

Dico
----

``Dico [OPTIONS] <dic_1> [<dic_2> <dic_3>...]``

Ce programme applique des dictionnaires à un texte. Le texte doit avoir
été découpé en unités lexicales par le programme ``Tokenize``.

**OPTIONS:**

-  ``-t TXT``/``--text=TXT``: nom complet du fichier texte ``.snt``;

-  ``-a ALPH``/``--alphabet=ALPH``: le fichier alphabet à utiliser;

-  ``-m DICS``/``--morpho=DICS``: ce paramètre optionnel liste les
   dictionnaires du mode morphologique, si la présence de dictionnaires
   ``.fst2`` rend cette information nécessaire. ``DICS`` représente une
   liste de fichiers ``.bin`` (avec leur nom complet) séparés par des
   points-virgules;

-  ``-K``/``--korean``: indique à ``Dico`` qu’il travaille sur du
   coréen;

-  ``-s``/``--semitic``: indique à ``Dico`` qu’il travaille sur une
   langue sémitique (nécessaire si ``Dico`` doit compresser un
   dictionnaire);

-  ``-u X``/``--arabic_rules=X``: désigne le fichier de configuration
   des règles typographiques de l’arabe;.

-  ``r X``/``--raw=X``: indique que ``Dico`` devrait simplement produire
   un fichier de sortie X contenant les mots simples et composés, sans
   exiger un répertoire texte. Si X est omis, les résultats sont
   affichés sur la sortie standard.

``<dic_i>`` représente le chemin d’accès complet à un dictionnaire. Le
dictionnaire doit être soit un dictionnaire compressé au format ``.bin``
(obtenu avec le programme ``Compress``) soit un graphe dictionnaire au
format\ ``.fst2`` (voir section [section-applying-dictionaries], page ).
Il est possible de donner des priorités aux dictionnaires. Pour les
détails voir section [section-dictionary-priorities].

Le programme ``Dico`` produit les fichiers suivants et les sauve dans le
répertoire du texte

-  ``dlf``: dictionnaire des mots simples du texte;

-  ``dlc``: dictionnaire des mots composés du texte;

-  ``err``: liste des mots inconnus du texte;

-  ``tags_err``: mots simples inconnus qui ne sont pas reconnus par le
   fichier ``tags.ind``;

-  ``tags.ind`` : séquences à insérer dans l’automate du texte (see
   section [section-dictionary-graphs], page );

-  ``stat_dic.n``: fichier contenant les nombres de mots simples,
   composés et inconnus du texte.

NOTE: Les fichiers\ ``dlf``, ``dlc``, ``err`` and ``tags_err`` ne sont
pas triés. Utilisez le programme ``SortTxt`` pour le faire.

DumpOffsets
-----------

[section-DumpOffsets] **Utilisation:** ``DumpOffsets [OPTIONS] <txt>``

``<txt>: fichier d'offsets d'origine``

Ce programme permet d’étudier et d’utiliser les fichiers de
correspondance d’Offsets, manipulé par certains outils Unitex comme
Unxmlize, Normalize, Fst2Txt, Tokenize, Concord et GrfTest.

**OPTIONS:**

-  ``-o X``/``--old=X``: nom du fichier d’origine

-  ``-n X``/``--new=X``: nom du fichier d’arrivée

-  ``-p X``/``--output=X``: nom du fichier de sortie

-  ``-f``/``--full``: ajouter le texte courant

-  ``-q``/``--quiet``: ne pas afficher de message

-  ``-c``/``--no_escape_sequence``: don’t escape text sequence

-  ``-h``/``--help``: cet aide

Exemple:

::

         UnitexToolLogger Normalize -r .\resource\Norm.txt .\work\text_file.txt      
                 --output_offsets .\work\text_file_offset.txt    
         UnitexToolLogger DumpOffsets -o .\work\text_file_offset.txt -n .\work\text_file_offset.snt      
                -p .\work\dump\dump_offsets.txt .\work\text_file_offset.txt      

**Autre Utilisation:** ``DumpOffsets [-m/--merge] [OPTIONS] <txt>``

``<txt>: fichier d'offsets d'origine``

Fusionner deux fichiers d’offsets produits par deux modifications
successives du texte.

**OPTIONS:**

-  ``-o X``/``--old=X``: nom du fichier d’origine

-  ``-n X``/``--output=X``: nom du fichier d’offset issu de la fusion

**Autre Utilisation:**
``DumpOffsets [-v/--convert_modified_to_common] [OPTIONS] <txt>``

``<txt>: fichier d'offsets d'origine``

Crée un fichier d’offset des chaines identiques dans le fichier original
et le fichier modifié. Au moins une taille doit être fournie.

**OPTIONS:**

-  ``-s N``/``--old_size=N``: taille en caractère de la version
   d’origine du fichier texte

-  ``-S N``/``--new_size=N``: taille en caractère de la version
   d’arrivée du fichier texte

-  ``-p X``/``--output=X``: nom du fichier d’offsets courant

-  ``-h``/``--help``: cet aide

**Autre Utilisation:**
``DumpOffsets [-M/--convert_modified_to_common] [OPTIONS] <txt>``

``<txt>: fichier d'offsets d'origine``

Crée un fichier d’offsets à partir des offsets des chaines identiques
dans le fichier original et le fichier modifié. Il faut obligatoirement
spécifier les deux tailles.

**OPTIONS:**

-  ``-s N``/``--old_size=N``: taille en caractère de la version
   d’origine du fichier texte

-  ``-S N``/``--new_size=N``: taille en caractère de la version
   d’arrivée du fichier texte

-  ``-p X``/``--output=X``: nom du fichier d’offsets courant

-  ``-h``/``--help``: cet aide

**Autre Utilisation:**
``DumpOffsets -o <list_of_position_file_to_read.txt>``

``<list_of_position_file_to_read.txt>`` est un fichier avec seulement un
nombre par ligne (une position).

Ceci convertit une liste de positions en utilisant le fichier d’offsets.
Le fichier créé contient à chaque ligne la nouvelle position suivi d’un
+ si le caractère à cette position est dans le fichier d’arrivée, suivi
d’un - si le caractère a été supprimé.

-  ``-p <list_to_create> -T <offset_file_to_read>``

Utiliser ``-t`` à la place de ``-T`` produit la traduction inverse.

DumpOffsets
-----------

[section-DumpOffsets]

Ce programme permet d’étudier et d’utiliser les fichiers de
correspondance d’Offsets, manipulé par certains outils Unitex comme
Unxmlize, Normalize, Fst2Txt, Tokenize, Concord et GrfTest.

::

    DumpOffsets --merge -o <fichier_offsets1> <fichier_offsets2>
      -p <fichier_offset12>

En entrée, le fichier offsets1 ([subsection-offsets-diff], page ))
contient la correspondant des offsets entre un fichier en version A et
un fichier en version B, et offset2 contient la correspondant des
offsets entre ce fichier en version B et en version C, le fichier
fichier\_offset12 résultant aura la correspondance entre les versions A
et B.

::

    DumpOffsets [OPTIONS] -o <fichier_version1> -n <fichier_Version2>
      <fichier_offset> -p <fichier_dump>

**OPTIONS:**

-  ``-f/--full``: Inclus des informations plus complètes

En entrée, le fichier fichier\_offset contient la correspondant des
offsets entre le fichier\_version1 et le fichier\_version2. En sortie,
le fichier texte <fichier\_dump> contiendra la comparaison des séquences
entre les 2 fichiers et vérifiera leur cohérence. Ce fichier est
destinée à une lecture manuelle, afin d’étudier le contenu du fichier
d’offset

::

    DumpOffsets [OPTIONS] --convert_modified_to_common 
      <fichier_offset_différence> -p <fichier_offset_zone_commune>

**OPTIONS:**

-  ``-s N/--old_size=N``: Contient la taille en caractère de la version
   d’origine du fichiet texte

-  ``-S N/--new_size=N``: Contient la taille en caractère de la version
   d’arrivée du fichiet texte

Il faut obligatoirement spécifier une des deux tailles. Pour un fichier
encodé en UTF16BE\_BOM, c’est la taille en octets, auquel on retranche 2
pour les 2 octets de signature BOM et que l’on divise ensuite par 2 car
chaque caractère unicode prend 2 octets. En UTF8, la correspondance
n’est pas immédiate.

Converti un fichier d’offset indiquant les caractères supprimés (tel que
fournis par les autres outils Unitex) en fichier indiquant les plages de
caractères identiques ([subsection-offsets-common]).

::

    DumpOffsets [OPTIONS] --convert_common_to_modified
      <fichier_offset_zone_commune> -p <fichier_offset_différence>

**OPTIONS:**

-  ``-s N/--old\_size=N``: Contient la taille en caractère de la version
   d’origine du fichier texte

-  ``-S N/--new\_size=N``: Contient la taille en caractère de la version
   d’arrivée du fichier texte

Il faut obligatoirement spécifier les deux tailles.

| Converti un fichier d’offset indiquant les plages de caractères
  identiques en fichier indiquant les caractères supprimés.
| **OPTIONS:**

-  ``-d/--denormalize``: Denormalize l’output

Typiquement ce program permet de rétablir les espaces, les espaces
insecables, les sauts de ligne, les tabulations, etc. effacés par
Normalize. Il rétablit aussi le texte qui a été supprimé par le
Preprocessing ou par un graphe. Il conserve les ajouts à condition que
ceux-ci soient placés entre chevrons.

Le fichier\_dump contient les textes du fichier version 1 et les textes
entre chevron (<, >) qui étaient ajoutés en fichier version 2.

::

    DumpOffsets [OPTIONS] -d -o <fichier_version1>
    -n <fichier_version2> <fichier_offset> -p <fichier_dump>

Elag
----

``Elag [OPTIONS] <tfst>``

Ce programme prend un fichier ``.tfst`` automate de texte ``<tfst>`` et
lui applique des règles de levée d’ambiguïtés.

**OPTIONS:**

-  ``-l LANG/--language=LANG``: Le fichier de configuration ELAG pour la
   langue considérée

-  ``-r RULES/--rules=RULES``: le fichier de règles compilées au format
   ``.rul``;

-  ``-o OUT/--output=OUT``: l’automate du texte de sortie.

ElagComp
--------

``ElagComp [OPTIONS]``

Ce programme compile une grammaire ELAG dont le nom est ``GRAMMAR``, ou
toutes les grammaires sont spécifiées dans le fichier ``RULES``. Le
résultat est stocké dans un fichier ``OUT`` qui pourra être utilisé par
le programme ``Elag``.

**OPTIONS:**

-  ``-r RULES``/``--rules=RULES``: fichier listant des grammaires ELAG;

-  ``-g GRAMMAR``/``--grammar=GRAMMAR``: une grammaire ELAG donnée;

-  ``-l LANG``/``--language=LANG``: le fichier de configuration ELAG
   pour la langue considérée;

-  ``-o OUT``/``--output=OUT``: nom du fichier de sortie. Par défaut, le
   fichier de sortie est identique à ``RULES``, sauf pour l’extension
   qui est ``.rul``.

Evamb
-----

``Evamb [OPTIONS] <tfst>``

Ce programme calcule un taux d’ambiguïté moyen sur tout l’automate du
texte ``<tfst>``, ou juste sur la phrase spécifiée par\ ``N``. Les
résultats du calcul sont affichés sur la sortie standard. L’automate du
texte n’est pas modifié par ce programme.

**OPTIONS:**

-  ``-o OUT``/``--output=OUT``: nom de fichier optionnel;

-  ``-s N``/``--sentence=N``: numéro de phrase.

Extract
-------

``Extract [OPTIONS] <text>``

Ce programme extrait de ce texte toutes les phrases qui contiennent au
moins une des occurrences de la concordance. Le paramètre ``<text>``
représente le nom complet du fichier texte, sans omettre l’extension
``.snt``.

**OPTIONS:**

-  ``-y``/``--yes``: extrait toutes les phrases qui contiennent des
   séquences reconnues (par défaut);

-  ``-n``/``--no``: extrait toutes les phrases qui ne contiennent pas de
   séquence reconnue

-  ``-o OUT``/``--output=OUT``: nom du fichier de sortie;

-  ``-i X``/``--index=X``: le fichier ``.ind`` qui décrit la
   concordance. Par défaut, ``X`` est le fichier ``concord.ind`` situé
   dans le répertoire du texte

Le résultat est un fichier texte contenant toutes les phrases extraites,
à raison d’une phrase par ligne.

Flatten
-------

``Flatten [OPTIONS] <fst2>``

Ce programme prend une grammaire ``.fst2`` en paramètre, et essaye de la
transformer en un transducteur à états finis.

**OPTIONS:**

-  ``-f``/``--fst``: la grammaire est “dépliée” à la profondeur maximum
   et tronquée si des appels à des sous-graphes existent. Les appels
   tronqués sont remplacés par des transitions vides. Le résultat est
   une grammaire ``.fst2`` qui contient un unique transducteur à états
   finis;

-  ``-r``/``--rtn``: les appels aux sous-graphes qui subsistent après
   transformation sont laissés tels quels. Le résultat est un
   transducteur à états finis dans le cas favorable, et une grammaire
   optimisée strictement équivalente à l’originale dans le cas contraire
   (par défaut);

-  ``-d N``/``--depth=N``: profondeur maximum à laquelle les appels aux
   graphes devraient être dépliés. La valeur par défaut est 10.

Fst2Check
---------

``Fst2Check [OPTIONS] <fst2>``

Ce programme vérifie si un fichier .fst2 n’a pas d’erreurs Locate.

**OPTIONS:**

-  ``-y``/``--loop_check``: active la vérification d’erreurs ( détection
   de boucles);

-  ``-n``/``--no_loop_check``: désactive la vérification d’erreurs (par
   défaut);

-  ``-t``/``--tfst_check``: vérifie si le graphe donné peut être
   considéré comme un automate de phrases ou non;

-  ``-e``/``--no_empty_graph_warning``: pas d’émission de warning quand
   les graphes reconnaissent le mot vide. Cette option est utilisée par
   ``MultiFlex`` pour ne pas effrayer les utilisateurs par des messages
   d’erreurs inadéquats lorsqu’ils construisent une grammaire de flexion
   qui reconnaît le mot vide

**Options de sortie:**

-  ``-o file``/``--output=file``: fichier de sorties pour les messages
   d’erreurs;

-  ``-a``/``--append``: ouvre un fichier de message d’erreurs en mode
   append;

-  ``-s``/``--statistics``: affiche les statistique du fichier
   ``.fst2``.

Fst2List
--------

``Fst2List [-o out][-p s/f/d][-[a/t] s/m][-m][-f s/a][-s[0s] "Str"]``

``         [-r[s/l] "Str"] [-l line#] [-i subname]*``

``         [-c SS=0xxxx]* fname``

Ce programme prend un fichier ``.fst2`` et produit la liste des
séquences reconnues par cette grammaire. Les paramètres sont les
suivants :

-  ``fname`` : nom de la grammaire, avec l’extension ``.fst2``;

-  ``-o out`` : précise le nom du fichier de sortie. Par défaut, ce
   fichier se nomme ``lst.txt``;

-  ``-S`` : Affiche le résultat sur la sortie standard. Exclusif avec
   ``-o``;

-  ``-[a/t] s/m`` : précise si l’on tient compte (``t``) ou non (``a``)
   des éventuelles sorties de la grammaire. ``s`` indique qu’il n’y a
   qu’un seul état initial, tandis que ``m`` indique qu’il y en a
   plusieurs (ce mode est utile en coréen). Par défaut, ce paramètre
   vaut ``-a s``;

-  ``-l line#`` : nombre maximum de lignes à écrire dans le fichier de
   sortie;

-  ``-i subname`` : indique que l’on doit arrêter l’exploration
   récursive lorsque l’on rencontre le graphe ``subname``. Ce paramètre
   peut être utilisé plusieurs fois, afin de spécifier plusieurs graphes
   d’arrêts

-  ``-p s/f/d`` : ``s`` produit l’affichage des chemins de chaque
   sous-graphe de la grammaire ; ``f`` (par défaut) affiche les chemins
   globaux de la grammaire; ``d`` affiche les chemins en ajoutant des
   indications sur les imbrications d’appels de sous-graphes;

-  ``-c SS=0xXXXX``: remplace le symbole ``SS`` quand il apparaît entre
   angles par le caractère unicode de code hexadécimal ``0xXXXX``;

-  ``-s "L[,R]"`` : spécifie les délimiteurs gauche (``L``) et droit
   (``R``) qui entoureront les items. Par défaut, ces délimiteurs sont
   nuls;

-  ``-s0 "Str"`` :si l’on tient compte des sorties de la grammaire, ce
   paramètre spécifie la séquence ``Str`` qui séparera une entrée de sa
   sortie. Par défaut, il n’y a pas de séparateur;

-  ``-f a/s`` : si l’on tient compte des sorties de la grammaire, ce
   paramètre spécifie le format des lignes générées :
   ``in0 in1 out0 out1`` (``s``) ou ``in0 out0 in1 out1`` (``a``). La
   valeur par défaut est ``s``;

-  ``-ss "stop"``: définit “str” comme la marque d’arrêt à
   l’exploitation à ``"<stop>"``. La valeur par défaut est ``null``;

-  ``-v`` : ce paramètre produit l’affichage de messages d’informations;
   (mode verbose);

-  ``-m`` : mode spécial pour description avec alphabet;

-  ``-rx "L,[R]"``: ce paramètre spécifie comment les cycles doivent
   être présentés ``L`` et ``R`` désignent des délimiteurs. Si l’on
   considère le graphe de la figure [cycle], voici les résultats que
   l’on obtient si l’on pose ``L``\ =“``[``” et ``R``\ =“``]*``”:

   ``il fait [très très]*``

   ``il fait très beau``

   .. figure:: resources/img/fig10-1.png
      :alt: Graphe avec un cycle[cycle]
      :width: 7.00000cm

      Graphe avec un cycle[cycle]

Fst2Txt
-------

[section-Fst2Txt] ``Fst2Txt [OPTIONS] <fst2>``

Ce programme applique un transducteur à un texte en phase de
prétraitement, quand le texte n’est pas encore découpé en unités
lexicales

**OPTIONS:**

-  ``-t TXT``/``--text=TXT``: le fichier texte à modifier, avec
   l’extension ``.snt``;

-  ``-a ALPH``/``--alphabet=ALPH``: le fichier alphabet de la langue du
   texte;

-  ``-s``/``--start_on_space``: ce paramètre indique que la recherche va
   commencer à n’importe quelle position dans le texte, même avant un
   espace. Ce paramètre ne devrait être utilisé que pour effectuer des
   recherches morphologiques;

-  ``-x``/``--dont_start_on_space``: interdit au programme de
   reconnaître des séquences commençant par un espace (par défaut);

-  ``-c``/``--char_by_char``: ce paramètre facultatif permet d’appliquer
   le transducteur en mode caractère par caractère. Cette option doit
   être utilisée pour les textes en langues asiatiques comme le Thaï;

-  ``-w``/``--word_by_word``: fonctionne en mode mot par mot (par
   défaut);

-  ``--input_offsets=XXX``: fichier offset à utiliser.

**Options de sorties:**

-  ``-M``/``--merge``: ajoute les sorties du transducteur aux séquences
   reconnues texte d’entrée (par défaut);

-  ``-R``/``--replace``: remplace les séquences reconnues avec les
   sorties correspondantes du transducteur.

-  ``--output_offsets=XXX``: fichier offset à produire

Ce programme a pour effet de modifier le fichier texte passé en
paramètre.

Grf2Fst2
--------

``Grf2Fst2 [OPTIONS] <grf>``

Ce programme compile une grammaire en un fichier ``.fst2`` (pour plus de
détails, voir section [section-graph-compilation]). Le paramètre
``<grf>`` désigne le chemin d’accès complet au graphe principal de la
grammaire, sans omettre l’extension ``.grf``.

**OPTIONS:**

-  ``-y``/``--loop_check``: active la vérification d’erreurs ( détection
   de boucles);

-  ``-n``/``--no_loop_check``: désactive la vérification d’erreurs (par
   défaut);

-  ``-a ALPH``/``--alphabet=ALPH``: spécifie le fichier d’alphabet à
   utiliser pour faire le découpage en unités lexicales du contenu des
   boîtes de la grammaire.

-  ``-c``/``--char_by_char``: le découpage se fait caractère par
   caractère. Si ni ``-c`` ni ``-a`` ne sont utilisés, le découpage
   s’effectue en prenant des suites de lettres Unicode.

-  ``-d DIR``/``--pkgdir=DIR``: définit le répertoire de dépôt à
   utiliser pour compiler la grammaire (voir section
   [section-repository], page ).

-  ``-e``/``--no_empty_graph_warning``: pas d’émission de warning quand
   les graphes reconnaissent le mot vide. Cette option est utilisée par
   ``MultiFlex`` pour ne pas effrayer les utilisateurs par des messages
   d’erreurs inadéquats lorsqu’ils construisent une grammaire de flexion
   qui reconnaît le mot vide.

-  ``-t``/``--tfst_check``: vérifie si le graphe donné peut être
   considéré comme un automate de phrases ou non;

-  ``-s``/``--silent_grf_name``: n’affiche pas le nom des graphes
   (nécessaire pour l’utilisation de fichiers log sur plusieurs
   systèmes);

-  ``-r XXX``/``--named_repositories=XXX``: déclaration de noms de
   répertoires de dépôt. XXX est formé d’une séquence d’un ou plusieurs
   X=Y, séparés par ‘;’, où X est le nom du répertoire de dépôt désigné
   par le chemin Y. Vous pouvez utiliser cette option à plusieurs
   reprises ;

-  ``--debug``: compile les graphes en mode debug;

-  ``-v``/``check_variables``: vérifier la validité de sortie afin
   d’éviter des expressions avec variables malformées.

Le résultat est un fichier portant le même nom que le graphe passé en
paramètre, mais avec l’extension ``.fst2``. Ce fichier est sauvegardé
dans le même répertoire que ``<grf>``.

GrfDiff
-------

``GrfDiff <grf1> <grf2>: fichier fichiers .grf`` à comparer

**OPTIONS:**

-  ``--output X``: sauve le résultat éventuel dans X au lieu de
   l’afficher

Compare les fichier .grf et affiche leurs différence sur la sortie
standard. Renvoie 0 s’il sont identiques modulo le réordonnancement des
boîtes et des transitions, 1 si ils sont différents, 2 en cas d’erreur.

Voici les indications que GrfDiff peut émettre :

-  ``P name``: présentation d’une propriété a changé. name= nom
   propriété name (SIZE, FONT, ...)

-  ``M a b``: une boîte est déplacée. a=numéro de boîte dans <grf1>,
   b=numéro de boîte dans <grf2>

-  ``C a b``: le contenu d’une boîte a changé. a=numéro de boîte dans
   <grf1>, b=numéro de boîte dans <grf2>

-  ``A x``: une boîte a été ajoutée. x=numéro de boîte dans <grf2>

-  ``R x``: une boîte a été supprimée. x=numéro de boîte dans <grf1>

-  ``T a b x y``: une transition a été ajoutée. a,b=src et dst numéros
   de boîtes dans <grf1>. x,y=src et dst numéros de boîtes dans <grf2>

-  ``X a b x y``: transition a été supprimée. a,b=src et dst numéros de
   boîtes dans <grf1>. x,y=src et dst numéros de boîtes dans <grf2>

Remarquons que les modifications concernant les transitions liées aux
boîtes ajoutées ou supprimées sont rapportées.

GrfDiff3
--------

GrfDiff3 <mine> <base> <other>

<mine>: mon fichier .grf <other>: l’autre fichier .grf qui produit un
conflit <base>: fichier .grf ancêtre commun

**OPTIONS:**

-  ``--output`` ``X``: enregistre le résultat, le cas échéant, dans X et
   pas sur la sortie

-  ``--conflicts`` ``X``: enregistre la description des conflits, le cas
   échéant, dans X

-  ``--only-cosmetic``: signale un conflit de tout changement qui n’est
   pas purement cosmétique

Essaye de regrouper les <mine> et <other>. En cas de succès, le résultat
est imprimé sur la sortie standard et 0 est renvoyé. En cas de conflits
non résolus, 1 est renvoyé et rien n’est imprimé. 2 est renvoyé en cas
d’erreur.

ImplodeTfst
-----------

``ImplodeTfst [OPTIONS] <tfst>``

Ce programme implose l’automate du texte spécifié en fusionnant ensemble
les entrées lexicales qui ne diffèrent que par leurs catactéristiques
flexionnelles.

**OPTIONS:**

-  ``-o OUT``/``--output=OUT``: fichier de sortie. Par défaut,
   l’automate du texte est modifiée.

Locate
------

[section-Locate] ``Locate [OPTIONS] <fst2>``

Ce programme applique une grammaire à un texte et construit un fichier
d’index des occurrences trouvées.

**OPTIONS:**

-  ``-t TXT``/``--text=TXT``: chemin complet du fichier texte, sans
   omettre l’extension ``.snt``;

-  ``-a ALPH``/``--alphabet=ALPH``: chemin d’accès complet au fichier
   alphabet;

-  ``-m DICS``/``--morpho=DICS``: ce paramètre optionnel indique quels
   dictionnaires morphologiques sont utilisés, s’ils sont exigés par des
   dictionnaires ``.fst2`` ``DICS`` représente une liste de fichiers
   ``.bin`` (avec leurs chemins complets) séparés par des
   points-virgules;

-  ``-s``/``--start_on_space``: ce paramètre indique que la recherche va
   commencer à n’importe quelle position dans le texte, même avant un
   espace. Ce paramètre ne devrait être utilisé que pour effectuer des
   recherches morphologiques;

-  ``-x``/``--dont_start_on_space``: interdit au programme de
   reconnaitre des séquences commençant par un espace (par défaut);

-  ``-c``/``--char_by_char``: ce paramètre facultatif permet d’appliquer
   le transducteur en mode caractère par caractère. Cette option doit
   être utilisée pour les textes en langues asiatiques comme le Thaï;

-  ``-w``/``--word_by_word``: fonctionne en mode mot par mot (par
   défaut);

-  ``-d DIR``/``--sntdir=DIR``: met les fichiers produits dans le
   répertoire au lieu ``DIR`` au lieu du répertoire texte. Notez que
   ``DIR`` doit se terminer par un séparateur de fichier (``\`` or
   ``/``);

-  ``-K``/``--korean``: indique ``Locate`` qu’il travaille sur du
   coréen;

-  ``-u X``/``--arabic_rules=X``: désigne le fichier de configuration
   des règles typographiques de l’arabe;

-  ``-g X``/``--negation_operator=X``: spécifie l’opérateur de négation
   à utiliser dans les masques lexicaux. Les deux valeurs possibles de
   ``X`` sont ``moins`` et ``tilde`` (par défaut). Utiliser ``moins``
   offre une compatibilité descendante avec les versions précédentes de
   Unitex.

**Options de limite de recherche:**

-  ``-l``/``--all``: recherche toutes les séquences reconnues (par
   défaut);

-  ``-n N``/``--number_of_matches=N``: stoppe après les premiers ``N``
   matches.

**Options du nombre d’itérations maximum par token:**

-  ``-o N``/``--stop_token_count=N``: stoppe après N itérations sur un
   token;

-  ``-o N,M``/``--stop_token_count=N,M``: émet un warning après N
   itérations sur un token et s’arrête après itérations M.

**Options du mode de reconnaissance:**

-  ``-S``/``--shortest_matches``;

-  ``-L``/``--longest_matches`` (par défaut);

-  ``-A``/``--all_matches``.

**Options de sortie:**

-  ``-I``/``--ignore``: ignore les sorties du transducteur (par défaut);

-  ``-M``/``--merge``: ajoute les sorties du transducteur avec les
   séquences reconnues;

-  ``-R``/``--replace``: remplace les séquences reconnues par les
   sorties correspondantes du transducteur;

-  ``-p``/``--protect_dic_chars``: quand le mode ``-M`` ou ``-R`` est
   utilisé, ``-p`` protège certains caractères de l’entrée avec un
   antislash. Ceci est utile quand ``Locate`` est appelée par ``Dico``
   afin d’éviter la production de mauvaises lignes comme:

   ``3,14,.PI.NUM``

-  ``-v X=Y``/``--variable=X=Y``: définit une variable de sortie nommé
   ``X`` avec un contenu ``Y``. Remarquons que Y doit être ASCII.

**Options de sortie ambiguës:**

-  ``-b``/``--ambiguous_outputs``: permet la production de plusieurs
   matchs avec la même entrée, mais différentes sorties (par défaut);

-  ``-z``/``--no_ambiguous_outputs``: interdit les sorties ambiguës.
   Dans le cas de sorties ambiguës, l’une sera arbitrairement choisie,
   en fonction de l’état interne du programme.

**Options d’erreur sur les variables**

Ces options n’ont aucun effet si le mode de sortie est réglé avec
``--ignore``; sinon, elles définissent le comportement du programme
``Locate`` quand une sortie contient une référence à une variable qui
n’est pas correctement définie.

-  ``-X``/``--exit_on_variable_error``: arrête le programme;

-  ``-Y``/``--ignore_variable_errors``: agit comme si la variable avait
   un contenu vide (par défaut);

-  ``-Z``/``--backtrack_on_variable_errors``: arrêter d’explorer le
   chemin courant de la grammaire.

**Injection de variables:**

-  ``-v X=Y``/``--variable=X=Y``: définit une variable de sortie nommée
   X avec un contenu Y. Notez que Y doit être ASCII.

Ce programme enregistre les références des occurrences trouvées dans un
fichier appelé ``concord.ind``. Le nombre d’occurrences, le nombre
d’unités appartenant à ces occurrences, ainsi que le pourcentage
d’unités reconnues dans le texte sont enregistrées dans un fichier
appelé ``concord.n``. Ces deux fichiers sont stockés dans le répertoire
du texte.

LocateTfst
----------

[section-LocateTfst] ``LocateTfst [OPTIONS] <fst2>``

Ce programme applique une grammaire à l’automate du texte, et sauve
l’indes des séquences reconnues dans un fichier ``concord.ind``, comme
le fait ``Locate``.

**OPTIONS:**

-  ``-t TFST``/``--text=TFST``: chemin complet du fichier texte, sans
   omettre l’extension;

-  ``-a ALPH``/``--alphabet=ALPH``: chemin d’accès complet au fichier
   alphabet;

-  ``-K``/``--korean``: indique à ``LocateTfst`` qu’il travaille sur du
   coréen;

-  ``-g X``/``--negation_operator=X``: spécifie l’opérateur de négation
   à utiliser dans les masques lexicaux. Les deux valeurs possibles de
   ``X`` sont ``moins`` et ``tilde`` (par défaut). Utiliser ``moins``
   offre une compatibilité descendante avec les versions précédentes de
   Unitex.

**Options de limite de recherche:**

-  ``-l``/``--all``: recherche toutes les séquences reconnues (par
   défaut);

-  ``-n N``/``--number_of_matches=N``: stoppe après les premiers ``N``
   matches.

**Options du mode de reconnaissance:**

-  ``-S``/``--shortest_matches``;

-  ``-L``/``--longest_matches`` (par défaut);

-  ``-A``/``--all_matches``.

**Options de sortie:**

-  ``-I``/``--ignore``: ignore les sorties du transducteur (par défaut);

-  ``-M``/``--merge``: ajoute les sorties du transducteur avec les
   séquences reconnues;

-  ``-R``/``--replace``: remplace les séquences reconnues par les
   sorties correspondantes du transducteur;

**Options de sortie ambiguës:**

-  ``-b``/``--ambiguous_outputs``: permet la production de plusieurs
   matchs avec la même entrée, mais différentes sorties (par défaut);

-  ``-z``/``--no_ambiguous_outputs``: interdit les sorties ambiguës.
   Dans le cas de sorties ambiguës, l’une sera arbitrairement choisie,
   en fonction de l’état interne du programme.

**Options d’erreur sur les variables**

Ces options n’ont aucun effet si le mode de sortie est réglé avec
``--ignore``; sinon, elles définissent le comportement du programme
``Locate`` quand une sortie une référence à une variable qui n’est pas
correctement définie.

-  ``-X``/``--exit_on_variable_error``: arrête le programme;

-  ``-Y``/``--ignore_variable_errors``: agit comme si la variable avait
   un contenu vide (par défaut);

-  ``-Z``/``--backtrack_on_variable_errors``:arrêter d’explorer le
   chemin courant de la grammaire.

**Injection de variables**

-  ``-v X=Y``/``--variable=X=Y``: définit une variable de sortie nommée
   ``X`` avec un contenu ``Y``. Notez que Y doit être ASCII.

**Option d’étiquetage**

-  ``--tagging``: indique que la concordance doit être tagguée, et
   contenir les informations supplémentaires sur les états de début et
   de fin de chaque match.

Ce programme enregistre les références des occurrences trouvées dans un
fichier appelé ``concord.ind``. Le nombre d’occurrences, et le nombre de
sorties produites sont enregistrées dans un fichier appelé
``concord_tfst.n``. Ces deux fichiers sont stockés dans le répertoire du
texte.

MultiFlex
---------

``MultiFlex [OPTIONS] <dela>``

Ce programme effectue la flexion automatique d’un dictionnaire DELA
contenant des formes canoniques [section-DELAS-format]) de mots simples
ou composés (see chapter [chap-multiflex]).

**OPTIONS:**

-  ``-o DELAF``/``--output=DELAF``: fichier DELAF de sortie;

-  ``-a ALPH``/``--alphabet=ALPH``: fichier alphabet;

-  ``-d DIR``/``--directory=DIR``: le répertoire contenant les fichiers
   ``Morphology`` et ``Equivalences`` et des graphes de flexion pour
   mots simples ou composés;

-  ``-K``/``--korean``: indique à ``MultiFlex`` qu’il travaille sur du
   coréen;

-  ``-s``/``--only-simple-words``: le programme tiendra compte des mots
   composés comme des erreurs;

-  ``-c``/``--only-compound-words``: le programme tiendra compte des
   mots simples comme des erreurs;

-  ``-p DIR``/``--pkgdir=DIR``: indique le répertoire des graphes.

-  ``-rXXX``/``--named_repositories=XXX``: déclaration des dépôts
   nommés. XXX est formée d’une séquence ou plus X=Y , séparés par ; où
   X est le nom de dépôt désigné par le chemin Y. Vous pouvez utiliser
   cette option à plusieurs reprises;

Remarquons que les transducteurs de flexion ``.fst2`` sont
automatiquement construits à partir des fichiers ``.grf`` correspondants
en cas d’absence ou de fichiers ``.grf`` plus anciens.

Normalize
---------

[section-Normalize] ``Normalize [OPTIONS] <text>``

Ce programme effectue une normalisation des séparateurs de texte. Les
séparateurs sont l’espace, la tabulation, et le saut de ligne. Chaque
séquence de séparateurs qui contient au moins un saut de ligne est
remplacé par un saut de ligne unique. Toutes les autres séquences de
séparateurs sont remplacées par un seul espace.

Ce programme vérifie également la syntaxe des étiquettes lexicales
présentes dans le texte. Toute séquence entre accolades doit être soit
le délimiteur de phrase ``{S}``, le marqueur ``{STOP}``, soit une ligne
de DELAF valide (``{aujourd'hui,.ADV}``).

Le paramètre ``<text>`` doit représenter le chemin d’accès complet au
fichier du texte. Le programme produit une version modifiée du texte qui
est sauvé dans un fichier portant l’extension ``.snt``.

**OPTIONS:**

-  ``-n``/``--no_carriage_return``: chaque séquence de séparateurs sera
   transformée en un espace unique;

-  ``--input_offsets=XXX``: fichier offset à utiliser.

-  ``--output_offsets=XXX``: fichier offset à produire

-  ``-r XXX``/``--replacement_rules=XXX``: indique la règle de
   normalisation à utiliser. Voir section [section-normalization-file]
   Pour plus de détails sur le format de ce fichier. Par défaut, le
   programme ne remplace que ``{`` and ``}`` par ``[`` et ``]``.

-  ``--no_separator_normalization``: n’applique que des règles de
   remplacement spécifiées par -r

ATTENTION: si vous spécifiez un fichier de règles de normalisation, ces
règles seront appliquées avant toute autre chose. Donc, il faut être
très prudent si vous manipulez les séparateurs dans ces règles.

PolyLex
-------

``PolyLex [OPTIONS] <list>``

Ce programme prend en paramètre un fichier de mots inconnus ``<list>``
et essaye d’analyser chacun d’eux comme un mot composé obtenu par
soudure de mots simples. Les mots qui ont au moins une analyse sont
retirés du fichier de mots inconnus et les lignes de dictionnaire
correspondant aux analyses sont ajoutées au fichier ``OUT``.

**OPTIONS:**

-  ``-a ALPH``/``--alphabet=ALPH``: le fichier alphabet à utiliser;

-  ``-d BIN``/``--dictionary=BIN``: le dictionnaire .bin à utiliser;

-  ``-o OUT``/``--output=OUT``: désigne le fichier dans lequel les
   lignes de dictionnaire produites doivent être enregistrées, si ce
   fichier existe déjà, les lignes sont ajoutées à la fin du fichier;

-  ``-i INFO``/``--info=INFO``: désigne un fichier texte dans lequel les
   informations relatives à l’analyse a été réalisée.

**Options de langue:**

-  ``-D``/``--dutch``

-  ``-G``/``--german``

-  ``-N``/``--norwegian``

-  ``-R``/``--russian``

NOTE: pour les mots hollandais ou norvégiens, le programme tente de lire
un fichier texte contenant une liste de mots interdits. Ce fichier est
supposé s’appeler ``ForbiddenWords.txt`` (voir section
[section-forbidden-words]) et être stocké dans le même répertoire que
``BIN``.

RebuildTfst
-----------

``RebuildTfst <tfst>``

Ce programme reconstruit l’automate du texte ``<tfst>`` en tenant compte
des modifications manuelles. Si le programme trouve un fichier
``sentenceN.grf`` dans le même répertoire que ``<tfst>``, il remplace
l’automate de la phrase ``N`` par celle représentée par
``sentenceN.grf``. L’automate du texte donné entrée est modifié.

Reconstrucao
------------

``Reconstrucao [OPTIONS] <index>``

Le programme génère une grammaire de normalisation destinée à être
appliquée avant la construction d’un automate pour un texte en langue
portugaise. Le fichier ``<index>`` représente une concordance qui doit
être produite en mode MERGE to the considered text a grammar that
extracts all forms to be normalized. Cette grammaire est nommée
``V-Pro-Suf``, et est stockée dans le répertoire
``/Portuguese/Graphs/Normalization``.

**OPTIONS:**

-  ``-a ALPH``/``--alphabet=ALPH``: le fichier alphabet à utiliser;

-  ``-r ROOT``/``--root=ROOT``: le dictionnaire inversé ``.bin`` à
   utiliser pour retrouver les formes au futur et au conditionnel à
   partir des formes canoniques. Il a été obtenu en compressant le
   dictionnaire des verbes au futur et au conditionnel avec le paramètre
   ``--flip`` (voir section [section-compress]);

-  ``-d BIN``/``--dictionary=BIN``: le dictionnaire ``.bin`` à utiliser;

-  ``-p PRO``/``--pronoun_rules=PRO``: la grammaire ``.fst2`` de
   réécriture des pronoms;

-  ``-n PRO``/``--nasal_pronoun_rules=PRO``: la grammaire ``.fst2`` de
   réécriture des pronoms nasaux;

-  ``-o OUT``/``--output=OUT``: le nom du graphe ``.grf`` à générer

Reg2Grf
-------

``Reg2Grf <txt>``

Ce programme construit un fichier ``.grf`` correspondant à l’expression
rationnelle contenue dans le fichier ``<txt>``. Le paramètre ``<txt>``
doit représenter le chemin d’accès complet au fichier contenant
l’expression rationnelle. Ce fichier doit être un fichier texte Unicode.
Le programme prend en compte tous les caractères jusqu’au premier retour
à ligne. Le fichier résultat se nomme ``regexp.grf`` et est sauvegardé
dans le même répertoire que ``<txt>``.

Seq2Grf
-------

[Seq2Grf] ``Seq2Grf [OPTIONS] <snt>``

ce programme construit un fichier ``.grf`` qui correspond aux séquences
contenues dans le fichier ``<snt>``.

**OPTIONS:**

-  ``-a ALPH``/``--alphabet=ALPH``: le fichier alphabet à utiliser;

-  ``-o XXX``/``--output=XXX``: le fichier graphe de sortie;

-  ``-s``/``--only-stop``: ne considérer que les séquences séparées par
   ``{STOP}``;

-  ``-b``/``--beautify``: appliquer au graphe l’algorithme beautify;

-  ``-n``/``--no_beautify``: ne pas appliquer au graphe l’algorithme
   beautify; (par défaut);

-  ``--case-sensitive``: respect de la casse (par défaut);

-  ``--case-insensitive``: non respect de la casse;

-  ``-w x``: nombre de jokers;

-  ``-i x``: nombre d’insertions;

-  ``-r x``: nombre de remplacement;

-  ``-d x``: nombre de délitions;

Construire l’automate des séquences : un unique automate qui reconnaît
toutes les séquences du SNT. Les séquences doivent être délimitées par
l’étiquette ``{STOP}``;. Le fichier ``.grf`` produit est stocké dans le
répertoire Graphs de l’utilisateur. Les autres fichiers, nommés
``text.tfst``, ``text.tind`` se trouvent dans le répertoire text.

SortTxt
-------

``SortTxt [OPTIONS] <txt>``

Ce programme effectue un tri lexicographique des lignes du fichier
``<txt>``. ``<txt>`` doit représenter le chemin d’accès complet au
fichier à trier.

**OPTIONS:**

-  ``-n``/``--no_duplicates``: supprime les doublons (par défaut);

-  ``-d``/``--duplicates``: conserve les doublons;

-  ``-r``/``--reverse``: trie en ordre décroissant;

-  ``-o XXX``/``--sort_order=XXX``: trie en utilisant l’ordre
   alphabétique défini par le fichier ``XXX``. Si ce paramètre est
   abscent, le tri est effectué selon l’ordre des caractères Unicode;

-  ``-l XXX``/``--line_info=XXX``: sauvegarde le nombre de lignes du
   fichier résultat dans le fichier ``XXX``;

-  ``-t``/``--thai``: option à utiliser pour trier un texte Thai.

-  ``-f``/``--factorize_inflectional_codes``: transforme les deux
   entrées XXX,YYY.ZZZ:A et XXX,YYY.ZZZ:B en l’entrée unique
   XXX,YYY.ZZZ:A:B

L’opération de tri modifie le fichier texte. Par défaut, le tri est
effectué dans l’ordre des caractères en Unicode, en supprimant les
doublons.

Stats
-----

``Stats [OPTIONS] <ind>``

Ce programme calcule des statistiques à partir du fichier d’index de
concordances ``<ind>``.

**OPTIONS:**

-  ``-m MODE``/``--mode=MODE``: spécifie la sortie à produire:

   -  ``0`` = séquence reconnue avec contexte gauche et droit + nombre
      d’occurrences;

   -  ``1`` = cooccurrences + nombre d’occurrences;

   -  ``2`` = cooccurrences + nombre d’occurrences + z-score.

-  ``-a ALPH``/``--alphabet=ALPH``: fichier alphabet à utiliser;

-  ``-o OUT``/``--output=OUT``: fichier de sortie;

-  ``-l N``/``--left=N``: longueur du contexte gauche en tokens;

-  ``-r N``/``--right=N``: longueur du contexte droit en tokens;

-  ``-c N``/``--case=N``: traitement de la casse: ``0`` = non respect de
   la casse, ``1`` = respect de la casse (par défaut).

Table2Grf
---------

``Table2Grf [OPTIONS] <table>``

Ce programme génère automatiquemient des graphes à partir de la table de
lexique- grammaire ``<table>`` et d’un graphe patron

**OPTIONS:**

-  ``-r GRF``/``--reference_graph=GRF``: nom du graphe patron;

-  ``-o OUT``/``--output=OUT``: nom du graphe résultant principal;

-  ``-s XXX``/``--subgraph_pattern=XXX``: si ce paramètre optionnel est
   spécifié, tous les sous-graphes produits seront nommés en fonction de
   ce motif. Afin d’avoir des noms non ambigus, nous vous recommandons
   d’inclure ``@%`` dans le paramètre (rappelons que ``@%`` sera
   remplacé par le numéro de ligne de l’entrée dans la table). Par
   exemple, si vous définissez le paramètre par le motif
   ’\ ``subgraph-@%.grf``\ ’, les noms de sous-graphe seront de la forme
   ’\ ``subgraph-0013.grf``\ ’. Par défaut, les noms de sous-graphe
   ressemblent à ’\ ``result_0013.grf``\ ’, où ’\ ``result.grf``\ ’ est
   le graphe résultant principal.

Tagger
------

``Tagger [OPTIONS] <tfst>`` [section-Tagger]

L’entrée de ce programme est l’automate du texte spécifié dans
``.tfst``. Le programme applique l’algorithme de Viterbi et produit un
automate linéaire. L’automate est élagué de façon probabiliste selon un
modèle de Markov caché de second ordre. Si fichier tagger indiqué
contient des tuples de type “cat” , le tagger élague les transitions sur
la base des codes grammaticaux, syntaxiques et sémantiques (par exemple,
``that.DET+Ddem`` versus ``that.PRO+Pdem``). Par contre si le fichier
contient des tuples de type “morph”, le tagger élague les transitions
sur la base des codes grammaticaux, syntaxiques, sémantiques et
flexionnels (``the.DET+Ddef:s`` versus ``the.DET+Ddef:p``). Dans le cas
où, l’automate doit être développé avant d’applique le processus
d’étiquetage un fichier tagset doit re indiqué avec l’option ``-t``
ci-dessous.

**OPTIONS:**

-  ``-a ALPH``/``--alphabet=ALPH``: fichier alphabet.

-  ``-o OUT``/``--output=OUT``: automate du texte en sortie.

-  ``-t TAGSET``/``--tagset=TAGSET``: nom du fichier tagset.

-  ``-d DATA``/``--data=DATA``: un fichier de donné tagger .bin qui
   contient le nombre d’occurences d’ unigramme, de bigrammes et de
   trigrammes afin de calculer des probabilités. ce fichier est fournit
   avec le programme ``TrainingTagger`` (voir section
   [section-training-dict]).

TagsetNormTfst
--------------

``TagsetNormTfst [OPTIONS] <tfst>``

Ce programme normalise l’automate de texte ``.tfst`` selon un fichier de
jeu d’étiquettes, en supprimmant les codes dictionnaire non déclarés et
les entrées lexicales incohérentes. Les caractéristiques flexionnelles
ne pas sont factorisées afin que ``{rouge,.A:fs:ms}`` soit divisé en
deux étiquettes ``{rouge,.A:fs}`` et ``{rouge,.A:ms}``.

**OPTIONS:**

-  ``-o OUT``/``--output=OUT``: automate de texte résultant. Par défaut,
   l’automate du texte donné en entrée est modifié;

-  ``-t TAGSET``/``--tagset=TAGSET``: nom du fichier de description du
   jeu d’étiquettes

TEI2Txt
-------

``TEI2Txt [OPTIONS] <xml>``

Produit un fichier de texte brut à partir du fichier TEI ``<xml>``.

**OPTIONS:**

-  ``-o TXT``/``--output=TXT``: nom du fichier de texte de sortie. Par
   défaut, le fichier de sortie porte le même nom que celui d’entrée,
   remplaçant ``.xml`` by ``.txt``.

Tfst2Grf
--------

``Tfst2Grf [OPTIONS] <tfst>``

Ce programme extrait un automate de phrase en format ``.grf`` format à
partir d’un automate du texte donné.

**OPTIONS:**

-  ``-s N``/``--sentence=N``: le nombre de phrases à extraire;

-  ``-o XXX``/``--output=XXX``: motif utilisé pour nommer le fichier de
   sortie ``XXX.grf``, ``XXX.txt`` et ``XXX.tok``
   (defaut=``cursentence``);

-  ``-f FONT``/``--font=FONT``: définit la police à utiliser en sortie
   ``.grf``

   (default=``Times new Roman``);

-  ``-z N``/``--fontsize=N``: définit la taille de police (defaut=10).

Le programme produit les fichiers suivants et les enregistre dans le
répertoire du texte:

-  ``cursentence.grf``: graphe représentant l’automate de la phrase;

-  ``cursentence.txt``: fichier texte contenant la phrase;

-  ``cursentence.tok``: fichier texte contenant le nombre de token qui
   compose la phrase;

Tfst2Unambig
------------

``Tfst2Unambig [OPTIONS] <tfst>``

Ce programme prend un automate de texte ``.tfst`` et produit le fichier
texte équivalent si celui-ci est linéaire (i.e. sans ambiguïté). Voir
section [section-linear-text], page .

**OPTIONS:**

-  ``-o TXT``/``--out=TXT``: fichier de sortie.

Tokenize
--------

[section-Tokenize] ``Tokenize [OPTIONS] <txt>``

Ce programme découpe le texte en unités lexicales. ``<txt>`` le chemin
d’accès complet au fichier texte, sans omettre l’extension ``.snt``
extension.

**OPTIONS:**

-  ``-a ALPH``/``--alphabet=ALPH``: alphabet file;

-  ``-c``/``--char_by_char``: indique que le programme est appliqué
   caractère par caractère à l’exception du délimiteur de phrase
   ``{S}``, du marqueur ``{STOP}`` et d’étiquettes lexicales comme
   ``{today,.ADV}`` qui sont considérées comme des unités simples;

-  ``-w``/``--word_by_word``: Avec cette option, le programme considère
   qu’une unité est soit une séquence de lettres (ces lettres sont
   définies dans le fichier ``alphabet``), ou un caractère qui n’est pas
   une lettre, ou le délimiteur de phrase ``{S}``, ou une étiquette
   lexicale comme ``{aujourd'hui,.ADV}``. C’est le mode par défaut.

-  ``-t TOKENS``/``--tokens=TOKENS``: désigne un fichier a
   ``tokens.txt`` à charger et à modifier, au lieu d’en créer un nouveau
   à partir de zéro.

**Options d’offsets:**

-  ``input_offsets``: fichier offsets d’entrée;

-  ``output_offsets``: fichier offsets à produire;

Le programme code chaque unité par un entier. La liste des unités est
sauvegardée dans un fichier texte nommé ``tokens.txt``. La suite des
codes représentant les unités permet alors de coder le texte. Cette
suite est sauvegardée dans un fichier binaire nommé ``text.cod``. Le
programme produit également les fichiers suivants :

-  ``tok_by_freq.txt``: fichier texte contenant la liste des unités
   triées par ordre de fréquence ;

-  ``tok_by_alph.txt``: fichier texte contenant la liste des unités
   triées par ordre alphabétique ;

-  ``stats.n``: fichier texte contenant des informations sur le nombre
   de séparateurs de phrases, le nombre d’unités, le nombre de mots
   simples et le nombre de chiffres ;

-  ``enter.pos``: fichier binaire contenant la liste des positions des
   retours à la ligne dans le texte. La représentation codée du texte ne
   contient pas de retours à la ligne, mais des espaces. Comme un retour
   à la ligne compte pour 2 caractères et l’espace pour un seul, il faut
   savoir où se trouvent les retours à la ligne dans le texte si l’on
   veut synchroniser les positions des occurrences calculées par le
   programme ``Locate`` avec le fichier texte. Le fichier ``enter.pos``
   est utilisé à cette fin par le programme ``Concord`` C’est grâce à
   cela que lorsque l’on clique sur une occurrence dans une concordance,
   celle-ci est correctement sélectionnée dans le texte.

Tous les fichiers produits sont sauvegardés dans le répertoire du texte.

TrainingTagger
--------------

``TrainingTagger [OPTIONS] <txt>`` [section-TrainingTagger]

Ce programme génère automatiquement deux fichiers de données Tagger à
partir d’un corpus étiqueté. Ils sont utilisés par le programme
``Tagger`` afin de calculer les probabilités et linéariser l’automate
texte. Le fichier corpus étiqueté doit suivre le format décrit à la
section [section-corpus-file]. Ces fichiers contiennent des tuples
(unigrammes, bigrammes et trigrammes), formées par des balises et des
mots. Dans le premier fichier de données, les étiquettes sont de type
“cat” (i.e. des codes grammaticaux, syntaxiques et sémantiques). Dans le
second fichier de données, les étiquettes sont de type “morph” (i.e. des
codes grammaticaux, syntaxiques, sémantiques et flexionnels).

**OPTIONS:**

-  ``-a/--all``: indique que le programme doit produire tous les
   fichiers de données (par défaut);

-  ``-c/--cat``: indique que le programme ne doit produire que les
   fichiers de données avec “cat”;

-  ``-m/--morph``: indique que le programme ne doit produire que les
   fichiers de données avec “morph”;

-  ``-n/--no_binaries``: indique que le programme ne doit pas compresser
   les fichiers de données en fichiers ``.bin``, seulement dans ce cas
   les fichiers de données ``.dic`` sont genérés;

-  ``-b/--binaries``: indique que le programme doit compresser les
   fichiers de données en fichiers ``.bin`` files (par défaut);

-  ``-o XXX/--output=XXX``: motif utilisé pour nommer les fichiers de
   sortie du taggueur ``XXX_data_cat.bin``; et ``XXX_data_morph.bin``
   (par défaut: nom de fichier sans extension corpus de textes);

-  ``-s/--semitic``: indique que l’algoritme de compression sémitique
   doit être utilisé;

Txt2Tfst
--------

``Txt2Tfst [OPTIONS] <txt>`` Ce programme construit l’automate du texte.
Le paramètre ``<txt>`` doit représenter le chemin d’accès complet au
fichier texte, sans omettre l’extension ``.snt``

**OPTIONS:**

-  ``-a ALPH``/``--alphabet=ALPH``: fichier alphabet;

-  ``-c``/``--clean``: indique que la règle de conservation des
   meilleurs chemins (voir section [section-keeping-best-paths]) doit
   être utilisée ;

-  ``-n XXX``/``--normalization_grammar=XXX``: nom de la grammaire de
   normalisation qui doit être appliquée à l’automate de texte;

-  ``-t TAGSET``/``--tagset=TAGSET``: fichier de jeu d’étiquete Elag
   pour la normalisation des entrées du dictionnaire;

-  ``-K``/``--korean``: indique à ``Txt2Tfst`` qu’il traite du coréen.

Si le texte a été découpé en phrases, le programme construit un automate
pour chaque phrase. Si ce n’est pas le cas, le programme découpe
arbitrairement le texte en séquences de 2000 unités lexicales et
construit un automate pour chacune de ces séquences.

Le résultat est un fichier nommé ``text.tfst`` qui est sauvegardé dans
le répertoire du texte. Un autre fichier ``text.tind`` est aussi
produit.

NOTE: Ce programme essaye également d’utiliser le fichier ``tags.ind``
s’il existe (voir section [section-tags-ind]).

Uncompress
----------

[section-Uncompress] ``Uncompress [OPTIONS] <bin>``

Ce programme décompresse un dictionnaire ``.bin`` en un fichier texte
``.dic``.

**OPTIONS:**

-  ``-o OUT``/``--output=OUT``: nom du fichier de sortie optionnel (par
   défaut: ``file.bin`` > ``file.dic``).

Untokenize
----------

[section-Untokenize] ``Untokenize [OPTIONS] <txt>``

Untokenize et reconstruit le texte orgininal. La liste des token est
stockée dans le fichier ``tokens.txt`` et le texte codé dans
``text.cod``. Le fichier ``enter.pos`` contient la position en tokens de
tous les retours à la ligne Ces fichiers se trouvent dans le répertoire
XXX\_snt où XXX est sans son extension <txt>.

**OPTIONS:**

-  ``-d X``/``--sntdir=X``: utilise le répertoire X au lieu du
   répertoire texte; remarquez que X doit se terminer par un antislash

-  ``-n N``/``--number_token=N``: ajoute le numéro de token chaque N
   token;

-  ``-r N``/``--range=N``: émet seulement les tokens du numéro N à la
   fin;

-  ``-r N,M``/``--range=N,M``: émet seulement les tokens du numéro N à
   M.

UnitexTool
----------

[section-UnitexTool] ``UnitexTool <utilities>``

Ce programme est un programme qui vous permet d’exécuter tous les
programmes externes d’Unitex Avec lui, vous pouvez enchaîner les
commandes afin qu’elles soit exécutées dans un même processus, afin
d’accélérer le traitement. Cela se fait en invoquant des commandes
imbriquées entre parenthèses comme ceci:

::

    UnitexTool { SelectOutput [OPTIONS] } 
                    { cmd #1+args } 
                    { cmd #2+args }
                    etc.

Par exemple, si vous souhaitez faire un locate et construire la
concordance, vous pouvez utiliser la commande suivante:

::

    UnitexTool { Locate "-tD:\My Unitex\English\Corpus\ivanhoe.snt" 
    "D:\My Unitex\English\regexp.fst2"
    "-aD:\My Unitex\English\Alphabet.txt" -L -I -n200 
    "--morpho=D:\Unitex2.0\English\Dela\dela-en-public.bin" -b -Y }
    { Concord "D:\My Unitex\English\Corpus\ivanhoe_snt\concord.ind" 
    "-fCourier new" -s12 -l40 -r55 --CL --html 
    "-aD:\My Unitex\English\Alphabet_sort.txt" }

**OPTIONS**:

-  ``-o [on/off]``/``--output=[on/off]``: activer (on) ou désactiver
   (off) la sortie standard

-  ``-e [on/off]``/``--error=[on/off]``: activer (on) ou désactiver
   (off) la sortie erreur standard

Par exemple:

::

    UnitexTool { SelectOutput -o off -e off } { Normalize
    Unitex\English\Corpus\ivanhoe.txt }

UnitexToolLogger
----------------

[section-UnitexToolLogger] ``UnitexToolLogger <utilities>``

Ce programme est un surensemble de UnitexTool. Il permet d’exécuter à
nouveau un fichier de log .ulp. Il peut également enregistrer une
session d’UnitexTool en cours d’exécution et créer un fichier de log
.ulp. Si UnitexToolLogger est utilisé comme UnitexTool (avec uniquement
les paramètres contenant des lignes de commande pour des programmes
Unitex externes), et qu’un fichier contenant un chemin et nommé
unitex\_logging\_parameters\_count.txt est présent dans le répertoire
courant, alors un fichier de log .ulp pour la session en cours sera
créé. Le fichier .ulp est un fichier zip comprimé (compatible avec
unzip), qui peut être utile pour le débogage.

``UnitexToolLogger RunLog [OPTIONS] <ulp>``

**OPTIONS after RunLog:**

-  ``-m``/``--quiet``: n’émet pas de messages lors de l’exécution;

-  ``-v``/``--verbose``: émet des messages lors de l’exécution;

-  ``-d DIR``/``--rundir=DIR``: chemin où le fichier log est exécuté;

-  ``-r newfile.ulp``/``--result=newfile.ulp``: nom du fichier ulp
   résultat créé;

-  ``-c``/``--clean``: supprime le fichier de travail après l’exécution;

-  ``-k``/``--keep``: conserve le fichier de travail après l’exécution;

-  ``-s file.txt``/``--summary=file.txt``: fichier \*\* avec comparaison
   de log

-  ``-e file.txt``/``--summary-error=file.txt``: fichier de synthèse
   avec comparaison des erreurs;

-  ``-b``/``--no-benchmark``: ne pas enregistrer le temps d’exécution
   dans les fichiers log;

-  ``-n``/``--cleanlog``: supprime le résultat ulp après exécution;

-  ``-l``/``--keeplog``: garde le résultat ulp après exécution;

-  ``-o NameTool``/``--tool=NameTool``: lance seulement les log pour
   ``NameTool``;

-  ``-i N``/``--increment=N``: incrémenter le nom de fichier <ulp> de 0
   à N;

-  ``-t N``/``--thread=N``: créer N thread;

-  ``-a N``/``--random=N``: choisir N fois un fichier log aléatoire dans
   la liste (dans chaque thread);

-  ``-f N``/``--break-after=N``: l’utilisateur annule après N exécutions
   (avec seulement un seul thread);

-  ``-u PATH``/``--unfound-location=PATH``: prend le dictionnaire et le
   FST2 à partir de PATH s’il est absent du fichier log;

Une autre utilisation UnitexToolLogger est d’utiliser l’option
MzRepairUlp pour réparer un fichier ulp abîmé (souvent, un log de
crash):

``UnitexToolLogger MzRepairUlp [OPTIONS] <ulpfile>``

**OPTIONS après MzRepairUlp:**

-  ``-t X``/``--temp=X``: utilise X comme nom de fichier temporaire
   (<ulpfile>.build par défaut);

-  ``-o X``/``--output=X``: utilise X comme nom de fichier .ulp
   (<ulpfile>.repair par défaut);

-  ``-m``/``--quiet``: n’émet pas de message lors de l’exécution;;

-  ``-v``/``--verbose``: émet un message lors de l’exécution;

Une autre utilisation de UnitexToolLogger est d’utiliser l’option
CreateLog option (avec des accolades) pour créer un fichier log
d’exécutions de programme Unitex, comme:

``UnitexToolLogger { CreateLog [OPTIONS] } cmd args``

``UnitexToolLogger { CreateLog [OPTIONS] } { cmd #1+args } { cmd #2+args } etc.``

Par exemple,

::

    UnitexToolLogger { CreateLog --log_file=my_run_normalize.ulp }
                 Normalize "C:\My Unitex\French\Corpus\80jours.txt"

::

    UnitexToolLogger { CreateLog --directory=c:\logs }
                      { Compress c:\dela\mydela.dic }
                      { CheckDic --delaf c:\dela\mydela.inf }

**OPTIONS après CreateLog:**

-  ``-g``/``--no_create_log``: ne pas créer de fichier log. Incompatible
   avec toutes les autres options;

-  ``-p XXX``/``--param_file=XXX``: charge un fichier de paramètres
   comme unitex\_logging\_parameters.txt. Incompatible avec toutes les
   autres options;

-  ``-d XXX/--directory=XXX``: Emplacement du répertoire où le fichier
   log est créé;

-  ``-l XXX/--log_file=XXX``: nom du fichier log à créer;

-  ``-i``/``--store_input_file``: enregistre le fichier d’entrée dans
   log (par défaut);

-  ``-n``/``--no_store_input_file``: n’enregistre pas le fichier
   d’entrée dans log (empêche de relancer le fichier log);

-  ``-o``/``--store_output_file``: enregistre le fichier de sortie dans
   log;

-  ``-u``/``--no_store_output_file``: n’enregistre pas le fichier de
   sortie dans log (par défaut);

-  ``-s``/``--store_list_input_file``: enregistre la liste de fichiers
   d’entrée dans log (par défaut);

-  ``-t``/``--no_store_list_input_file``: n’enregistre pas la liste de
   fichiers d’entrée dans log;

-  ``-r``/``--store_list_output_file``: enregistre la liste de fichiers
   de sortie dans log (par défaut);

-  ``-f``/``--no_store_list_output_file``: n’enregistre pas la liste de
   fichiers de sortie dans log.

::

    UnitexToolLogger { SelectOutput [OPTIONS] } 
                    { cmd #1+args } 
                    { cmd #2+args }
                    etc.

**OPTIONS après SelectOutput :**

-  ``-o [on/off]``/``--output=[on/off]``: activer (on) ou désactiver
   (off) la sortie standard

-  ``-e [on/off]``/``--error=[on/off]``: activer (on) ou désactiver
   (off) la sortie erreur standard

Par exemple:

::

    UnitexToolLogger { SelectOutput -o off -e off } { Normalize 
    Unitex\English\Corpus\ivanhoe.txt }

Unxmlize
--------

[section-Unxmlize]

Ce programme supprime tous les tags xml d’un fichier .xml ou .html donné
pour produire un fichier texte traitable par Unitex.
``Unxmlize [OPTIONS] <file>``

**OPTIONS:**

-  ``-o TXT``/``--output=TXT``: fichier de sortie. Par défaut, foo.xml
   => foo.txt

-  ``--output_offsets=XXX``: spécifie le fichier offset à produire

-  ``--PRLG=XXX``: extrait dans le fichier XXX des informations
   utilisées dans le projet PRLG du grec ancien (exige
   ``--output_offsets``)

-  ``-t``/``--html``: considère le fichier comme un fichier html (ne
   tient pas compte de l’extension)

-  ``-x``/``--xml``: considère le fichier comme un fichier xml (ne tient
   pas compte de l’extension)

-  ``-l``/``--tolerate``: essayez tolérer des malformations de balisage

-  ``--comments=IGNORE``: chaque commentaire est supprimé (par défaut)

-  ``--comments=SPACE``: chaque commentaire est remplacé par un simple
   espace

-  ``--scripts=IGNORE``: chaque script block is removed

-  ``--scripts=SPACE``: chaque commentaire est remplacé par un simple
   espace (par défaut pour .html)

Note: par défaut, balises de script sont traitées comme des balises
normales (par défaut pour .xml).

-  ``--normal_tags=IGNORE``: chaque tag différent est supprimé (par
   défaut pour .xml)

-  ``--normal_tags=SPACE``: chaque tag différent est remplacé est
   remplacé par un unique espace (par défaut pour .html)

XMLizer
-------

[section-XMLizer] ``XMLizer [OPTIONS] <txt>``

Ce programme prend un fichier texte brut ``<txt>`` et produit le fichier
équivalent au format TEI ou XML. La différence entre TEI et XML est que
les fichier TEI contiennent une en-tête de type TEI.

**OPTIONS:**

-  ``-x``/``--xml``: produit un fichier a XML;

-  ``-t``/``--tei``: produit un fichier TEI (par défaut);

-  ``-n XXX``/``--normalization=XXX``: désigne le fichier de règles de
   normalisation à utiliser (voir section [section-normalization-file]);

-  ``-o OUT``/``--output=OUT``: nom optionnel du de fichier de sortie
   (par défaut: ``file.txt`` > ``file.xml``);

-  ``-a ALPH``/``--alphabet=ALPH``: fichier alphabet;

-  ``-s SEG``/``--segmentation_grammar=SEG``: grammaire de délimitation
   de phrase à utiliser. Cette grammaire devrait ressembler à la
   grammaire ``Sentence.grf`` utilisée lors du prétraitement d’un
   corpus, mais elle peut comporter l’étiquette spéciale ``{P}`` pour
   indiquuer les limites de paragraphe.
