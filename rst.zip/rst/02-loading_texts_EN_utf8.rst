Loading a text
==============

One of the main functionalities of Unitex is to search a text for
expressions. To do that, texts have to undergo a set of preprocessing
steps that normalize non-ambiguous forms and split the text in
sentences. Once these operations are performed, the electronic
dictionaries are applied to the texts. Then one can search more
effectively in the texts by using grammars.

This chapter describes the different steps for text preprocessing.

Selecting a language
--------------------

When starting Unitex, the program asks you to choose the language in
which you want to work (see figure [fig-language-selection]). The
languages displayed are the ones that are present in the Unitex system
directory and those that are installed in your personal working
directory. If you use a language for the first time, Unitex copies the
system directory for this language to your working directory, except for
the dictionaries in order to save disk space.

WARNING: If you already have a working directory for a given language,
Unitex won’t try to copy system data into it. So, if an update has
modified a resource file other than a dictionary, you will have to copy
by yourself this file, or to delete your working directory for this
language, and let Unitex rebuild it properly.

Choosing the language allows Unitex to find certain files, for example
the alphabet file. You can change the language at any time by choosing
“Change Language...” in the “Text” menu. If you change the language, the
program will close all windows related to the current text, if there are
any. The active language is indicated in the title bar of the graphical
interface.

.. figure:: resources/img/fig2-1.png
   :alt: [fig-language-selection]Language selection when starting Unitex
   :width: 6.20000cm

   [fig-language-selection]Language selection when starting Unitex

Text formats
------------

Unitex works with Unicode texts. Unicode is a standard that describes a
universal character code. Each character is given a unique number, which
allows for representing texts without having to take into account the
proprietary codes on different machines and/or operating systems. Unitex
uses a two-byte representation of the Unicode 3.0 standard, called
Unicode Little-Endian (for more details, see
:raw-latex:`\cite{UNICODE}`).

Texts that come with Unitex are already in Unicode format. If you try to
open a text that is not in Unicode, the program proposes to convert it
(see figure [auto-transcoding]). This conversion is based on the current
language: if you are working in French, Unitex proposes to convert your
text [1]_ assuming that it is coded using a French code page. By
default, Unitex proposes to either replace the original text or to
rename the original file by inserting ``.old`` at the beginning of its
extension. For example, if one has an ASCII file named ``biniou.txt``,
the conversion process will create a copy of this ASCII file named
``biniou.old.txt``, and will replace the contents of ``biniou.txt`` with
its equivalent in Unicode.

.. figure:: resources/img/fig2-2.png
   :alt: [auto-transcoding]Automatic conversion of a non-Unicode text
   :width: 10.00000cm

   [auto-transcoding]Automatic conversion of a non-Unicode text

If the encoding suggested by default is not correct or if you want to
rename the file differently than with the suffix ``.old``, you must use
the “More options...” button. This allows you to choose source and
target encodings of the documents to be converted (see
figure [transcoding]). By default, the selected source encoding is that
which corresponds to the current language and the destination encoding
is Unicode Little-Endian. You can modify these choices by selecting any
source and target encodings. Thus, if you wish, you can convert your
data into other encodings, as for example UTF-8 in order for instance to
create web pages. The button “Add Files” enables you to select the files
to be converted. The button “Remove Files” makes it possible to remove a
list of files erroneously selected. The button “Transcode” will start
the conversion of all the selected files. If an error occurs with a file
is processed (for example, a file which is already in Unicode), the
conversion continues with the next file.

.. figure:: resources/img/fig2-3.png
   :alt: [transcoding]Transcoding files
   :width: 12.00000cm

   [transcoding]Transcoding files

To obtain a text in the right format, you can also use a text processor
like the free software from OpenOffice.org
(:raw-latex:`\cite{OpenOffice}`) or Microsoft Word, and save your
document with the format “Unicode text”. In OpenOffice Writer, you have
to choose the “Coded Text (\*.txt)” format and then select the “Unicode”
encoding in the configuration window as shown on figure [OfficeWriter].

.. figure:: resources/img/fig2-4.png
   :alt: [OfficeWriter]Saving in Unicode with OpenOffice Writer
   :width: 12.50000cm

   [OfficeWriter]Saving in Unicode with OpenOffice Writer

By default, the encoding proposed on a PC is always Unicode
Little-Endian. The texts thus obtained do not contain any formatting
information anymore (fonts, colors , etc.) and are ready to be used with
Unitex.

You can change the default encoding to UTF16LE, UTF16BE or UTF8 in the
’Encoding’ tab via the Preference command in the Info menu. This
encoding is valid for the current language only.

.. figure:: resources/img/fig2-5.png
   :alt: [OfficeWriter]Setting the default encoding for current language
   :width: 10.00000cm

   [OfficeWriter]Setting the default encoding for current language

Editing text files
------------------

For small texts, you also have the possibility of using the text editor
integrated into Unitex, accessible via the “Open...” command in the
“File Edition” menu. This editor offers search and replace
functionalities for the texts and dictionaries handled by Unitex. To use
it, click on the “Find” icon. You will then see a window divided into
three parts. The “Find” part corresponds to the usual search operations.
If you open a text split into sentences, you can base your search on
sentence numbers in the “Find Sentence” part. Lastly, the “Search
Dictionary” part, visible in figure [dictionary-search], enables you to
carry out operations concerning the electronic dictionaries. In
particular, you can search by specifying if it concerns inflected forms,
lemmas, grammatical and semantic and/or inflectional codes. Thus, if you
want to search for all the verbs which have the semantic feature ``t``,
which indicates transitivity, you just have to search for ``t`` by
clicking on “Grammatical code”. You will get the matching entries
without confusion with all the other occurrences of the letter ``t``.

.. figure:: resources/img/fig2-6.png
   :alt: Searching an electronic dictionary for the semantic feature
   ``t``\ [dictionary-search]
   :width: 15.00000cm

   Searching an electronic dictionary for the semantic feature
   ``t``\ [dictionary-search]

Opening a text
--------------

Unitex deals with several types of documents. The files with the
extension ``.snt`` are text files preprocessed by Unitex which are ready
to be manipulated by the different system functions. You can also load
raw files ending with ``.txt``, or XML and HTML files. To open any of
these files, click on “Open...” in the “Text” menu. You can there choose
the file type (“Raw Unicode Texts”, “XML files”, “HTML files”, “Unitex
Texts”). If you open XML or HTML files, foo.xml for example, it will be
preprocessed in order to remove non textual content. This will produce a
foo.xml.txt file containing only the textual content of the original
file. The resulting ``.txt`` file will be processed to produce a
``.snt`` file

.. figure:: resources/img/fig2-7.png
   :alt: Text Menu
   :width: 14.00000cm

   Text Menu

.. figure:: resources/img/fig2-8.png
   :alt: Opening a Unicode text
   :width: 13.00000cm

   Opening a Unicode text

Preprocessing a text
--------------------

After a text is selected, Unitex offers to preprocess it. Text
preprocessing consists of performing the following operations:
normalization of separators, splitting into sentences, normalization of
non-ambiguous forms, tokenization and application of dictionaries. If
you choose not to preprocess the text, it will nevertheless be
normalized and tokenized, since these operations are necessary for all
further Unitex operations. It is always possible to carry out the
preprocessing later by clicking on “Preprocess Text...” in the “Text”
menu.

.. figure:: resources/img/fig2-9.png
   :alt: Preprocessing Window[fig-preprocessing-frame]
   :width: 15.00000cm

   Preprocessing Window[fig-preprocessing-frame]

If you choose to preprocess the text, Unitex proposes to parameterize it
as in the window shown in figure [fig-preprocessing-frame]. The option
“Apply FST2 in MERGE mode” is used to split the text into sentences. The
option “Apply FST2 in REPLACE mode” is used to make replacements in the
text, especially for the normalization of non-ambiguous forms. With the
option “Apply All default Dictionaries” you can apply dictionaries in
the DELA format (Dictionnaires Electroniques du LADL). The option
“Analyze unknown words as free compound words” is used in Norwegian for
correctly analyzing compound words constructed via concatenation of
simple forms. Finally, the option “Construct Text Automaton” is used to
build the text automaton. This option is deactivated by default, because
it consumes a large amount of memory and disk space if the text is too
large. The construction of the text automaton is described in
chapter [chap-text-automaton].

NOTE: If you click on “Cancel but tokenize text”, the program will carry
out the normalization of separators and split the text into tokens.
Click on “Cancel and close text” to cancel the operation.

Normalization of separators
~~~~~~~~~~~~~~~~~~~~~~~~~~~

The standard separators are the space, the tab and the newline
characters. There can be several separators following each other, but
since this isn’t useful for linguistic analyses, separators are
normalized according to the following rules:

-  a sequence of separators that contains at least one newline is
   replaced by a single newline

-  all other sequences of separators are replaced by a single space.

The distinction between space and newline is maintained at this point
because the presence of newlines may have an effect on the process of
splitting the text into sentences. The result of the normalization of a
text named ``my_text.txt`` is a file in the same directory as the
``.txt`` file and is named ``my_text.snt``.

NOTE: When the text is preprocessed using the graphical interface, a
directory named

``my_text_snt`` is created immediately after normalization. This
directory, called text directory, contains all the data associated with
this text.

Splitting into sentences
~~~~~~~~~~~~~~~~~~~~~~~~

Splitting texts into sentences is an important preprocessing step since
this helps in determining the units for linguistic processing. The
splitting is used by the text automaton construction program. In
contrast to what one might think, detecting sentence boundaries is not a
trivial problem. Consider the following text:

*The family has urgently called Dr. Martin.*

The full stop that follows *Dr* is followed by a word beginning with a
capital letter. Thus it may be considered as the end of the sentence,
which would be wrong. To avoid the kind of problems caused by the
ambiguous use of punctuation, grammars are used to describe the
different contexts for the end of a sentence.
Figure [fig-example-sentence-splitting] shows an example grammar for
sentence splitting (for French sentences).

.. figure:: resources/img/fig2-10.pdf
   :alt: Sentence splitting grammar for
   French[fig-example-sentence-splitting]
   :width: 15.00000cm

   Sentence splitting grammar for French[fig-example-sentence-splitting]

When a path of the grammar recognizes a sequence in the text and when
this path produces the sentence delimiter symbol ``{S}`` , this symbol
is inserted into the text. For example, one of the paths shown in
figure [fig-example-sentence-splitting] recognizes the sequence
consisting of a question mark and a word beginning with a capital letter
and inserts the symbol ``{S}`` between the question mark and the
following word. The following text:

*What time is it? Eight o’ clock.*

will be converted to:

*What time is it ?{S} Eight o’ clock.*

A grammar for end-of-sentence detection may use the following special
symbols, or meta-symbols:

-  ``<E>``: empty word, or epsilon. Recognizes the empty sequence;

-  ``<WORD>``: recognizes any sequence of letters;

-  ``<LOWER>``: recognizes any sequence of letters in lower case;

-  ``<UPPER>``: recognizes any sequence of letters in upper case;

-  ``<FIRST>``: recognizes any sequence of letters that begins with an
   upper case letter;

-  ``<NB>``: recognizes any sequence of digits (1234 is recognized but
   not 1 234);

-  ``<PNC>``: recognizes the punctuation symbols `` ; , ! ? :`` and the
   inverted exclamation points and question marks in Spanish and some
   Asian punctuation letters;

-  ``<^>``: recognizes a newline;

-  ``#``: prohibits the presence of a space.

Earlier codes for ``<WORD>``, ``<LOWER>``, ``<UPPER>`` and ``<FIRST>``
were respectively ``<MOT>``, ``<MIN>``, ``<MAJ>`` and ``<PRE>``. They
can still be used for backward compatibility of the system with existing
graphs. Though there are no current plans to remove this codes, it is
recommended to avoid them in graphs designed to be used with more recent
versions, [2]_ so that the number of lexical masks in use does not
increase uselessly.

By default, the space is optional between two boxes. If you want to
prohibit the presence of the space you have to use the special character
``#``. At the opposite, if you want to force the presence of the space,
you must use the sequence ``" "``. Lower and upper case letters are
defined by an alphabet file (see chapter [chap-file-formats]). For more
details on grammars, see chapter [chap-grammars]. For more information
about sentence boundary detection, see
:raw-latex:`\cite{ameliorer-decoupage-en-phrases}`. The grammar used
here is named ``Sentence.fst2`` and can be found in the following
directory:

``/(working directory)/(language)/Graphs/Preprocessing/Sentence``

This grammar is applied to a text with the ``Fst2Txt`` program in MERGE
mode. This has the effect that the output produced by the grammar, in
this case the symbol ``{S}``, is inserted into the text. This program
takes a ``.snt`` file and modifies it.

Normalization of non-ambiguous forms
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Certain forms present in texts can be normalized (for example, the
English sequence “*I’m*” is equivalent to “*I am*”). You may want to
replace these forms according to your own needs. However, you have to be
careful that the forms normalized are unambiguous or that the removal of
ambiguity has no undesirable consequences.

For instance, if you want to normalize “*O’clock*” to “*on the clock*”,
it would be a bad idea to replace “*O’*” by “*on the* ”, because a
sentence like:

*John O’Connor said: “it’s 8 O’clock”*

would be replaced by the following incorrect sentence:

*John on the Connor said: “it’s 8 on the clock”*

Thus, one needs to be very careful when using the normalization grammar.
One needs to pay attention to spaces as well. For example, if one
replaces “’re” by “are”, the sentence:

*You’re stronger than him.*

will be replaced by:

*Youare stronger than him.*

To avoid this problem, one should explicitly insert a space, *i.e.*
replace “*’re*” by “ *are*”.

The accepted symbols for the normalization grammar are the same as the
ones allowed for the sentence splitting grammar. The normalization
grammar is called ``Replace.fst2`` and can be found in the following
directory:

``/(working directory)/(language)/Graphs/Preprocessing/Replace``

As in the case of sentence splitting, this grammar is applied using the
``Fst2Txt`` program, but in REPLACE mode, which means that input
sequences recognized by the grammar are replaced by the output sequences
that are produced. Figure [fig-normalization-grammar] shows a grammar
that normalizes verbal contractions in English.

.. figure:: resources/img/fig2-11.pdf
   :alt: Normalization of English verbal
   contractions[fig-normalization-grammar]
   :height: 17.00000cm

   Normalization of English verbal
   contractions[fig-normalization-grammar]

Splitting a text into tokens
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

[tokenization] Some languages, in particular Asian languages, use
separators that are different from the ones used in western languages.
Spaces can be forbidden, optional, or mandatory. In order to better cope
with these particularities, Unitex splits texts in a language dependent
way. Thus, languages like English are treated as follows:

A token can be:

-  the sentence delimiter ``{S}``;

-  the stop marker ``{STOP}``. This token is a special one that can
   NEVER be matched in any way by a grammar. It can be used to bound
   elements in a corpus. For instance, if a corpus is made of news
   separated by ``{STOP}``, it will be impossible that a grammar matches
   a sequence that overlaps the end of a news and the beginning of the
   following news;

-  a lexical tag ``{aujourd'hui,.ADV}``;

-  a contiguous sequence of letters (the letters are defined in the
   language alphabet file);

-  one (and only one) non-letter character, i.e. all characters not
   defined in the alphabet file of the current language; if it is a
   newline, it is replaced by a space.

For other languages, tokenization is done on a character by character
basis, except for the sentence delimiter ``{S}``, the ``{STOP}`` marker
and lexical tags. This simple tokenization is fundamental for the use of
Unitex, but limits the optimization of search operations for patterns.

Regardless of the tokenization mode, newlines in a text are replaced by
spaces. Tokenization is done by the ``Tokenize`` program. This program
creates several files that are saved in the text directory:

-  ``tokens.txt`` contains the list of tokens in the order in which they
   are found in the text;

-  ``text.cod`` contains an integer array; every integer corresponds to
   the index of a token in the file ``tokens.txt``;

-  ``tok_by_freq.txt`` contains the list of tokens sorted by frequency;

-  ``tok_by_alph.txt`` contains the list of tokens in alphabetical
   order;

-  ``stats.n`` contains some statistics about the text.

Tokenizing the text:

*A cat is a cat.*

returns the following list of tokens: *A* SPACE *cat is a .*

You will observe that tokenization is case sensitive (*A* and *a* are
two distinct tokens), and that each token is listed only once. Numbering
these tokens from 0 to 5, the text can be represented by a sequence of
numbers (integers) as described in the following table:

+-----------------------+-------+-----+---------+-----+--------+-----+-------+-----+---------+-------+----+----+
| Token number          | 0     | 1   | 2       | 1   | 3      | 1   | 4     | 1   | 2       | 5     |    |    |
+=======================+=======+=====+=========+=====+========+=====+=======+=====+=========+=======+====+====+
| Corresponding token   | *A*   |     | *cat*   |     | *is*   |     | *a*   |     | *cat*   | *.*   |    |    |
+-----------------------+-------+-----+---------+-----+--------+-----+-------+-----+---------+-------+----+----+

Table: Representation of the text *A cat is a cat.*

For more details, see chapter [chap-file-formats].

.. figure:: resources/img/fig2-12.png
   :alt: Tokens of an English text sorted by frequency
   :height: 10.00000cm

   Tokens of an English text sorted by frequency

Applying dictionaries
~~~~~~~~~~~~~~~~~~~~~

Applying dictionaries consists of building the subset of dictionaries
consisting only of forms that are present in the text. Thus, the result
of applying a English dictionary to the text *Igor’s father in law is
ill* produces a dictionary of the following simple words:

::

    father,.N+Hum:s
    father,.V:W:P1s:P2s:P1p:P2p:P3p
    ill,.A
    ill,.ADV
    ill,.N:s
    in,.A
    in,.N:s
    in,.PART
    in,.PREP
    is,be.V:P3s
    is,i.N:p
    law,.N:s
    law,.V:W:P1s:P2s:P1p:P2p:P3p
    s,.N:s

as well as a dictionary of compound words consisting of a single entry:

::

    father in law,.N+NPN+Hum+z1:s

Since the sequence *Igor* is neither a simple English word nor a part of
a compound word, it is treated as an unknown word. The application of
dictionaries is done through the program ``Dico``. The three files
produced (``dlf`` for simple words, ``dlc`` for compound words and
``err`` for unknown words) are placed in the text directory. The ``dlf``
and ``dlc`` files are called text dictionaries.

As soon as the dictionary look-up is finished, Unitex displays the
sorted lists of simple, compound and unknown words found in a new
window. Figure [fig-Dico-application-results] shows the result for an
English text.

.. figure:: resources/img/fig2-13.png
   :alt: Result after applying dictionaries to an English
   text[fig-Dico-application-results]
   :width: 12.00000cm

   Result after applying dictionaries to an English
   text[fig-Dico-application-results]

It is also possible to apply dictionaries without preprocessing the
text. In order to do this, click on “Apply Lexical Resources...” in the
“Text” menu. Unitex then opens a window (see
figure [fig-Dico-configuration]) in which you can select the list of
dictionaries to apply.

.. figure:: resources/img/fig2-14.png
   :alt: Parameterizing the application of
   dictionaries[fig-Dico-configuration]
   :width: 10.00000cm

   Parameterizing the application of
   dictionaries[fig-Dico-configuration]

The list “User resources” lists all dictionaries present in the
directory

``(current language)/Dela`` of the user. The dictionaries installed in
the system are listed in the scroll list named “System resources”. Use
the <Ctrl+click> combination to select several dictionaries. System
dictionaries will be applied prior to user dictionaries. Within the
system or user list, you can fix the order of dictionaries using the up
and down arrows, as shown on figure [fig-Dico-configuration]. The button
“Set Default” allows you to define the current selection of dictionaries
as the default. This default selection will then be used during
preprocessing if you activate the option “Apply All default
Dictionaries”. If you right-click on a dictionary name, the associated
documentation, if any, will be displayed in the lower frame of the
window.

Analysis of compound words in Dutch, German, Norwegian and Russian
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

[section-Norwegian-compound-words] In certain languages like Norwegian,
German and others, it is possible to form new compound words by
concatenating together other words. For example, the word *aftenblad*
meaning *evening journal* is obtained by combining the words *aften*
(*evening*) et *blad* (*journal*). The ``PolyLex`` program parses the
list of unknown words after the application of dictionaries and tries to
analyze each of these words as a compound word. If a word has at least
one analysis as a compound word, it is removed from the list of unknown
words and the lines produced for this word are appended to the simple
word text dictionary.

Opening a tagged text
---------------------

A tagged text is a text containing words with lexical tags enclosed in
braces:

*I do not like the {square bracket,.N} sign! {S}*

Such tags can be used to avoid ambiguities. In the previous example, it
will be impossible to match *square bracket* as the combination of two
simple words.

However, the presence of these tags can alter the application of
preprocessing graphs. To avoid complications, you can use the “Open
Tagged Text...” command in the “Text” menu. With it, you can open a
tagged text and skip the application of preprocessing graphs, as shown
on Figure [preprocess-tagged-text].

.. figure:: resources/img/fig2-15.png
   :alt: Preprocessing a tagged text[preprocess-tagged-text]
   :width: 14.00000cm

   Preprocessing a tagged text[preprocess-tagged-text]

.. [1]
   Unitex also proposes to automatically convert graphs and dictionaries
   that are not in Unicode Little-Endian.

.. [2]
   From version 3.1beta, revision 4072, October 2, 2015.
