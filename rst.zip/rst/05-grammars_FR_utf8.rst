Grammaires locales
==================

Les grammaires locales sont un moyen puissant de représenter la plupart
des phéno- mènes linguistiques. La première section présentera le
formalisme sur lesquel ces grammaires reposent. Nous verrons ensuite
comment construire et présenter des grammaires avec Unitex.

Formalisme des grammaires locales
---------------------------------

Grammaires algébriques
~~~~~~~~~~~~~~~~~~~~~~

Les grammaires Unitex sont des variantes des grammaires algébriques,
également appelées grammaires hors-contexte. Une grammaire algébrique
est constituée de règles de réécriture. Voici une grammaire qui
reconnaît n’importe quel nombre de caractères :math:`a`:

:math:`S \rightarrow` :math:`aS`

:math:`S \rightarrow`

Les symboles figurant à gauche des règles sont appelés *symboles
non-terminaux* car ils peuvent être réécrits. Les symboles qui ne
peuvent pas être réécrits par des règles sont appelés *symboles
terminaux*. Les membres droits des règles sont des suites de symboles
non-terminaux et terminaux. Le symbole epsilon noté   désigne le mot
vide. Dans la grammaire ci-dessus, :math:`S` est un symbole non-terminal
et :math:`a` un terminal. :math:`S` peut se réécrire soit en un
:math:`a` suivi d’un :math:`S`, soit en mot vide. L’opération de
réécriture par l’application d’une règle est appelée *dérivation*. On
dit qu’une grammaire reconnaît un mot s’il existe une suite de
dérivations qui produit ce mot. Le non-terminal qui sert de point de
départ à la première dérivation est appelé *axiome*.

La grammaire ci-dessus reconnaît ainsi le mot *aa*, car on peut obtenir
ce mot depuis l’axiome :math:`S` en effectuant les dérivations
suivantes:

Dérivation 1: réécriture de l’axiome en :math:`aS`

:math:`\rightarrow aS`

Dérivation 2: réécriture du :math:`S` du membre droit en :math:`aS`

:math:`S` :math:`\rightarrow a` :math:`\rightarrow aaS`

Dérivation 3: réécriture du :math:`S` to

:math:`S` :math:`\rightarrow aS \rightarrow aa` :math:`\rightarrow aa`

On appelle *langage d’une grammaire* l’ensemble des mots reconnus par
celle-ci. Les langages reconnus par les grammaires algébriques sont
appelés *Languages algébriques* ou *Langages hors-contexte*.

Grammaires algébriques étendues
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Les grammaires algébriques étendues sont des grammaires algébriques où
les membres droits des règles ne sont plus des suites de symboles mais
des expressions rationnelles. Ainsi, la grammaire reconnaissant une
suite quelconque de :math:`a` peut se réécrire en une grammaire étendue
d’une seule règle:

:math:`S \rightarrow` :math:`a^{*}`

Ces grammaires, également appelées *réseaux de transitions récursifs*
(*RTN en Anglais*) ou *diagrammes de syntaxe*, se prêtent à une
représentation graphique conviviale. En effet, le membre droit d’une
règle peut être représenté par un graphe dont le nom est le membre
gauche de la règle.

Toutefois, les grammaires Unitex ne sont pas exactement des grammaires
algébriques étendues, car elles intégrent la notion de *transduction*.
Cette notion, empruntée aux automates à états finis, signifie qu’une
grammaire peut produire des sorties. Dans un souci de clarté, nous
utiliserons malgré tout les termes grammaire ou graphe. Quand une
grammaire produira des sorties, nous utiliserons le terme
*transducteur*, par extension de la définition d’un transducteur dans le
domaine des automates à états finis.

Édition de graphes
------------------

Création d’un graphe
~~~~~~~~~~~~~~~~~~~~

Pour créer un graphe, cliquez sur “New” dans le menu “FSGraph”
([fig-fsgraph-menu]).

.. figure:: resources/img/fig5-1.png
   :alt: Menu FSGraph[fig-fsgraph-menu]
   :width: 13.00000cm

   Menu FSGraph[fig-fsgraph-menu]

On voit alors apparaitre une fenêtre comme celle de la
figure [fig-new-graph].

.. figure:: resources/img/fig5-2.png
   :alt: Graphe vierge[fig-new-graph]
   :width: 14.50000cm

   Graphe vierge[fig-new-graph]

Pour pouvoir importer des graphes Intex dans Unitex, il faut les
convertir en Unicode. Le procédé de conversion est le même que pour les
textes (voir section [section-conversion-texte-unicode]).

Le symbole en forme de flèche est *l’état initial* du graphe. Le symbole
composé d’un rond contenant un carré est *l’état final* du graphe. La
grammaire reconnaît les séquences décrites par les chemins allant de
l’état initial à l’état final

Pour créer une boîte, cliquez sur la fenêtre tout en appuyant sur la
touche Ctrl. Vous verrez alors apparaître un carré bleu symbolisant la
boîte vide créée (voir figure  [fig-box-creation]). Lors de la création
d’une boîte, celle-ci est automatiquement sélectionnée.

.. figure:: resources/img/fig5-3.png
   :alt: Création d’une boîte[fig-box-creation]
   :width: 14.50000cm

   Création d’une boîte[fig-box-creation]

Le contenu de la boîte s’affiche dans la zone de texte située en haut de
la fenêtre (figure [fig-box-creation]). La boîte créée contient le
symbole ``<E>`` qui représente le mot vide epsilon. Remplacez ce symbole
par le texte ``I+you+he+she+it+we+they`` et validez en appuyant sur la
touche Entrée. Vous venez de créer une boîte contenant sept lignes (voir
figure [fig-pronoun-box]).

.. figure:: resources/img/fig5-4.png
   :alt: Boîte contenant ``I+you+he+she+it+we+they``\ [fig-pronoun-box]
   :width: 14.50000cm

   Boîte contenant ``I+you+he+she+it+we+they``\ [fig-pronoun-box]

En effet, le caractère ``+`` sert de séparateur. La boîte apparaît sous
la forme de lignes de texte rouge car elle n’est pour l’instant reliée à
aucune autre. On utilise souvent ce type de boîtes pour insérer des
commentaires dans un graphe.

Si vous souhaitez ajouter un commentaire dans un graphe, vous devez
créer une boîte qui commence par ``/``. Le texte de la boîte est affiché
en vert, et peut contenir des lignes vides. La boîte ne peut avoir, ni
de transition entrante, ni de transition sortante (voir
figure [comment-box]).

.. figure:: resources/img/fig5-4b.png
   :alt: Boîte contenant un commentaire[comment-box]
   :width: 12.50000cm

   Boîte contenant un commentaire[comment-box]

Pour relier une boîte à une autre, il faut cliquer sur la boîte de
départ, puis sur la boîte de destination. S’il y a déjà une transition
entre les deux boîtes, celle-ci est enlevée. Il est possible d’effectuer
cette même opération en cliquant d’abord sur la boîte de destination,
puis sur la boîte de départ tout en pressant sur la touche Shift. Dans
notre exemple, une fois la boîte reliée à l’état initial et à l’état
final du graphe, on obtient le graphe de la figure [fig-pronoun-graph]:

.. figure:: resources/img/fig5-5.png
   :alt: Graphe reconnaissant des pronoms anglais[fig-pronoun-graph]
   :width: 14.50000cm

   Graphe reconnaissant des pronoms anglais[fig-pronoun-graph]

REMARQUE: si vous double-cliquez sur une boîte, vous relierez cette
boîte à elle-même (voir figure [fig-loop-box]). Pour annuler,
double-cliquez une nouvelle fois sur la boîte.

.. figure:: resources/img/fig5-6.png
   :alt: Boîte reliée à elle-même[fig-loop-box]
   :width: 4.50000cm

   Boîte reliée à elle-même[fig-loop-box]

Cliquez sur “Save as...” dans le menu “FSGraph” pour enregistrer le
graphe. Par défaut, Unitex propose d’enregistrer le graphe dans le
sous-répertpoire ``Graphs`` de votre répertoire de travail. Vous pouvez
voir si le graphe a été modifié après le dernier enregistrement en
vérifiant si le titre du graphe contient le texte ``(Unsaved)``.

Un graphe peut contenir des boucles. Une boucle peut entourer une seule
boite, comme dans la fig. [fig-loop-box], ou plusieurs, comme dans la
fig. [multi-selection]. Le contenu de la boucle sera reconnu n’importe
quel nombre de fois en séquence. On peut fixer des limites au nombre de
fois, mais uniquement pour une boucle autour d’une seule boite: voir la
section [nb-repetitions].

Lorsqu’on modifie un graphe, on peut faire apparaître, par un clic
droit, un menu contextuel (fig. [contextual-menu]) qui permet
d’effectuer les opérations les plus usuelles :

.. figure:: resources/img/fig5-6b.png
   :alt: Menu contextuel[contextual-menu]
   :width: 7.50000cm

   Menu contextuel[contextual-menu]

-  créer une boîte

-  enregistrer ou imprimer le graphe courant ou modifier les paramètres
   de la page

-  les menus habituels “Tools”, “Format” et “Zoom” également accessibles
   dans le menu “FSGraph”

Si une ou plusieurs boîtes sont sélectionnées, les menus suivants
deviennent accessibles, et permettent d’effectuer plusieurs types
d’opérations sur cet ensemble de boîtes. Sinon, ils sont inutiles et
donc désactivés.

-  entourer les boîtes sélectionnées avec la définition d’une variable
   d’entrée ou de sortie, d’un contexte au sens de la
   section [section-contexts], ou des délimiteurs du mode morphologique.
   Ces opérations sont également réalisables avec la barre d’outils de
   la fenêtre d’édition du graphe (voir section [toolbar-commands]).

-  fusionner les boîtes sélectionnées

-  exporter les boîtes sélectionnées en tant que nouveau graphe

Sous-graphes
~~~~~~~~~~~~

Pour faire appel à un sous-graphe, il faut indiquer son nom dans une
boîte en le faisant précéder du caractère ``:``. Si vous entrez dans une
boîte le texte suivant:

``alpha+:beta+gamma+:E:\greek\delta.grf``

vous obtiendrez une boîte similaire à celle de la
figure [fig-subgraph-call].

.. figure:: resources/img/fig5-7.png
   :alt: Graphe faisant appel aux sous-graphes ``beta`` et
   ``delta``\ [fig-subgraph-call]
   :width: 6.00000cm

   Graphe faisant appel aux sous-graphes ``beta`` et
   ``delta``\ [fig-subgraph-call]

Vous pouvez indiquer le nom complet du graphe (``E:\greek\delta.grf``)
ou simplement le nom sans le chemin d’accès (``beta``); dans ce cas, le
sous-graphe est supposé se trouver dans le même répertoire que le graphe
qui y fait référence. Il est déconseillé d’utiliser des noms de graphes
comportant des chemins absolus, car cela nuit à leur portabilité. Si
vous utilisez un nom de graphe absolu, comme c’est ici le cas pour
``E:\greek\delta.grf`` le compilateur de graphe émettra un avertissement
(voir figure [fig-warning-absolute-graph-name]).

.. figure:: resources/img/fig5-8.png
   :alt: Avertissement pour un nom de graphe non
   portable[fig-warning-absolute-graph-name]
   :width: 14.50000cm

   Avertissement pour un nom de graphe non
   portable[fig-warning-absolute-graph-name]

Pour les mêmes raisons de portabilité, il est déconseillé d’utiliser
``\`` ou ``/`` comme séparateur dans les noms de graphes. À la place, il
vaut mieux utiliser le caractère ``:`` qui joue le rôle de séparateur
universel, valable quel que soit le système sous lequel vous travaillez.
On peut d’ailleurs voir sur la figure  [fig-warning-absolute-graph-name]
que c’est ce séparateur qui est utilisé en interne par le compilateur de
graphe (``E::greek:delta.grf``).

**Répertoire de dépôt** [section-repository]

Lorsqu’on souhaite réutiliser une grammaire :math:`X` dans une grammaire
:math:`Y`, une pratique répandue est de recopier tous les graphes de
:math:`X` dans le répertoire où se trouvent les graphes de :math:`Y`, ce
qui pose deux problèmes :

-  le nombre de graphes dans le répertoire devient vite très important ;

-  deux graphes ne peuvent pas avoir le même nom.

Afin d’éviter cela, il est possible de stocker la grammaire :math:`X`
dans un répertoire particulier, appelé *répertoire de dépôt*. Ce
répertoire est une sorte de bibliothèque dans laquelle on peut ranger
des graphes, et faire ensuite appel à ces graphes au moyen de ``::`` au
lieu de ``:``. Pour utiliser ce mécanisme, il faut tout d’abord définir
le répertoire de dépôt dans le menu “Info>Preferences...>Directories”
(voir figure [directories]). Choisissez votre répertoire dans le cadre
“Graph repository”. Le répertoire de dépôt est propre à la langue de
travail, vous n’êtes donc pas obligé d’utiliser le même répertoire pour
plusieurs langues.

.. figure:: resources/img/fig5-10.png
   :alt: Configuration du répertoire de dépôt[directories]
   :width: 8.00000cm

   Configuration du répertoire de dépôt[directories]

Supposons que l’on ait une arborescence comme celle de la figure
[repository]. Si l’on souhaite faire appel au graphe ``DET`` qui se
trouve dans le sous-répertoire ``Johnson``, on utilisera l’appel

``::Det:Johnson:DET`` (voir figure [repository-graph-call] [1]_).

.. figure:: resources/img/fig5-11.png
   :alt: Exemple de répertoire de dépôt[repository]
   :width: 3.90000cm

   Exemple de répertoire de dépôt[repository]

.. figure:: resources/img/fig5-12.png
   :alt: Appel un graphe du répertoire de dépôt[repository-graph-call]
   :width: 6.70000cm

   Appel un graphe du répertoire de dépôt[repository-graph-call]

ASTUCE: si vous voulez éviter de mettre dans vos graphes un chemin
compliqué comme ``::Det:Johnson:DET``, vous pouvez créer un graphe nommé
``DET`` que vous placerez à la racine du répertoire de dépôt
``D:\repository\DET.grf``). Ce graphe contiendra simplement un appel au
graphe ``::Det:Johnson:DET``. Vous pourrez alors mettre dans vos graphes
un simple appel à ``::DET``. Cela permet 1) de ne pas avoir de noms
compliqués et 2) de pouvoir modifier les graphes du répertoire de dépôt
sans avoir à modifier tous vos graphes. En effet, il vous suffira de
mettre à jour le graphe situé à la racine du répertoire de dépôt.

Les appels à des sous-graphes sont représentés dans les boîtes par des
lignes sur fond gris (figure [fig-subgraph-call]), ou kaki dans le cas
de sous-graphes à rechercher dans le répertoire de dépôt
(figure [repository-graph-call]). Si le fichier ``.grf`` du sous-graphe
n’est pas trouvé au chemin indiqué, Unitex cherchera le fichier
``.fst2`` de même nom. Si Unitex ne trouve ni le fichier ``.grf`` ni le
fichier ``.fst2``, l’appel au graphe manquant apparaît dans une ligne
sur fond rouge.

.. figure:: resources/img/fig5-9.png
   :alt: Les sous-graphes manquants apparaissent en rouge
   :width: 7.00000cm

   Les sous-graphes manquants apparaissent en rouge

Sous Windows, vous pouvez ouvrir un sous-graphe en cliquant sur la ligne
grisée tout en appuyant sur la touche Alt. Sous Linux, la combinaison
<Alt+Click> est interceptée par le système [2]_ : pour ouvrir un
sous-graphe, faites un clic central sur son nom (avec le bouton central)
ou faites un clic simultané (avec les boutons gauche et droit).

La liste des graphes appelés par le graphe courant et celle des graphes
qui appellent le graphe courant peuvent être affichées en cliquant sur
le second et troisième bouton du quatrième groupe de boutons de la barre
d’outils (figure [list-called-graphs] ; voir aussi figure [fig-toolbar],
section [toolbar-commands]). Dans ces listes de sous-graphes:

-  les sous-graphes directement appelés par le graphe courant
   apparaissent avec leur simple nom de fichier

-  les sous-graphes indirectement appelés par l’un des graphes appelés
   par le graphe courant apparaissent avec une flèche devant leurs nom

-  les sous-graphes qui apparaissent dans des graphes appelés par le
   graphe courant sans être connectés et donc non traités ont leur nom
   en orange

-  les sous-graphes non trouvés (ni en .grf ni en .fst2) apparaissent en
   rouge.

.. figure:: resources/img/fig5-12b.png
   :alt: Affichage de la liste de tous les graphes
   appelés[list-called-graphs]
   :width: 15.20000cm

   Affichage de la liste de tous les graphes appelés[list-called-graphs]

Manipulation des boîtes
~~~~~~~~~~~~~~~~~~~~~~~

Vous pouvez sélectionner plusieurs boîtes au moyen de la souris. Pour
cela, cliquez et déplacez la souris sans relâcher le bouton. Lorsque
vous relâcherez le bouton, toutes les boîtes touchées par le rectangle
de sélection seront sélectionnées et s’afficheront alors en blanc sur
fond bleu (figure [multi-selection]).

.. figure:: resources/img/fig5-13.png
   :alt: Sélection de plusieurs boîtes[multi-selection]
   :width: 10.00000cm

   Sélection de plusieurs boîtes[multi-selection]

Vous pouvez sélectionner plusieurs boîtes en maintenant les touches
<CTRL> et <SHIFT> et en cliquant sur chaque boîte à ajouter à la
sélection. De cette manière, vous pouvez sélectionner plusieurs boîtes
sans avoir à sélectionner une zone complète (figure [multi-selection2]).

.. figure:: resources/img/fig5-13b.png
   :alt: Sélection de boîtes éloignées[multi-selection2]
   :width: 10.00000cm

   Sélection de boîtes éloignées[multi-selection2]

Lorsque des boîtes sont sélectionnées, vous pouvez les déplacer en
cliquant et en déplaçant le curseur sans relâcher le bouton. Pour
annuler la sélection, cliquez sur une zone vide du graphe ; si vous
cliquez sur une boîte, toutes les boîtes de la sélection seront reliées
à celle-ci.

Vous pouvez effectuer un copier-coller sur plusieurs boîtes, comme dans
la figure [copy-paste-multi-selection]. Pour cela, sélectionnez-les et
appuyez sur <Ctrl+C> ou cliquez sur “Copy” dans le menu “Edit”. Votre
sélection multiple est maintenant dans le presse-papiers d’Unitex. Vous
pouvez alors coller cette sélection en pressant <Ctrl+V> ou en cliquant
sur “Paste” dans le menu “Edit”.

.. figure:: resources/img/fig5-14.png
   :alt: Copier-coller d’une sélection
   multiple[copy-paste-multi-selection]
   :width: 13.00000cm

   Copier-coller d’une sélection multiple[copy-paste-multi-selection]

NOTE: Vous pouvez coller une sélection multiple dans des graphes
différents de celui dont elle est issue.

Pour supprimer des boîtes, sélectionnez-les, effacez le texte qu’elles
contiennent (c’est-à-dire le texte affiché dans le champ situé en haut
de la fenêtre) et appuyez sur Enter.

On ne peut pas supprimer l’état initial ni l’état final.

Sortie
~~~~~~

Il est possible d’associer une sortie à une boîte. Pour cela, on utilise
le caractère spécial ``/``. Tous les caractères situés à droite de
celui-ci seront considérés comme faisant partie de la sortie. Ainsi, le
texte ``one+two+three/number`` donne la boîte de la figure
 [fig-exemple-transduction].

.. figure:: resources/img/fig5-15.png
   :alt: Exemple de sortie[fig-exemple-transduction]
   :width: 4.50000cm

   Exemple de sortie[fig-exemple-transduction]

Pour créer une boite vide avec une sortie contenant ``number``, on écrit
``<E>/number`` (exemple : la boite la plus à droite dans la
figure [fig-using-variable] est vide et a une sortie). La sortie
associée à une boîte est représentée en gras sous celle-ci.

**Poids**

On peut attribuer un poids à des boîtes d’un transducteur. Ainsi,
lorsqu’une séquence est reconnue par plusieurs chemins avec des sorties
différentes (transducteur ambigu), seul un chemin de poids maximal sera
conservé. Après un “Locate”, la concordance ne comportera qu’une seule
fois la séquence reconnue, et avec la sortie appropiée
(figure [fig-weights-in-graphs]).

.. figure:: resources/img/fig5-15b.png
   :alt: Poids dans les graphes [fig-weights-in-graphs]
   :width: 14.50000cm

   Poids dans les graphes [fig-weights-in-graphs]

Les poids sont des valeurs entières. Pour donner à une boite le poids 1,
on insère ``${1}$`` dans la sortie de la boite, comme dans
``<E>/${1}$``.

Le poids d’un chemin est le dernier poids trouvé en parcourant le
chemin. Un poids peut être nul, mais pas strictement négatif. Un chemin
qui a un poids, même nul, a la priorité sur un chemin sans poids.

Avec des poids, on peut définir une priorité entre des chemins qui
reconnaissent la même séquence. On ne peut pas définir une priorité
entre deux séquences dont une est incluse dans l’autre (cf.
section [section-configuration-recherche]), ni entre des séquences qui
se chevauchent (cf. section [section-priorite-gauche]).

Les poids ne sont valides qu’à l’intérieur du graphe, et non dans les
sous-graphes ni les graphes appelants.

Variables d’entrée
~~~~~~~~~~~~~~~~~~

Il est possible de sélectionner des parties du texte reconnu par une
grammaire au moyen de variables d’entrée. Pour associer une variable
d’entrée ``var1`` à une partie d’une grammaire, on utilise soit le
bouton avec les parenthèses rouges dans la barre d’icônes au-dessus du
graphe (section  [toolbar-commands]), soit les symboles spéciaux
``$var1(`` et ``$var1)``. (Ces symboles définissent respectivement le
début et la fin de la zone à mémoriser. Créez deux boîtes contenant
l’une ``$var1(`` et l’autre ``$var1)``. Ces boîtes ne doivent rien
contenir d’autre que le nom de la variable précédé de ``$`` et suivi
d’une parenthèse. Reliez ensuite ces boîtes à la zone de la grammaire
voulue.) Dans le graphe de la figure [fig-using-variable], on reconnaît
une séquence commençant par un nombre, que l’on stocke dans une variable
nommée ``var1``, suivi de ``dollar`` ou ``dollars``.

.. figure:: resources/img/fig5-16.png
   :alt: Utilisation d’une variable d’entrée
   ``var1``\ [fig-using-variable]
   :width: 13.50000cm

   Utilisation d’une variable d’entrée ``var1``\ [fig-using-variable]

Les noms de variables peuvent contenir des lettres latines non
accentuées, minuscules ou majuscules, ainsi que des chiffres et le
caractère ``_`` (underscore). Unitex fait la différence entre les
lettres minuscules et majuscules.

Quand une variable a ainsi été définie, on peut l’utiliser dans les
sorties en encadrant son nom avec le caractère ``$``. La grammaire de la
figure [fig-date-grammar] reconnaît une date formée d’un mois et d’une
année, et produit en sortie la même date, mais dans l’ordre année-mois.

Si on veut utiliser le caractère ``$`` en sortie d’une boîte, on doit le
redoubler, comme le montre la figure [fig-using-variable].

.. figure:: resources/img/fig5-17.png
   :alt: Interversion du mois et de l’année dans une
   date[fig-date-grammar]
   :width: 14.50000cm

   Interversion du mois et de l’année dans une date[fig-date-grammar]

Quand une boite redéfinit une variable qui avait déjà été définie, la
nouvelle valeur écrase l’ancienne. Ainsi, si la variable est définie
dans une boucle, la valeur de la variable juste après la boucle dépend
du dernier passage dans la boucle.

Par défaut ``Locate`` et ``LocateTfst`` considèrent que les variables
non définies sont vides. On peut modifier ce comportement (voir section
[section-advanced-search-options]). De plus, il est possible dans un
graphe d’interroger une variable pour savoir si elle a été initialisée
ou non (section [section-variables]).

Copie de listes
~~~~~~~~~~~~~~~

Il peut être pratique d’effectuer un copier-coller d’une liste de mots
ou d’expressions depuis un éditeur de texte vers une boîte dans un
graphe. Afin d’éviter de devoir copier manuellement chaque terme, Unitex
propose un mécanisme de copie de listes. Pour l’utili- ser, sélectionnez
votre liste dans votre éditeur de texte et copiez-la au moyen de
<Ctrl+C> ou de la fonction de copie intégrée à votre éditeur. Créez
ensuite une boîte dans votre graphe, et utilisez <Ctrl+V> ou la commande
“Paste” du menu “Edit” pour la coller dans la boîte. Vous verrez alors
apparaître la fenêtre de la
figure [fig-setting-contexts-for-multiple-copy].

.. figure:: resources/img/fig5-18.png
   :alt: Sélection de contexte pour la copie d’une
   liste[fig-setting-contexts-for-multiple-copy]
   :width: 7.00000cm

   Sélection de contexte pour la copie d’une
   liste[fig-setting-contexts-for-multiple-copy]

Cette fenêtre vous permet de définir les contextes gauche et droit qui
seront ajoutés automatiquement à chaque terme de la liste. Par défaut,
ces contextes sont vides. Si l’on applique les contextes ``<`` et
``.V>`` à la liste suivante:

*eat*

*sleep*

*drink*

*play*

*read*

on obtient la boîte de la figure [fig-multiple-copy].

.. figure:: resources/img/fig5-19.png
   :alt: Boîte obtenue par copie d’une liste avec ajout de
   contextes[fig-multiple-copy]
   :width: 6.70000cm

   Boîte obtenue par copie d’une liste avec ajout de
   contextes[fig-multiple-copy]

Symboles spéciaux
~~~~~~~~~~~~~~~~~

L’éditeur de graphes d’Unitex interprète de façon particulière les
symboles suivants:

``" + : / < > # \``

Le tableau  [tab-special-symbols] résume la signification pour Unitex de
ces symboles, ainsi que la ou les façons de reconnaître ces caractères
dans des textes.

+-----------------+--------------------------------------------------------------------------------------------------------------------------+---------------------+
| ``Caractère``   | ``Signification``                                                                                                        | ``Codage``          |
+=================+==========================================================================================================================+=====================+
| ``"``           | les guillemets délimitent des séquences qui ne doivent ni être interprétées par Unitex, ni subir de variantes de casse   | ``\"``              |
+-----------------+--------------------------------------------------------------------------------------------------------------------------+---------------------+
| ``+``           | ``+`` sépare les différentes lignes boîtes                                                                               | ``"+"``             |
+-----------------+--------------------------------------------------------------------------------------------------------------------------+---------------------+
| ``:``           | ``:`` sert à introduire à appel à un sous-graphe                                                                         | ``":"`` or ``\:``   |
+-----------------+--------------------------------------------------------------------------------------------------------------------------+---------------------+
| ``/``           | ``/`` indique le début de la sortie d’une boîte                                                                          | ``\/``              |
+-----------------+--------------------------------------------------------------------------------------------------------------------------+---------------------+
| ``<``           | ``<`` indique le début d’un motif ou d’un méta                                                                           | ``"<"`` or ``\<``   |
+-----------------+--------------------------------------------------------------------------------------------------------------------------+---------------------+
| ``>``           | ``>`` indique la fin d’un motif ou d’un méta                                                                             | ``">"`` or ``\>``   |
+-----------------+--------------------------------------------------------------------------------------------------------------------------+---------------------+
| ``#``           | ``#`` sert à interdire la présence de l’espace                                                                           | ``"#"``             |
+-----------------+--------------------------------------------------------------------------------------------------------------------------+---------------------+
| ``\``           | ``\`` sert à déspécialiser la plupart des caractères spéciaux                                                            | ``\\``              |
+-----------------+--------------------------------------------------------------------------------------------------------------------------+---------------------+

Table: Codage des symboles spéciaux dans l’éditeur de
graphes[tab-special-symbols]

Commandes de la barre d’icônes
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

[toolbar-commands]

La barre d’icônes présente au-dessus des graphes contient des raccourcis
vers certaines commandes et permet de manipuler les boîtes d’un graphe
en utilisant des “outils”. Cette barre d’icônes peut être déplacée en
cliquant sur la zone “rugueuse”. Elle peut même être dissociée du graphe
et apparaître alors comme une fenêtre séparée (voir
figure [fig-toolbar]). Dans ce cas, le fait de fermer cette fenêtre
replace la barre d’icônes à sa position initiale. Chaque graphe possède
sa propre barre d’icônes.

.. figure:: resources/img/fig5-20.png
   :alt: Barre d’outils[fig-toolbar]
   :width: 15.00000cm

   Barre d’outils[fig-toolbar]

Les deux premières icônes sont des raccourcis permettant de sauver et de
compiler le graphe. Les cinq suivantes correspondent aux opérations
“Copier”, “Couper”, “Coller”, “Redo” et “Undo”.

Les 6 icônes suivantes correspondent à des commandes d’édition des
boîtes. La première, en forme de flèche blanche, correspond au mode
d’édition normal des boîtes. Les 5 autres correspondent à des outils.
Pour utiliser un outil, cliquez sur l’icône correspondante : le curseur
de la souris changera alors de forme et les clics de la souris seront
alors interprétés de façon particulière. Voici la description des
outils, de gauche à droite:

-  création de boîtes: crée une boîte vide à l’endroit du clic;

-  suppression de boîtes: supprime la boîte sur laquelle vous cliquez;

-  relier des boîtes à une autre boîte: cet outil permet de sélectionner
   une ou plusieurs boîtes, et de la ou les relier à une autre. À la
   différence du mode normal, la ou les transitions qui vont être créées
   sont affichées pendant le déplacement du pointeur de la souris;

-  relier des boîtes à une autre boîte en sens inverse: cet outil
   effectue la même chose que le précédent, mais en reliant en sens
   inverse les boîtes sélectionnées à la boîte cliquée;

-  ouvrir un sous-graphe: ouvre un sous-graphe lorsque vous cliquez sur
   la ligne grisée correspondante dans une boîte.

Pour que le curseur retrouve sa forme initiale de flèche blanche, faites
un clic droit sur le fond du graphe : les clics seront à nouveau
interprétés normalement.

L’icône en forme de clé anglaise est un raccourci pour ouvrir la fenêtre
des options d’affichage du graphe. Les deux suivantes permettent de voir
les listes de graphes en relation avec le graphe courant:

-  Le premier bouton affiche la liste des graphes appelés par le graphe
   courant

-  Le deuxième bouton affiche la liste des graphes qui appellent le
   graphe courant

Le bouton muni de deux flèches vertes rafraîchit le graphe courant en
chargeant sa dernière version. Si un fichier ``.grf`` est modifié alors
que le graphe qu’il contient est affiché dans une fenêtre Unitex, une
fenêtre pop up vous invitera à le recharger.

Le bouton portant l’icône d’une balance permet de comparer le graphe
courant à un autre graphe ou à une autre version du même graphe. Une
nouvelle fenêtre est alors affichée (voir figure [Graph-DIFF]) qui
contient les deux graphes avec des couleurs qui indiquent les types de
différences entre les deux graphes : insertion, suppression, déplacement
de boîtes et changement de contenu d’une boîte apparaissent
respectivement en vert, rouge, mauve et jaune.

.. figure:: resources/img/DIFF.png
   :alt: DIFF[Graph-DIFF]
   :width: 15.60000cm

   DIFF[Graph-DIFF]

Les six derniers boutons sont des raccourcis pour la définition d’une
variable, du mode morphologique ou d’un contexte sur une ou plusieurs
boîtes sélectionnées. Ces boutons ne sont activés que si une ou
plusieurs boîtes sont sélectionnées:

-  : variable d’entrée (voir section [section-using-variables])

-  : variable de sortie (voir section [section-output-variables])

-  : mode morphologique (voir section [section-morphological-mode])

-  : contexte gauche (voir section [section-contexts])

-  : contexte droit (voir section [section-contexts])

-  : contexte droit négatif (voir section [section-contexts])

Options de présentation
-----------------------

Tri des lignes d’une boîte
~~~~~~~~~~~~~~~~~~~~~~~~~~

Vous pouvez trier le contenu d’une boîte en la sélectionnant et en
cliquant sur “Sort Node Label” dans le sous-menu “Tools” du menu
“FSGraph”. Ce tri ne fait pas appel au programme ``SortTxt``. Il s’agit
d’un tri basique qui trie les lignes de la boîte selon l’ordre des
caractères dans le codage Unicode.

Zoom
~~~~

Le sous-menu “Zoom” vous permet de choisir l’échelle à laquelle sera
affiché le graphe.

.. figure:: resources/img/fig5-21.png
   :alt: Sous-menu Zoom
   :width: 6.40000cm

   Sous-menu Zoom

L’option “Fit in screen” étire ou rétrécit le graphe pour lui donner la
taille de l’écran. L’option “Fit in window” ajuste le graphe pour qu’il
soit entièrement affiché dans la fenêtre.

Antialiasing
~~~~~~~~~~~~

L’antialiasing est un effet de rendu qui permet d’éviter l’effet de
pixellisation. Vous pouvez activer cet effet en cliquant sur
“Antialiasing...” dans le sous-menu “Format”. La
figure [fig-antialiasing] montre deux graphes affichés normalement
(graphe du haut) et avec antialiasing (graphe du bas).

.. figure:: resources/img/fig5-22.png
   :alt: Exemple d’antialiasing[fig-antialiasing]
   :width: 13.50000cm

   Exemple d’antialiasing[fig-antialiasing]

Cet effet ralentit l’exécution d’Unitex. Nous vous conseillons de ne pas
l’utiliser si votre machine est peu puissante.

Alignement des boîtes
~~~~~~~~~~~~~~~~~~~~~

Afin d’obtenir des graphes harmonieux, il est utile de pouvoir aligner
les boîtes, aussi bien horizontalement que verticalement. Pour cela,
sélectionnez les boîtes à aligner et cli- quez sur “Alignment...” dans
le sous-menu “Format” du menu “FSGraph” ou appuyez sur <Ctrl+M>. Vous
voyez alors apparaître la fenêtre de la figure [fig-alignment-frame].

Les possibilités d’alignement horizontal sont:

-  Top: les boîtes sont alignées sur la boîte la plus haute;

-  Center: les boîtes sont toutes centrées sur un même axe;

-  Bottom: les boîtes sont alignées sur la boîte la plus basse.

.. figure:: resources/img/fig5-23.png
   :alt: Fenêtre d’alignement[fig-alignment-frame]
   :width: 6.60000cm

   Fenêtre d’alignement[fig-alignment-frame]

Les possibilités d’alignement vertical sont:

-  Left: les boîtes sont alignées sur la boîte la plus à gauche;

-  Center: les boîtes sont toutes centrées sur un même axe;

-  Right: les boîtes sont alignées sur la boîte la plus à droite.

La figure  [fig-vertical-left-alignment] montre un exemple d’alignement.
Le groupe de boîtes situé à droite est une copie des boîtes de gauche
qui a été alignée verticalement à gauche.

.. figure:: resources/img/fig5-24.png
   :alt: Exemple d’alignement vertical
   gauche[fig-vertical-left-alignment]
   :width: 11.50000cm

   Exemple d’alignement vertical gauche[fig-vertical-left-alignment]

L’option “Use Grid” de la fenêtre d’alignement permet d’afficher une
grille en arrière-plan du graphe. Cela permet d’aligner
approximativement les boîtes.

.. figure:: resources/img/fig5-25.png
   :alt: Exemple d’utilisation d’une grille
   :width: 15.00000cm

   Exemple d’utilisation d’une grille

Présentation, polices et couleurs
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Vous pouvez configurer l’aspect d’un graphe en appuyant sur <Ctrl+R> ou
en cliquant sur “Presentation...” dans le sous-menu “Format” du menu
“FSGraph”, ce qui provoque l’af- fichage de la fenêtre de la
figure [fig-graph-display-configuration].

.. figure:: resources/img/fig5-26.png
   :alt: Configuration de l’aspect d’un
   graphe[fig-graph-display-configuration]
   :width: 9.00000cm

   Configuration de l’aspect d’un
   graphe[fig-graph-display-configuration]

Les paramètres de polices sont:

-  Input: police utilisée dans les boîtes, ainsi que dans la zone de
   texte où l’on édite le contenu des boîtes;

-  Output: police utilisée pour afficher les sorties des boîtes.

Les paramètres de couleur sont:

-  Background: couleur de fond;

-  Foreground: couleur utilisée pour le texte et le dessin des boîtes;

-  Auxiliary Nodes: couleur des boîtes faisant appel à des sous-graphes
   ;

-  Selected Nodes: couleur utilisée pour dessiner les boîtes quand elles
   sont sélectionnées ;

-  Comment Nodes: couleur utilisée pour dessiner les boîtes qui ne sont
   reliées à aucune autre.

Les autres paramètres sont:

-  Date: affichage de la date courante dans le coin inférieur gauche du
   graphe;

-  File Name: affichage du nom du graphe dans le coin inférieur gauche
   du graphe;

-  Pathname: affichage du nom du graphe avec son chemin complet dans le
   coin inférieur gauche du graphe. Cette option n’a d’effet que si
   l’option “File Name” est sélectionnée;

-  Frame: dessine un cadre autour du graphe;

-  Right to Left: inverse le sens de lecture du graphe (voir exemple de
   la figure [fig-right-to-left-graph]).

.. figure:: resources/img/fig5-27.png
   :alt: Graphe se lisant de droite à gauche[fig-right-to-left-graph]
   :width: 14.50000cm

   Graphe se lisant de droite à gauche[fig-right-to-left-graph]

Vous pouvez rétablir les paramètres par défaut en cliquant sur le bouton
“Default”. Si vous cliquez sur le bouton “OK”, seul le graphe courant
sera modifié. Pour modifier les préférences par défaut d’une langue,
cliquez sur “Preferences...” dans le menu “Info” et choisissez l’onglet
“Graph Presentation”.

Les graphes en dehors d’Unitex
------------------------------

Inclusion d’un graphe dans un document
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Pour inclure un graphe dans un document, il faut en faire une image.
Pour cela, une première méthode consiste à exporter votre graphe vers un
format d’image : PNG, JPEG ou SVG. Pour cela, allez dans le menu
“FSGraph” et cliquez sur “Export as image”. Choisissez ensuite le type
de fichier. Vous obtiendrez ainsi une image prête à être intégrée dans
un document ou à être éditée avec un logiciel de retouche d’images. Afin
de rendre l’image plus lisse, vous pouvez activer l’antialiasing pour le
graphe qui vous intéresse. Contraitement au JPEG, le format PNG utilise
une compression sans perte de qualité, donc le PNG donne toujours un
meilleurs résultat que le JPEG. Et contrairement au PNG et au JPEG, qui
sont des fomats bitmap, le format SVG est un format vectoriel, ce qui
permet souvent un meilleur résultat. A l’aide du logiciel Inkscape, il
est également possible de convertir le fichier SVG en EPS ou en PDF,
avec des lignes de commandes de ce type:

::

    Inkscape -z -E graph.eps graph.svg

::

    Inkscape -z -A graph.pdf graph.svg

La seconde méthode consiste à faire une capture d’écran:

Sous Windows:

Appuyez sur la touche “Imprime écran” de votre clavier qui doit se
trouver près de la touche F12. Lancez le programme ``Paint`` dans le
menu “Accessoires” de Windows. Appuyez sur <Ctrl+V>. ``Paint`` peut vous
dire que l’image contenue dans le presse-papiers est trop grande et vous
demander si vous voulez agrandir l’image. Cliquez sur “Oui”. Vous pouvez
maintenant éditer l’image de l’écran. Sélectionnez la zone qui vous
intéresse. Pour cela, passez en mode sélection en cliquant sur le
rectangle en pointillé qui se trouve dans le coin supérieur gauche de la
fenêtre. Vous pouvez maintenant sélectionner une zone de l’image avec la
souris. Une fois votre zone sélectionnée, appuyez sur <Ctrl+C>. Votre
sélection est maintenant dans le presse-papier, il ne vous reste plus
qu’à aller dans votre document et à appuyer sur <Ctrl+V> pour coller
votre image.

Sous Linux:

Effectuez une capture d’écran (par exemple avec le programme ``xv``).
Retaillez ensuite votre image avec un éditeur graphique (par exemple
``TheGimp``), et collez votre image dans votre document de la même façon
que sous Windows.

**Image vectorielle**

Si vous préférez une image vectorielle, vous pouvez exporter votre
graphe vers le format SVG, qui est utilisable avec des logiciels comme
Inkscape (:raw-latex:`\cite{Inkscape}`). Il permet d’obtenir des sorties
PostScript utilisables dans des documents LaTeX.

Impression d’un graphe
~~~~~~~~~~~~~~~~~~~~~~

Vous pouvez imprimer un graphe en cliquant sur “Print...” dans le menu
“FSGraph” ou en appuyant sur <Ctrl+P>.

ATTENTION: vous devez vous assurer que le paramètre d’orientation de
l’imprimante (portrait ou paysage) correspond bien à l’orientation de
votre graphe.

Vous pouvez définir vos préférences d’impression en cliquant sur “Page
Setup” dans le menu “FSGraph”. Vous pouvez également imprimer tous les
graphes qui sont ouverts en cliquant sur “Print All...”.

.. [1]
   Dans un souci de clarté, les appels à des graphes du répertoire de
   dépôt sont affichés sur fond kaki au lieu de gris.

.. [2]
   Si vous travaillez sous KDE, désactivez <Alt+Click> dans kcontrol.
