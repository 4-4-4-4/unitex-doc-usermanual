Installation d’Unitex
=====================

Unitex est un système multi-plateformes capable de fonctionner aussi
bien sous Windows que sous Linux ou OS X. Ce chapitre décrit
l’installation et le lancement d’Unitex pour chacun de ces systèmes. Il
présente également les procédures d’ajout de nouvelles langues et de
désinstallation.

Licences
--------

Unitex est un logiciel libre. Cela signifie que le code source des
programmes est distribué avec le logiciel, et que chacun peut le
modifier et le redistribuer. Le code des programmes d’Unitex est sous
licence LGPL (:raw-latex:`\cite{LGPL}`), à l’exception de :

#. la bibliothèque de manipulation d’expressions régulières TRE de Ville
   Laurikari (:raw-latex:`\cite{TRE}`), qui est sous une licence du
   genre des licences BSD à 2 clauses ;

#. la bibliothèque ``wingetopt`` de Todd Miller et de la Fondation
   NetBSD, également sous une licence du genre des licences BSD à 2
   clauses, plus permissive que la licence LPGL ;

#. l’analyseur syntaxique Xerces2 Java Parser, de l’Apache Software
   Foundation, sous licence Apache ;

#. la bibliothèque LibYAML de Kirill Simonov, qui est sous licence MIT,
   également plus permissive que la licence LGPL ;

#. la bibliothèque SVNKit de TMate Software, sous licence TMate.

La licence LGPL est plus permissive que la licence GPL, car elle permet
d’utiliser du code LGPL dans des logiciels non libres. Dans les deux
cas, le logiciel peut librement être utilisé et distribué.

Toutes les ressources linguistiques distribuées avec Unitex sont
soumises à la licence LGPLLR (:raw-latex:`\cite{LGPLLR}`).

Le texte complet des licences LGPL, BSD à 2 clauses, Apache, MIT, TMate
et LGPLLR se trouve dans les annexes à la fin de ce manuel.

Environnement d’exécution Java
------------------------------

Unitex est composé d’une interface graphique écrite en Java et de
programmes externes écrits en *C/C-.05em-.1em*. Ce mélange de langages
de programmation permet d’avoir une application rapide et portable sous
différents systèmes d’exploitation.

Afin de pouvoir utiliser l’interface graphique, il faut préalablement
installer un environnement d’exécution, communément appelé machine
virtuelle ou JRE (Java Runtime Environment).

Pour fonctionner en mode graphique, Unitex nécessite une version 1.6 (ou
plus récente) de Java. Si vous avez une version trop ancienne de Java,
Unitex se bloquera après que vous ayez choisi votre langue de travail.

Vous pouvez télécharger librement la machine virtuelle correspondant à
votre système d’exploitation sur le site de Sun Microsystems
(:raw-latex:`\cite{site-java}`) à l’adresse suivante :
http://java.sun.com.

Si vous travaillez sous Linux ou OS X, ou si vous utilisez une version
de Windows gérant des comptes personnels pour les utilisateurs, il vous
faudra demander à votre administrateur système d’installer Java.

Programme d’installation
------------------------

Le programme d’installation d’Unitex/GramLab peut être téléchargé depuis
cette page :

`\\UnitexURLLatestReleases <\UnitexURLLatestReleases>`__

Sous Windows
~~~~~~~~~~~~

Le nom du fichier téléchargé sera par exemple :

Ensuite, double-cliquez sur ce fichier et suivez les instructions
(fig. [fig-installer]). Il est recommandé de désinstaller toute version
existante avant d’en installer une nouvelle. Unitex/GramLab sera
installé dans un répertoire (dossier) situé de préférence dans le
répertoire ``Program Files``, et qui sera appelé dans ce manuel le
répertoire système Unitex.

.. figure:: resources/img/installer.png
   :alt: Programme d’installation sous Windows[fig-installer]
   :width: 13.00000cm

   Programme d’installation sous Windows[fig-installer]

Une fois l’installation terminée, une icône Unitex et une icône GramLab
apparaissent sur le bureau : double-cliquez dessus pour lancer Unitex ou
GramLab (voir [section-first-use]). (Si le programme d’installation n’a
pas créé ces icônes, ouvrez le répertoire Unitex système : il contient
plusieurs sous-répertoires, dont un est ``App``. Ce dernier répertoire
contient deux fichiers ``Unitex.jar`` et ``GramLab.jar``. Ce sont les
fichiers Java qui lancent les interfaces graphiques. Double-cliquez sur
l’un d’entre eux pour lancer Unitex ou GramLab
(voir [section-first-use]). Pour faciliter le lancement du programme, il
est conseillé de créer des raccourcis vers ces fichiers sur le bureau.)

Si vous désirez installer Unitex sur une machine Windows
multi-utilisateurs, il est préférable de demander à votre administrateur
de le faire. Si vous êtes le seul utilisateur de votre machine, vous
pouvez effectuer l’installation vous-même.

Le programme d’installation sous Windows peut aussi être lancé en ligne
de commande et dans ce cas il accepte plusieurs paramètres optionnels.
En voici quelques-uns :

-  ``/AllUsers``

   | Par défaut i’installation vaudra pour tous les utilisateurs

-  ``/CurrentUser``

   | Par défaut i’installation vaudra pour l’utilisateur seulement

-  ``/D C:\path\without quotes\``

   | Spécifie le répertoire d’installation par défaut

-  ``/NCRC``

   | Saute le contrôle de redondance cyclique

-  ``/S``

   Supprime toutes les questions

Sous Windows 7, on peut avoir des problèmes avec le fichier de
configuration d’Unitex, car Unitex essaie de le créer dans le
sous-répertoire Unitex et Windows 7 le lui interdit.

Sous GNU/Linux et OS X
~~~~~~~~~~~~~~~~~~~~~~

Le nom du fichier téléchargé sera par exemple :

Donnez-lui les droits d’exécution, par exemple par :

chmod a+x

Le fichier ``.run`` est une archive qu’on décompresse en l’exécutant :

./

Le fichier d’installation sous GNU/Linux et OS X accepte plusieurs
paramètres de ligne de commande optionnels. En voici quelques-uns :

-  ``--confirm``

   | Demander avant de lancer le script d’installation

-  ``--quiet``

   | N’afficher que les messages d’erreur

-  ``--noexec``

   | Ne pas lancer le script d’installation

-  ``--target dir``

   Spécifier le répertoire d’installation par défaut

Installation manuelle
---------------------

On peut aussi installer Unitex/GramLab manuellement à l’aide du paquet
de distribution. Téléchargez-le depuis cette page :

`\\UnitexURLLatestReleases/source <\UnitexURLLatestReleases/source>`__

Le nom du fichier téléchargé sera par exemple :

Créez un répertoire que vous nommez par exemple Unitex, de préférence
dans le répertoire ``Program Files``, et qui sera appelé dans ce manuel
le répertoire système Unitex. Décompressez-y le paquet de distribution.

Si votre ordinateur est sous un des systèmes d’exploitation suivants,
l’installation est terminée : Windows (32 bits ou 64 bits), GNU/Linux
(i686 ou x86\_64) et OS X (10.7+). (S’il fonctionne sous un autre
système Unix, comme FreeBSD, ou s’il a une autre architecture de
processeur, comme ARM, allez dans le répertoire ``App/install`` et
lancez :

``sh setup``

Ce script vérifie si Java est installé, compile les sources C++, crée
les répertoires personnels de travail Unitex et GramLab et met en place
des raccourcis sur le bureau [1]_.)

Une fois l’installation terminée, le répertoire système Unitex contient
plusieurs sous-répertoires dont un est ``App``.

-  Sous Windows : ``App`` contient des fichiers ``Unitex.jar`` et
   ``GramLab.jar``. Ce sont les fichiers Java qui lancent les interfaces
   graphiques. Double-cliquez sur l’un d’entre eux pour lancer Unitex ou
   GramLab (voir [section-first-use]). Pour faciliter le lancement du
   programme, il est conseillé de créer des raccourcis vers ces fichiers
   sur le bureau.

-  Sous Linux ou OS X: le répertoire ``App`` contient deux scripts shell
   ``Unitex`` et ``GramLab``. Lancez l’un d’entre eux pour démarrer
   Unitex or GramLab (voir [section-first-use]). Si vous avez lancé le
   script d’installation, il a normalement fait apparaitre sur le bureau
   des raccourcis vers ces fichiers.

Première utilisation
--------------------

Si vous travaillez sous Windows, le programme vous demandera de choisir
un répertoire personnel de travail , que vous pourrez changer
ultérieurement dans “Info>Preferences...>Di-rectories”. Pour créer un
répertoire, cliquez sur l’icône représentant un dossier (voir
figure [fig-creation-personal-directory]).

Sous Linux et OS X, le programme créera automatiquement un répertoire
personnel de travail, appelé ``/unitex``, dans votre répertoire
``$HOME``.

Le répertoire personnel de travail, ou répertoire de l’utilisateur, vous
permettra de stocker vos données Unitex personnelles. Pour chaque langue
que vous utiliserez, le programme copiera l’arborescence de la langue
dans votre répertoire de travail, à l’exception des dictionnaires. Vous
pourrez ainsi modifier à votre guise votre copie des données sans
risquer d’endommager les données du système, stockées dans le répertoire
système Unitex.

.. figure:: resources/img/fig1-1.png
   :alt: Première utilisation sous Windows
   :width: 6.30000cm

   Première utilisation sous Windows

.. figure:: resources/img/fig1-2.png
   :alt: Première utilisation sous Linux
   :width: 7.00000cm

   Première utilisation sous Linux

.. figure:: resources/img/fig1-3.png
   :alt: Création du répertoire personnel de travail
   [fig-creation-personal-directory]
   :width: 13.00000cm

   Création du répertoire personnel de travail
   [fig-creation-personal-directory]

Ajout de nouvelles langues
--------------------------

Il y a deux manières d’ajouter des langues. Si vous désirez ajouter une
nouvelle langue accessible à tous les utilisateurs, il vous faut copier
le répertoire correspondant à cette langue dans le répertoire système
Unitex, ce qui nécessite d’avoir les droits d’accès à ce répertoire (il
vous faudra peut-être demander à votre administrateur système de le
faire). En revanche, si vous êtes le seul utilisateur concerné par la
langue, vous pouvez copier le répertoire en question dans votre
répertoire de travail. Vous pourrez ainsi travailler sur cette langue
sans qu’elle soit proposée aux autres utilisateurs.

Désinstallation
---------------

Quel que soit le système sous lequel vous travaillez, il vous suffit de
supprimer le répertoire ``Unitex`` pour effacer tous les fichiers du
système. Sous Windows, vous devrez ensuite supprimer le raccourci vers
``Unitex.jar`` si vous en avez créé un ; même chose sous Linux ou OS X
si vous avez créé un alias.

Unitex pour les développeurs
----------------------------

Si vous êtes programmeur, cela peut vous intéresser de lier votre code
avec les sources C++ d’Unitex. Pour faciliter cette opération, vous
pouvez compiler Unitex en tant que bibliothèque dynamique qui contient
toutes les fonctions Unitex, sauf les ``main``\ s, bien sûr. La page
http://docs.unitexgramlab.org/projects/unitex-library/fr/latest/ est une
documentation sur la bibliothèque. Les sources C++ d’Unitex contiennent
du code pour des bindings Java JNI, Ruby et Microsoft .NET. La page
https://github.com/patwat/python-unitex contient des bindings Python.

Sous Linux/OS X, tapez :

``make LIBRARY=yes``

et vous obtiendrez une bibliothèque nommée ``libunitex.so``. Si vous
souhaitez produire DLL Windows nommée ``unitex.dll``, utilisez les
commandes suivantes:

Windows: ``make SYSTEM=windows LIBRARY=yes``

Cross-compilation avec mingw32: ``make SYSTEM=mingw32 LIBRARY=yes``

dans tous les cas, vous obtiendrez aussi un programme nommé
``Test_lib``\ (``.exe``). Si tout a bien fonctionné, ce programme
devrait afficher l’écran suivant:

::

    Expression converted.
    Reg2Grf exit code: 0

    #Unigraph
    SIZE 1313 950
    FONT Times New Roman:  12
    OFONT Times New Roman:B 12
    BCOLOR 16777215
    FCOLOR 0
    ACOLOR 12632256
    SCOLOR 16711680
    CCOLOR 255
    DBOXES y
    DFRAME y
    DDATE y
    DFILE y
    DDIR y
    DRIG n
    DRST n
    FITS 100
    PORIENT L
    #
    7
    "<E>" 100 100 1 5
    "" 100 100 0
    "a" 100 100 1 6
    "b" 100 100 1 4
    "c" 100 100 1 6
    "<E>" 100 100 2 2 3
    "<E>" 100 100 1 1

.. [1]
   Si vous voulez uniquement compiler les sources C++, extrayez les
   fichiers du paquet de distribution, placez-vous dans le répertoire
   Src/C++/build et lancez make install.
