 

**Unitex**

**Manuel d’utilisation**

|image|

Université Paris-Est Marne-la-Vallée

http://www-igm.univ-mlv.fr/~unitex

``unitex-devel@univ-mlv.fr``

Sébastien Paumier

| La version française de 2013 a été réalisée par Claude Martineau à
  partir
| de la version 1.2 en français (2006) et de la version 3.1 bêta en
  anglais
| (quatre nouveaux chapitres et de nombreux ajouts dans les chapitres
  préexistants).

Date de cette version :

.. |image| image:: resources/img/logo-Unitex.png
   :width: 4.00000cm
