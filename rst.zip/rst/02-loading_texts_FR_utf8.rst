Chargement d’un texte
=====================

Une des principales fonctionnalités d’Unitex est la recherche
d’expressions dans des textes. Pour cela, les textes doivent subir
plusieurs opérations de prétraitement telles que la normalisation de
formes non ambiguës et le découpage du texte en phrases. Une fois ces
opérations effectuées, des dictionnaires électroniques sont appliqués
aux textes. On peut alors effectuer des recherches sur ces textes en
leur appliquant des grammaires.

Ce chapitre décrit les différentes étapes du prétraitement des textes.

Sélection de la langue
----------------------

Lors du lancement d’Unitex, le programme vous demande de choisir la
langue dans laquelle vous allez travailler (voir
figure [fig-language-selection]). Les langues proposées sont celles qui
sont présentes dans le répertoire système Unitex ainsi que celles
éventuellement installées dans votre répertoire de travail. Si vous
utilisez une langue pour la première fois, Unitex recopie le répertoire
système de cette langue dans votre répertoire de travail, à l’exception
des dictionnaires, afin d’économiser de l’espace disque.

Attention, si vous avez déjà un répertoire de travail pour une langue
donnée, Unitex n’essaiera pas de recopier les données système dedans.
Ainsi, si une mise à jour a modifié un fichier de ressource autre qu’un
dictionnaire, il vous faudra soit faire une mise à jour manuelle du
fichier dans votre répertoire de travail, soit supprimer votre
répertoire pour la langue concernée et laisser à Unitex le soin de le
recréer.

Le choix de la langue permet d’indiquer à Unitex où trouver certaines
données, comme par exemple le fichier alphabet. Vous pouvez à tout
moment changer de langue en cliquant sur “Change Language...” dans le
menu “Text”. Si vous changez de langue, le programme fermera, s’il y en
a, toutes les fenêtres relatives au texte courant. La langue courante
est indiquée sur la barre de titre de l’interface graphique.

.. figure:: resources/img/fig2-1.png
   :alt: [fig-language-selection]Sélection de la langue au lancement
   d’Unitex
   :width: 6.20000cm

   [fig-language-selection]Sélection de la langue au lancement d’Unitex

Format des textes
-----------------

Unitex manipule des textes Unicode. Unicode est un standard qui décrit
un codage universel des caractères. Chaque caractère se voit attribuer
un numéro unique, ce qui permet de représenter des textes sans avoir à
tenir compte des codages propres aux différentes machines et/ou systèmes
d’exploitation. Unitex utilise une représentation codée sur deux octets
du standard Unicode 3.0, appelée Unicode Little-Endian (pour plus de
détails, voir :raw-latex:`\cite{UNICODE}`).

Les textes fournis avec Unitex sont déjà au format Unicode. Si vous
essayez d’ouvrir un texte qui n’est pas au format Unicode, le programme
vous proposera de le convertir automatiquement (voir
figure [auto-transcoding]). Cette conversion se base sur la langue
courante : si vous travaillez en français, Unitex vous proposera de
convertir votre texte [1]_, en supposant qu’il est codé avec un codage
français. Par défaut, Unitex vous propose soit de remplacer le texte
original, soit de renommer le fichier d’origine en insérant ``.old`` au
début de son extension. Par exemple, si un fichier ASCII est nommé
``biniou.txt``, le processus de conversion va créer une copie de ce
fichier ASCII nommée ``biniou.old.txt``, et va remplacer le contenu de
``biniou.txt`` par son équivalent en Unicode.

.. figure:: resources/img/fig2-2.png
   :alt: [auto-transcoding]Conversion automatique d’un texte non Unicode
   :width: 10.00000cm

   [auto-transcoding]Conversion automatique d’un texte non Unicode

Si le codage proposé par défaut n’est pas le bon, ou si vous voulez
renommer le fichier autrement qu’avec le suffixe ``.old``,vous pouvez
utiliser la commande “Transcode Files” dans le menu “File Edition”.
Cette commande vous permet de choisir les codages d’origine et de
destination des documents à convertir (voir figure [transcoding]). Par
défaut, le codage source proposé est celui qui correspond à la langue
courante, et le codage de destination est Unicode Little-Endian. Vous
pouvez modifier ces choix, en sélectionnant n’importe quels codages de
source et destination. Ainsi, vous pouvez si vous le souhaitez convertir
vos données dans d’autres codages, comme par exemple UTF-8 si vous
voulez en faire des pages web. Le bouton “Add Files” vous permet de
sélectionner les fichiers à convertir. Le bouton “Remove Files” permet
de retirer de la liste des fichiers sélectionnés par erreur. Le bouton
“Transcode” lancera la conversion de tous les fichiers. Si une erreur
survient lors du traitement d’un fichier (par exemple, un fichier qui
serait déjà en Unicode), le traitement continue avec le fichier suivant.

.. figure:: resources/img/fig2-3.png
   :alt: [transcoding]Conversion de fichiers
   :width: 12.00000cm

   [transcoding]Conversion de fichiers

Pour obtenir du texte au bon format, vous pouvez également utiliser un
traitement de texte comme le logiciel libre OpenOffice.org
(:raw-latex:`\cite{OpenOffice}`) ou Microsoft Word, et sauvegarder votre
document au format “Texte unicode”. Dans OpenOffice Writer, vous devez
choisir le format “Coded Text (\*.txt)” puis le codage “Unicode” dans la
fenêtre de configuration comme le montre la figure [OfficeWriter].

.. figure:: resources/img/fig2-4.png
   :alt: [OfficeWriter]Sauvegarde en Unicode dans OpenOffice Writer
   :width: 12.50000cm

   [OfficeWriter]Sauvegarde en Unicode dans OpenOffice Writer

Par défaut, le codage proposé sur un PC est toujours Unicode
Little-Endian. Les textes ainsi obtenus ne contiennent plus
d’informations de formatage (police, couleurs, etc.) et sont prêts à
être utilisés avec Unitex.

Vous pouvez choisir le codage par défaut, UTF16LE, UTF16BE ou UTF8 dans
l’onglet, “Encoding” grâce au sous-menu “Preference” dans le menu
“Info”. Ce codage n’est valide que pour la langue courante.

.. figure:: resources/img/fig2-5.png
   :alt: Choix de l’encodage par défaut pour la langue courante
   :width: 10.00000cm

   Choix de l’encodage par défaut pour la langue courante

Édition de textes
-----------------

Vous avez également la possibilité d’utiliser l’éditeur de texte intégré
à Unitex, accessible via la commande “Open...” du menu “File Edition”.
Cet éditeur vous propose des fonctionnalités de recherche et
remplacement propres aux textes et dictionnaires manipulés par Unitex.
Pour y accéder, cliquez sur l’icône “Find” (jumelles). Vous verrez alors
apparaître une fenêtre divisée en trois onglets. L’onglet “Find”
correspond aux opérations de recherche habituelles. Si vous ouvrez un
texte découpé en phrases, vous aurez la possibilité de faire une
recherche par numéro de phrase dans l’onglet “Find Sentence”. Enfin,
l’onglet “Dictionary Search”, visible sur la figure [dictionary-search],
vous permet d’effectuer des opérations propres aux dictionnaires
électroniques. En particulier, vous pouvez effectuer une recherche en
spécifiant si elle doit porter sur la forme fléchie, le lemme, les codes
grammaticaux et sémantiques et/ou les codes flexionnels. Ainsi, si vous
voulez rechercher tous les verbes qui ont le trait sémantique ``t``,
marquant la transitivité, il vous suffit de chercher ``t`` en cochant
“Grammatical code”. Vous obtiendrez ainsi les entrées voulues, sans
ambiguïtés avec toutes les autres occurrences de la lettre ``t``.

.. figure:: resources/img/fig2-6.png
   :alt: Recherche du trait sémantique ``t``\ dans un dictionnaire
   électronique[dictionary-search]
   :width: 15.00000cm

   Recherche du trait sémantique ``t``\ dans un dictionnaire
   électronique[dictionary-search]

Ouverture d’un texte
--------------------

Unitex propose d’ouvrir deux types de fichiers textes. Les fichiers
portant l’extension ``.snt`` sont des fichiers textes prétraités par
Unitex qui sont prêts à être manipulés par les différentes fonctions du
système. Les fichiers portant l’extension ``.txt`` sont des fichiers
bruts. Pour utiliser un texte, il faut donc commencer par ouvrir le
fichier ``.txt`` correspondant en cliquant sur “Open...” dans le menu
“Text”.

.. figure:: resources/img/fig2-7.png
   :alt: Menu Text
   :width: 14.00000cm

   Menu Text

.. figure:: resources/img/fig2-8.png
   :alt: Ouverture d’un texte Unicode
   :width: 13.00000cm

   Ouverture d’un texte Unicode

Prétraitement du texte
----------------------

Une fois le texte sélectionné, Unitex vous propose de le prétraiter. Le
prétraitement du texte consiste à lui appliquer les opérations suivantes
: normalisation des séparateurs, découpage en unités lexicales,
normalisation de formes non ambiguës, découpage en phrases et
application des dictionnaires. Si vous refusez le prétraitement, le
texte sera néanmoins normalisé et découpé en unités lexicales, car ces
opérations sont indispensables au fonctionnement d’Unitex. Il vous sera
toujours possible d’effectuer le prétraitement plus tard, en cliquant
sur “Preprocess text...” dans le menu “Text”.

.. figure:: resources/img/fig2-9.png
   :alt: Fenêtre de prétraitement[fig-preprocessing-frame]
   :width: 15.00000cm

   Fenêtre de prétraitement[fig-preprocessing-frame]

Si vous acceptez le prétraitement, Unitex vous proposera de le
paramétrer grâce à la fenêtre de la figure [fig-preprocessing-frame].
L’option “Apply FST2 in MERGE mode” sert à effectuer le découpage du
texte en phrases. L’option “Apply FST2 in REPLACE mode” est utilisée
pour effectuer des remplacements dans le texte, le plus souvent des
normalisations de formes non ambiguës. L’option “Apply All default
Dictionaries” permet d’appliquer au texte des dictionnaires au format
DELA (Dictionnaires Electroniques du LADL). L’option “Analyse unknown
words as free compound words” est utilisée en norvégien pour analyser
correctement les mots composés libres formés par soudure de mots
simples. Enfin, l’option “Construct Text Automaton” est utilisée pour
construire l’automate du texte. Cette option est désactivée par défaut,
car elle entraîne une forte consommation de mémoire et d’espace disque
si le texte est trop volumineux. La construction de l’automate du texte
sera abordée dans le chapitre [chap-text-automaton].

NOTE: si vous cliquez sur “Cancel but tokenize text”, le programme
effectuera malgré tout la normalisation des séparateurs et le découpage
en unités lexicales ; cliquez sur “Cancel and close text” pour annuler
complètement l’opération.

Normalisation des séparateurs
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Les séparateurs usuels sont l’espace, la tabulation et le retour à la
ligne. On peut rencontrer plusieurs séparateurs consécutifs dans des
textes, mais comme cela n’est d’aucune utilité pour une analyse
linguistique, on normalise ces séparateurs selon les règles suivantes:

-  toute suite de séparateurs contenant au moins un retour à la ligne
   est remplacée par un unique retour à la ligne

-  toute autre suite de séparateurs est remplacée par un espace.

La distinction entre espace et retour à la ligne est conservée à cette
étape car la présence de retours à la ligne peut intervenir dans le
découpage du texte en phrases. Le résultat de la normalisation d’un
fichier appelé ``mon_texte.txt`` est un fichier situé dans le même
répertoire que le ``.txt`` et dont le nom est ``mon_texte.snt``.

NOTE : lorsque l’on prétraite un texte depuis l’interface graphique, un
répertoire nommé

``mon_texte.snt`` est créé immédiatement après la normalisation. Ce
répertoire, appelé répertoire du texte, contiendra toutes les données
relatives à ce texte.

Découpage en phrases
~~~~~~~~~~~~~~~~~~~~

Le découpage en phrases est une étape importante du prétraitement car
elle va permettre de définir des unités de traitement linguistique. Ce
découpage sera utilisé par le programme de construction de l’automate du
texte. Contrairement à ce que l’on pourrait penser, la re- cherche des
limites de phrases n’est pas un problème trivial. Considérons le texte
suivant :

*La famille a appelé le Dr. Martin en urgence.*

Le point qui suit *Dr* est suivi d’un mot commençant par une majuscule;
il pourrait donc être considéré comme un point de fin de phrase, ce qui
serait faux. Afin d’éviter les problèmes de ce genre, dus à des
ambiguïtés des symboles de ponctuation, on utilise des grammaires qui
décrivent les différents contextes où peuvent apparaître les limites de
phrases. La figure [fig-example-sentence-splitting] montre un exemple de
grammaire de découpage en phrases.

.. figure:: resources/img/fig2-10.pdf
   :alt: Grammaire de découpage en phrases pour le français
   [fig-example-sentence-splitting]
   :width: 15.00000cm

   Grammaire de découpage en phrases pour le français
   [fig-example-sentence-splitting]

Lorsqu’un chemin de la grammaire reconnaît une séquence dans le texte et
que ce chemin produit le symbole délimiteur de phrases ``{S}``, on
insère ce symbole dans le texte. Ainsi, un chemin de la grammaire de la
figure [fig-example-sentence-splitting] reconnaît la séquence composée
d’un point d’interrogation et d’un mot commençant par une majuscule et
insère le symbole ``{S}`` entre le point d’interrogation et le mot
suivant. Le texte suivant :

*Quelle heure est-il ? Huit heures.*

deviendrait donc :

*Quelle heure est-il ?{S} Huit heures.*

Une grammaire de découpage peut manipuler les symboles spéciaux, ou
méta-symboles, suivants :

-  ``<E>`` : mot vide, ou epsilon. Reconnaît la séquence vide ;

-  ``<WORD>`` : reconnaît n’importe quelle suite de lettres ;

-  ``<LOWER>`` : reconnaît n’importe quelle suite de lettres
   minuscules ;

-  ``<UPPER>`` : reconnaît n’importe quelle suite de lettres
   majuscules ;

-  ``<FIRST>`` : reconnaît n’importe quelle suite de lettres commençant
   par une majuscule ;

-  ``<NB>`` : reconnaît n’importe quelle suite de chiffres contigus
   (1234 est reconnu mais pas 1 234) ;

-  ``<PNC>`` : reconnaît les symboles de ponctuation ; , ! ? : ainsi que
   les points d’exclamation et d’interrogation inversés de l’espagnol et
   quelques signes de ponctuation asiatiques ;

-  <``^``> : reconnaît un retour à la ligne ;

-  ``#`` : interdit la présence de l’espace.

Les anciens codes correspondant à ``<WORD>``, ``<LOWER>``, ``<UPPER>``
et ``<FIRST>`` étaient respectivement ``<MOT>``, ``<MIN>``, ``<MAJ>`` et
``<PRE>``. Ils restent opérationnels afin de conserver la compatibilité
descendante du système avec les graphes existants. Même s’il n’est pas
prévu de supprimer ces codes, on recommande de les éviter dans les
graphes conçus pour fonctionner avec les versions plus récentes [2]_,
pour ne pas faire augmenter inutilement le nombre de masques lexicaux en
usage.

Par défaut, l’espace est facultatif entre deux boîtes. Si l’on veut
interdire la présence de ce séparateur, il faut utiliser le symbole
spécial ``#``. À l’inverse, si vous souhaitez forcer la présence de
l’espace, vous devez utiliser la séquence ``" "``. Les lettres
minuscules et majuscules sont définies par un fichier alphabet (voir
chapitre [chap-file-formats]). Pour plus de détails sur les graphes,
voir le chapitre [chap-grammars]. Pour plus de détails sur le découpage
d’un texte en phrases, voir
:raw-latex:`\cite{ameliorer-decoupage-en-phrases}`. La grammaire
utilisée se nomme ``Sentence.fst2`` et se trouve dans le répertoire
suivant :

``/(répertoire personnel)/(langue)/Graphs/Preprocessing/Sentence``

L’application de cette grammaire à un texte s’effectue grâce au
programme ``Fst2Txt`` en mode MERGE. Cela signifie que les sorties
produites par la grammaire, en l’occurrence le symbole ``{S}``, sont
insérées dans le texte. Ce programme prend en entrée un fichier ``.snt``
et le modifie.

Normalisation de formes non ambiguës
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

Certaines formes présentes dans les textes peuvent être normalisées (par
exemple, la séquence française “*l’on*” est équivalente à la forme
“*on*”). Chaque utilisateur peut donc vouloir effectuer des
remplacements en fonction de ses besoins. Toutefois, il faut faire
attention à ce que les formes normalisées soient non ambiguës, ou à ce
que la disparition de l’ambiguïté soit sans conséquence pour
l’application recherchée.

Si l’on décide de remplacer la forme “*audit*” par “*à le-dit*”, la
phrase :

*La cour a procédé à un audit des comptes de cette société.*

sera remplacée par la phrase incorrecte :

*La cour a procédé à un à le-dit des comptes de cette société.*

Il faut donc être très prudent lorsque l’on manipule la grammaire de
normalisation. Il faut également faire attention aux espaces. En effet,
si l’on remplace “*c’*” par “*ce*” non suivi par un espace, la phrase :

*Est-ce que c’était toi ?*

sera remplacée par la séquence incorrecte :

*Est-ce que ce était toi ?*

Les symboles acceptés par les grammaires de normalisation sont les mêmes
que ceux autorisés dans les grammaires de découpage en phrases. La
grammaire utilisée se nomme ``Replace.fst2`` et se trouve dans le
répertoire suivant :

``/(répertoire personnel)/(langue)/Graphs/Preprocessing/Replace``

Comme pour le découpage en phrases, cette grammaire est utilisée avec le
programme ``Fst2Txt`` , mais cette fois en mode REPLACE, ce qui signifie
que les entrées reconnues par la grammaire sont remplacées par les
séquences produites par celle-ci. On peut voir sur la
figure [fig-normalization-grammar] une grammaire qui normalise des
contractions verbales en anglais.

.. figure:: resources/img/fig2-11.pdf
   :alt: Grammaire de normalisation de formes verbales en
   anglais[fig-normalization-grammar]
   :height: 17.00000cm

   Grammaire de normalisation de formes verbales en
   anglais[fig-normalization-grammar]

Découpage du texte en unités lexicales
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

[tokenization] Certaines langues, en particulier les langues asiatiques,
utilisent les séparateurs de façon différente des langues occidentales ;
les espaces peuvent être interdits, facultatifs ou obligatoires. Pour
pouvoir gérer ces particularités au mieux, Unitex découpe les textes
d’une manière dépendante de la langue. Ainsi, les langues comme le
français sont traitées selon le principe suivant :

Une unité lexicale peut être :

-  soit le délimiteur de phrases ``{S}``;

-  le marqueur ``{STOP}``. Contrairement au délimiteur de phrases
   ``{S}``, le marqueur ``{STOP}`` ne peut JAMAIS être reconnu par une
   grammaire, de quelque façon que ce soit. Il peut être utilisé dans un
   corpus pour délimiter des élements. Par exemple, si un corpus est
   formé de nouvelles séparées par ``{STOP}``, il est impossible pour
   une grammaire de reconnaître une séquence qui chevauche la fin d’une
   nouvelle et le début de la suivante;

-  une étiquette lexicale ``{aujourd'hui,.ADV}``;

-  une séquence de lettres contiguës (les lettres sont définies dans le
   fichier alphabet de la langue);

-  un (et un seul) caractère différrent d’une lettre, i.e. tous les
   caractères non définis dans le fichier alphabet de la langue
   courante; s’il s’agit d’une newline, il est remplacé par un espace.

Pour les autres langues, le découpage est effectué caractère par
caractère, à l’exception du délimiteur de phrases ``{S}`` le marqueur
``{STOP}`` et des étiquettes lexicales. Ce découpage basique garantit le
fonctionnement d’Unitex, mais limite l’optimisation des opérations de
recherche de motifs.

Quel que soit le mode de découpage, les retours à la ligne présents dans
un texte sont remplacés par des espaces. Ce découpage est effectué par
le programme ``Tokenize`` . Ce programme produit plusieurs fichiers,
stockés dans le répertoire du texte :

-  ``tokens.txt`` contient la liste des unités lexicales dans l’ordre où
   elles ont été trouvées dans le texte;

-  ``text.cod`` contient un tableau d’entiers; chaque entier
   correspondant à l’indice d’une unité lexicale dans le fichier
   ``tokens.txt``;

-  ``tok_by_freq.txt`` contient la liste des unités lexicales triée par
   ordre de fréquence;

-  ``tok_by_alph.txt`` contient la liste des unités lexicales triée par
   ordre alphabétique;

-  ``stats.n`` contient quelques statistiques sur le texte.

Le découpage du texte :

*Un sou c’est un sou.*

donne la liste d’unités lexicales suivantes : *UN* ESPACE *sou c ’ est
un .*

On peut remarquer qu’il est tenu compte de la casse (Un et un sont deux
unités distinctes), mais que chaque unité n’est codée qu’une fois. En
numérotant ces unités de 0 à 7, ce texte peut être représenté par la
séquence d’entiers décrite dans le tableau suivant :

+---------------------------------+--------+-----+---------+-----+---------+-----+--------+-----+---------+-------+----+----+
| Indice                          | 0      | 1   | 2       | 1   | 3       | 1   | 4      | 1   | 2       | 5     |    |    |
+=================================+========+=====+=========+=====+=========+=====+========+=====+=========+=======+====+====+
| Unité lexicale correspondante   | *UN*   |     | *sou*   |     | *est*   |     | *UN*   |     | *sou*   | *.*   |    |    |
+---------------------------------+--------+-----+---------+-----+---------+-----+--------+-----+---------+-------+----+----+

Table: Représentation du texte *Un sou c’est un sou.*

Pour plus de détails, voir le chapitre [chap-file-formats].

.. figure:: resources/img/fig2-12.png
   :alt: Unités lexicales d’un texte anglais triées par fréquence
   :height: 10.00000cm

   Unités lexicales d’un texte anglais triées par fréquence

Application de dictionnaires
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

L’application de dictionnaires consiste à construire le sous-ensemble
des dictionnaires ne contenant que les formes présentes dans le texte.
Ainsi, le résultat de l’application des dictionnaires du français au
texte *Igor mange une pomme de terre* produit le dictionnaire de mots
simples suivant :

::

    de,.DET+z1
    de,.PREP+z1
    de,.XI+z1
    mange,manger.V+z1:P1s:P3s:S1s:S3s:Y2s
    pomme,.A+z1:ms:fs:mp:fp
    pomme,.N+z1:fs
    pomme,pommer.V+z3:P1s:P3s:S1s:S3s:Y2s
    terre,.N+z1:fs
    terre,terrer.V+z1:P1s:P3s:S1s:S3s:Y2s
    une,.N+z1:fs
    une,un.DET+z1:fs

ainsi que le dictionnaire de mots composés contenant l’unique entrée :

::

    pomme de terre,.N+z1:fs

La séquence *Igor* n’étant ni un mot simple du français, ni une partie
de mot composé, a été considérée comme un mot inconnu. L’application de
dictionnaires s’effectue avec le programme ``Dico``. Les trois fichiers
produits (``dlf`` pour les mots simples, ``dlc`` pour les mots composés
et ``err`` pour les mots inconnus) sont placés dans le répertoire du
texte. On appelle dictionnaires du texte les fichiers ``dlf`` et ``dlc``

Une fois l’application des dictionnaires effectuée, Unitex présente par
ordre alphabétique les mots simples, composés et inconnus trouvés dans
une fenêtre. La figure [fig-Dico-application-results] montre les
résultats pour un texte anglais.

.. figure:: resources/img/fig2-13.png
   :alt: Résultats de l’application de dictionnaires sur un texte
   anglais[fig-Dico-application-results]
   :width: 12.00000cm

   Résultats de l’application de dictionnaires sur un texte
   anglais[fig-Dico-application-results]

Il est également possible d’appliquer des dictionnaires en dehors du
prétraitement du texte. Pour cela, il faut cliquer sur “Apply Lexical
Resources...” dans le menu “Text”. Unitex affiche alors une fenêtre
(voir figure  [fig-Dico-configuration]) qui permet de choisir la liste
des dictionnaires à appliquer.

.. figure:: resources/img/fig2-14.png
   :alt: Paramétrage de l’application des
   dictionnaires[fig-Dico-configuration]
   :width: 10.00000cm

   Paramétrage de l’application des
   dictionnaires[fig-Dico-configuration]

La liste “User resources” recense tous les dictionnaires ``.bin`` et
``.fst2`` présents dans le répertoire ``(langue)/Dela`` de
l’utilisateur. Les dictionnaires du système sont listés dans le cadre
intitulé “System resources”. Utilisez <Ctrl+click> pour sélectionner
plusieurs dictionnaires. Les dictionnaires systèmes sont appliqués avant
les dictionnaires utilisateurs. Vous pouvez choisir l’ordre des
dictionnaires des listes utililisateur et système à l’aide des flèches
haut et bas (voir figure [fig-Dico-configuration]). Le bouton “Set
Default” vous permet de définir la sélection courante de dictionnaires
comme sélection par défaut. Cette sélection par défaut sera utilisée
lors du prétraitement si vous choisissez l’option “Apply All default
Dictionaries”. Si vous effectuez un clic droit au-dessus d’un nom de
dictionnaire, la documentation du dictionnaire, si elle existe,
s’affichera dans le cadre inférieur.

Analyse des mots composés libres en néerlandais, allemand, norvégien et russe
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

[section-Norwegian-compound-words] Dans certaines langues comme le
norvégien, il est possible de former des mots composés libres en soudant
leurs éléments. Par exemple, le mot *aftenblad* signifiant *journal du
soir* est obtenu en combinant les mots *aften* (*soir*) et *blad*
(*journal*). Le programme ``PolyLex`` explore la liste des mots inconnus
après application des dictionnaires au texte et essaye d’analyser chacun
de ces mots comme un mot composé. Si un mot possède au moins une
analyse, il est retiré de la liste des mots inconnus et les lignes de
dictionnaires produites pour ce mot sont ajoutées au dictionnaire des
mots simples du texte.

Ouverture d’un texte taggué
---------------------------

Un texte taggué est un texte contenant des entrées lexicales entre
accolades comme par exemple :

*I do not like the {square bracket,.N} sign! {S}*

De tels tags permettent de lever des ambiguïtés en interdisant tout
autre interprétation. Dans notre exemple, on ne pourra pas reconnaître
square bracket comme combinaison de deux mots simples.

Toutefois, la présence de ces tags peut perturber l’application des
graphes de prétraitement. L’utilisateur dispose donc de la commande
“Open Tagged Text...” dans le menu “Text”, grâce à laquelle il peut
ouvrir un texte contenant des tags sans que les graphes de
prétraitements ne soient appliqués, comme on le voit sur la figure
[preprocess-tagged-text].

.. figure:: resources/img/fig2-15.png
   :alt: Prétraitement d’un texte taggué[preprocess-tagged-text]
   :width: 14.00000cm

   Prétraitement d’un texte taggué[preprocess-tagged-text]

.. [1]
   Unitex propose également de convertir automatiquement les graphes et
   dictionnaires qui ne sont pas en Unicode Little-Endian.

.. [2]
   À partir de la version 3.1bêta, révision 4072 du 2 octobre 2015.
